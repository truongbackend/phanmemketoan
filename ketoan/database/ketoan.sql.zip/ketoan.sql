-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jun 22, 2025 at 04:41 PM
-- Server version: 5.7.39
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ketoan`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('new','in_review','resolved') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `user_id`, `order_code`, `content`, `status`, `created_at`, `updated_at`) VALUES
(1, 6, 'heheheheh', 'e', 'new', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `custom_notifications`
--

CREATE TABLE `custom_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `custom_notifications`
--

INSERT INTO `custom_notifications` (`id`, `title`, `content`, `type`, `created_at`, `updated_at`) VALUES
(5, 'lozz', 'ưdfwd', '2', '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(6, 'lozz', 'ưdfwd', '2', '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(7, 'đkđkkd', 'sdwfdw', '2', '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(8, 'huhwh', 'aa', '2', '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(9, 'cọc', 'ưdw', '1', '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(10, 'hêhhe', '111', '1', '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(12, 'a', 'a', '1', '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(13, 'heheh', '22', '1', '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(14, 'heheh', '22', '1', '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(15, 'heheh', '22', '1', '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(16, 'heheh', '22', '1', '2025-06-22 08:26:40', '2025-06-22 08:26:40');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `history_export`
--

CREATE TABLE `history_export` (
  `history_id` int(11) NOT NULL,
  `history_user_id` int(11) NOT NULL,
  `order_code` varchar(255) NOT NULL,
  `order_date` varchar(255) NOT NULL,
  `order_total_amount` int(13) DEFAULT NULL,
  `order_vat_amount` int(13) DEFAULT NULL,
  `order_paid_amount` int(13) DEFAULT NULL,
  `order_export_receipt` enum('0','1','2','3') NOT NULL DEFAULT '0',
  `history_instance_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history_export`
--

INSERT INTO `history_export` (`history_id`, `history_user_id`, `order_code`, `order_date`, `order_total_amount`, `order_vat_amount`, `order_paid_amount`, `order_export_receipt`, `history_instance_id`, `created_at`, `updated_at`) VALUES
(11, 1, 'WB00156770292PS', '16/06/2025 12:01:29', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:01', '2025-06-21 07:21:01'),
(12, 1, 'WB00156757857PS', '15/06/2025 11:40:27', 15278, 6667, 16500, '0', NULL, '2025-06-21 07:21:01', '2025-06-21 07:21:01'),
(13, 1, 'WB00156806970PS', '15/06/2025 10:40:41', 16667, 6667, 18000, '0', NULL, '2025-06-21 07:21:01', '2025-06-21 07:21:01'),
(14, 1, 'WB00156783276PS', '15/06/2025 12:41:14', 15278, 6667, 16500, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(15, 1, 'WB00156682085PS', '16/06/2025 11:19:33', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(16, 1, 'WB00156773501PS', '15/06/2025 08:59:55', 15278, 6667, 16500, '0', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(17, 1, 'WB00156692975PS', '15/06/2025 10:33:11', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(18, 1, 'WB00156692103PS', '16/06/2025 10:09:39', 15278, 6667, 16500, '0', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(19, 1, 'WB00156689434PS', '15/06/2025 09:44:15', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(20, 1, 'WB00156738123PS', '15/06/2025 10:31:06', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2025_06_08_040026_create_package_table', 1),
(6, '2025_06_09_030836_create_notification_table', 2),
(7, '2025_06_09_031400_create_notifications_table', 3),
(8, '2025_06_10_061839_create_permission_tables', 4),
(9, '2025_06_10_063247_add_note_and_status_to_roles_table', 5),
(10, '2025_06_13_090504_create_product_table', 6),
(11, '2025_06_15_165325_create_notifications_table', 7),
(12, '2025_06_18_090058_create_products_table', 8),
(13, '2025_06_21_142305_create_custom_notifications_table', 8),
(14, '2025_06_21_142404_create_notification_user_table', 8),
(15, '2025_06_22_160046_create_complaints_table', 9);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 9),
(2, 'App\\Models\\User', 10),
(2, 'App\\Models\\User', 18),
(1, 'App\\Models\\User', 20),
(2, 'App\\Models\\User', 22),
(2, 'App\\Models\\User', 23);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notification` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_user`
--

CREATE TABLE `notification_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notification_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_user`
--

INSERT INTO `notification_user` (`id`, `notification_id`, `user_id`, `read_at`, `created_at`, `updated_at`) VALUES
(65, 5, 11, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(66, 5, 6, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(67, 5, 19, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(68, 5, 7, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(69, 5, 12, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(70, 5, 10, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(71, 5, 23, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(72, 5, 13, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(73, 5, 22, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(74, 5, 20, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(75, 5, 8, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(76, 5, 18, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(77, 5, 17, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(78, 5, 14, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(79, 5, 9, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(80, 5, 1, '2025-06-22 08:53:34', '2025-06-21 07:47:49', '2025-06-22 04:16:01'),
(81, 6, 11, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(82, 6, 6, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(83, 6, 19, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(84, 6, 7, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(85, 6, 12, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(86, 6, 10, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(87, 6, 23, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(88, 6, 13, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(89, 6, 22, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(90, 6, 20, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(91, 6, 8, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(92, 6, 18, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(93, 6, 17, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(94, 6, 14, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(95, 6, 9, NULL, '2025-06-21 07:47:49', '2025-06-21 07:47:49'),
(96, 6, 1, '2025-06-22 08:53:34', '2025-06-21 07:47:49', '2025-06-22 08:00:51'),
(97, 7, 11, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(98, 7, 6, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(99, 7, 19, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(100, 7, 7, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(101, 7, 12, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(102, 7, 10, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(103, 7, 23, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(104, 7, 13, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(105, 7, 22, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(106, 7, 20, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(107, 7, 8, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(108, 7, 18, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(109, 7, 17, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(110, 7, 14, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(111, 7, 9, NULL, '2025-06-21 07:48:02', '2025-06-21 07:48:02'),
(112, 7, 1, '2025-06-22 08:53:34', '2025-06-21 07:48:02', '2025-06-22 04:16:00'),
(113, 8, 11, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(114, 8, 6, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(115, 8, 19, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(116, 8, 7, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(117, 8, 12, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(118, 8, 10, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(119, 8, 23, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(120, 8, 13, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(121, 8, 22, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(122, 8, 20, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(123, 8, 8, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(124, 8, 18, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(125, 8, 17, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(126, 8, 14, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(127, 8, 9, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(128, 8, 1, '2025-06-22 08:53:34', '2025-06-22 03:36:22', '2025-06-22 04:15:59'),
(129, 9, 11, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(130, 9, 6, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(131, 9, 19, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(132, 9, 7, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(133, 9, 12, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(134, 9, 10, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(135, 9, 23, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(136, 9, 13, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(137, 9, 22, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(138, 9, 20, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(139, 9, 8, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(140, 9, 18, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(141, 9, 17, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(142, 9, 14, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(143, 9, 9, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(144, 9, 1, '2025-06-22 08:53:34', '2025-06-22 03:40:08', '2025-06-22 08:24:43'),
(145, 10, 11, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(146, 10, 6, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(147, 10, 19, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(148, 10, 7, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(149, 10, 12, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(150, 10, 10, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(151, 10, 23, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(152, 10, 13, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(153, 10, 22, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(154, 10, 20, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(155, 10, 8, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(156, 10, 18, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(157, 10, 17, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(158, 10, 14, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(159, 10, 9, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(160, 10, 1, '2025-06-22 08:53:34', '2025-06-22 07:59:32', '2025-06-22 08:20:35'),
(177, 12, 11, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(178, 12, 6, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(179, 12, 19, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(180, 12, 7, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(181, 12, 12, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(182, 12, 10, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(183, 12, 23, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(184, 12, 13, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(185, 12, 22, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(186, 12, 20, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(187, 12, 8, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(188, 12, 18, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(189, 12, 17, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(190, 12, 14, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(191, 12, 9, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(192, 12, 1, '2025-06-22 08:53:34', '2025-06-22 08:21:36', '2025-06-22 08:49:02'),
(193, 13, 11, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(194, 13, 6, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(195, 13, 19, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(196, 13, 7, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(197, 13, 12, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(198, 13, 10, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(199, 13, 23, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(200, 13, 13, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(201, 13, 22, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(202, 13, 20, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(203, 13, 8, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(204, 13, 18, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(205, 13, 17, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(206, 13, 14, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(207, 13, 9, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(208, 13, 1, '2025-06-22 08:53:34', '2025-06-22 08:26:39', '2025-06-22 08:46:01'),
(209, 14, 11, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(210, 14, 6, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(211, 14, 19, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(212, 14, 7, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(213, 14, 12, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(214, 14, 10, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(215, 14, 23, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(216, 14, 13, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(217, 14, 22, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(218, 14, 20, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(219, 14, 8, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(220, 14, 18, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(221, 14, 17, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(222, 14, 14, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(223, 14, 9, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(224, 14, 1, '2025-06-22 08:53:34', '2025-06-22 08:26:40', '2025-06-22 08:51:08'),
(225, 15, 11, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(226, 15, 6, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(227, 15, 19, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(228, 15, 7, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(229, 15, 12, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(230, 15, 10, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(231, 15, 23, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(232, 15, 13, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(233, 15, 22, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(234, 15, 20, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(235, 15, 8, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(236, 15, 18, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(237, 15, 17, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(238, 15, 14, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(239, 15, 9, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(240, 15, 1, '2025-06-22 08:53:34', '2025-06-22 08:26:40', '2025-06-22 08:46:00'),
(241, 16, 11, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(242, 16, 6, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(243, 16, 19, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(244, 16, 7, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(245, 16, 12, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(246, 16, 10, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(247, 16, 23, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(248, 16, 13, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(249, 16, 22, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(250, 16, 20, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(251, 16, 8, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(252, 16, 18, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(253, 16, 17, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(254, 16, 14, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(255, 16, 9, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(256, 16, 1, '2025-06-22 08:53:34', '2025-06-22 08:26:40', '2025-06-22 08:46:00');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `discould` decimal(5,2) NOT NULL,
  `default_packages` tinyint(1) DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `expiration_time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `created_at`, `updated_at`, `name`, `note`, `price`, `discould`, `default_packages`, `status`, `expiration_time`) VALUES
(3, '2025-06-08 19:12:28', '2025-06-12 09:34:41', 'truong', '21', '12.00', '12.00', 1, 1, '10'),
(4, '2025-06-08 19:57:02', '2025-06-12 09:34:41', 'base', NULL, '21.00', '12.00', 0, 1, '12'),
(5, '2025-06-09 01:23:50', '2025-06-12 09:34:41', 'hehehehe', '21', '1200211.00', '16.00', 0, 1, '1'),
(6, '2025-06-16 01:50:40', '2025-06-16 01:50:40', 'heheh', '12', '22123.00', '12.00', 0, 1, '21');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'user.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(2, 'user.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(3, 'user.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(4, 'user.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(7, 'package.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(8, 'package.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(9, 'package.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(10, 'package.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(11, 'role.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(12, 'role.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(13, 'role.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(14, 'role.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(15, 'report.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(16, 'report.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(17, 'report.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(18, 'report.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(19, 'notification.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(20, 'notification.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(21, 'notification.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(22, 'notification.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(23, 'complaints.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(24, 'complaints.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(25, 'complaints.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(26, 'complaints.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(27, 'product.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(28, 'product.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(29, 'product.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(30, 'product.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `market_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accounting_system_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate` decimal(5,2) NOT NULL,
  `combo_detail_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `combo_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `combo_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` double(8,2) NOT NULL DEFAULT '1.00',
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `market_code`, `accounting_system_code`, `product_name`, `unit`, `tax_rate`, `combo_detail_code`, `combo_name`, `combo_unit`, `quantity`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 's', 'a', 's', 'f', '1.00', 'f', 's', 'a', 1.00, '1', '2025-06-15 16:25:38', '2025-06-15 16:25:38');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `market_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accounting_system_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate` decimal(5,2) NOT NULL,
  `combo_detail_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `combo_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `combo_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` double(8,2) NOT NULL DEFAULT '1.00',
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `default_role` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `note`, `status`, `default_role`) VALUES
(1, 'admin hehehe', 'api', '2025-06-09 23:23:02', '2025-06-16 04:47:01', 'Quant trị viên', 1, 1),
(2, 'nhân viên content', 'api', '2025-06-09 23:46:09', '2025-06-15 08:34:32', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_package` date DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `expiration_package` date DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `packages_id` int(11) DEFAULT NULL,
  `api_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `phone`, `address`, `create_package`, `note`, `expiration_package`, `status`, `packages_id`, `api_token`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'truong', 'truongbackend@gmail.com', '2032-02-25 02:51:34', '$2y$10$GcsjVq9wJshLtxWh5XBJw.ywinZ/XHEzm1GiNVfpT.xjFOHnZHCkK', '0521266565', '0521266565121', '2025-06-30', NULL, '2025-06-30', 1, 3, 'LvDRG2HPZuuMByNveKVzADqswhjmftX3nvM7HNdnlf2rjmHQC2XfS5NVKRdC', NULL, '2024-07-20 01:59:26', '2025-06-16 02:01:44'),
(6, 'admin', 'admin@gmail.com', NULL, '$2y$10$p4cmVtGZAMVWOhflDtgbguJ9UI9vjMm.Daa4otYgE.0Dgq2j6QUUC', '0352848002', '412', '2025-06-09', NULL, '2025-06-12', 0, 4, '', NULL, '2025-06-09 01:06:54', '2025-06-09 19:55:06'),
(7, 'truong', 'gh@gmail.com', NULL, '$2y$10$NfHYNUt.p5eKgthmkVwlQ.4kcDgEINRv4gz9u2XeaH/uku22UdiVG', '352848002', '214', '2025-06-09', NULL, '2025-06-27', 1, 3, '', NULL, '2025-06-09 01:07:48', '2025-06-09 01:14:09'),
(8, 'truong', 'truong@gmail.com', NULL, '$2y$10$J8mrZu62ukuXNdehYuWQ2.0WTS4Z58EZGxtRkuzF5ke6y2b85nrPy', NULL, NULL, NULL, NULL, NULL, 1, NULL, '', NULL, '2025-06-09 03:00:02', '2025-06-09 03:00:02'),
(9, 'truong', 'truong123@gmail.com', NULL, '$2y$10$6lJNvdwSjAu08wUykhdwjuatIOMFAy.w7qkETamqA/N.KYQQ98ZQO', '0352848005', NULL, '2025-06-10', NULL, '2025-06-11', 1, NULL, 'EofAHhhFyHEOEnPxVFq79Hx6MDaBMGyhyjfkvcPEHGr9Woo6V4qHZvo1SBq5', NULL, '2025-06-10 03:01:17', '2025-06-10 03:04:10'),
(10, 'hehehe', 'hehee@gmail.com', NULL, '$2y$10$RFDyyCC1q9VFoEnBEhTP4.5usuK/.CvD7QF3SXAkk.uZTDrJf0Lp6', NULL, NULL, '2025-06-10', NULL, '2025-06-11', 1, NULL, NULL, NULL, '2025-06-10 03:02:53', '2025-06-10 03:02:53'),
(11, 'aa', 'abc@gmail.com', NULL, '$2y$10$iy8XIcOa33X85rJy2NXpJulMG9CqEGs20RzfRvE9P8SviMQWdZ/Ky', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2025-06-12 08:26:01', '2025-06-12 08:26:01'),
(12, 'hêh ngay 22', 'he22@gmail.com', NULL, '$2y$10$ceVwL7zfmBOZ18uHKgPBr.ROO5i20l.NU4JpELDlgzidUwM.lAR52', NULL, NULL, NULL, NULL, '2025-06-22', 1, 3, NULL, NULL, '2025-06-12 09:35:17', '2025-06-12 09:35:17'),
(13, 'ngay moii', 'ngaymoi@gmail.com', NULL, '$2y$10$zzpWMnrj25jjBMXajpn7DeKS36xQlY4LsKe.hCC1bPnS2ek3wZNrO', NULL, NULL, '2025-06-12', NULL, '2025-06-22', 1, 3, NULL, NULL, '2025-06-12 09:39:49', '2025-06-12 09:39:49'),
(14, 'truong12', 'truong12@gmail.com', NULL, '$2y$10$n2Ixc5A0LI2AwDIkqWmc1egD2CejmBGojZC.vz3maC36oan8Hmi2W', NULL, NULL, '2025-06-12', NULL, '2025-06-22', 1, 3, NULL, NULL, '2025-06-12 09:58:34', '2025-06-12 09:58:34'),
(17, 'truong123', 'truong11322@gmail.com', NULL, '$2y$10$n2Ixc5A0LI2AwDIkqWmc1egD2CejmBGojZC.vz3maC36oan8Hmi2W', NULL, NULL, '2025-06-12', NULL, '2025-06-22', 1, 3, NULL, NULL, '2025-06-12 09:58:34', '2025-06-12 09:58:34'),
(18, 'truong', 'truong1@gmail.com', NULL, '$2y$10$TVFRk3aGoQ3//jK3Zj34i.5ngzotHUdXanQZqwh2gqwdbJc63DSGW', NULL, NULL, '2025-06-15', NULL, '2025-06-25', 1, 3, NULL, NULL, '2025-06-15 08:34:07', '2025-06-15 08:34:07'),
(19, 'truong', 'ahh1h2@gmail.com', NULL, '$2y$10$52.ihW2Y9xSqqM7TAou5HOv5kIkwSOL667WAfVWB2jjyG8l/fAP8W', NULL, NULL, '2025-06-16', NULL, '2025-06-26', 1, 3, NULL, NULL, '2025-06-16 01:51:03', '2025-06-16 01:51:03'),
(20, 'Admin', 'nhatmai.ketoan@gmail.com', NULL, '$2y$10$xnb7XbiB63I/V6N6VKcqduAQrAvJIUONHtNrEVaLkhnut.GbCgKJG', NULL, NULL, '2025-06-16', NULL, '2025-06-26', 1, 3, NULL, NULL, '2025-06-16 04:41:33', '2025-06-16 04:41:33'),
(22, 'Lim', 'nguyenthily.weup@gmail.com', NULL, '$2y$10$qSOdrgkJsONwELAJG7PDfuamhV8NCXwvLD5mJZXU/3SlfvxuKgCSG', NULL, NULL, '2025-06-16', NULL, '2025-06-26', 1, 3, 'tBpTPG2RPNnhhj8WzRpX4Xf3bocDmOuFtRZFAaPaRlK8yS2fcFzIO6PISCBI', NULL, '2025-06-16 05:19:23', '2025-06-16 06:32:55'),
(23, 'hoàng hải đăng', 'hoanghaidang.dev@gmail.com', NULL, '$2y$10$Qvcxwi0TOvdAjbUFahoHlOhDYgT8QNMNKBYWCJuvFEJKktXSGoGDC', NULL, NULL, '2025-06-16', NULL, '2025-06-26', 1, 3, 'URD9HC82nYkGKLISkZ6o7FFEmBv6qL9kWedkliTZHGtncuRUpVskPifYVlbn', NULL, '2025-06-16 07:30:08', '2025-06-16 08:20:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `complaints_user_id_foreign` (`user_id`);

--
-- Indexes for table `custom_notifications`
--
ALTER TABLE `custom_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `history_export`
--
ALTER TABLE `history_export`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_user`
--
ALTER TABLE `notification_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `notification_user_notification_id_user_id_unique` (`notification_id`,`user_id`),
  ADD KEY `notification_user_user_id_foreign` (`user_id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `custom_notifications`
--
ALTER TABLE `custom_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `history_export`
--
ALTER TABLE `history_export`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification_user`
--
ALTER TABLE `notification_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notification_user`
--
ALTER TABLE `notification_user`
  ADD CONSTRAINT `notification_user_notification_id_foreign` FOREIGN KEY (`notification_id`) REFERENCES `custom_notifications` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notification_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
