-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 31, 2025 at 05:30 PM
-- Server version: 5.7.39
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ketoan_version1`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('new','in_review','resolved') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `user_id`, `order_code`, `content`, `status`, `created_at`, `updated_at`) VALUES
(6, 1, 'aa', 'Since Role and Permission models are extended from Eloquent models, basic Eloquent calls can be used as well:', 'new', '2025-06-22 20:02:32', '2025-06-22 20:02:32'),
(7, 1, '424', '12431243', 'new', '2025-06-22 20:02:41', '2025-06-22 20:02:41'),
(8, 1, 'wqe', 'qwe21321431232121424214aaaa', 'resolved', '2025-06-22 20:03:39', '2025-06-22 20:53:15'),
(9, 1, 'hỗ trợ khách hàng', 'ádsad', 'new', '2025-06-22 20:14:37', '2025-06-22 20:14:37'),
(12, 24, 'hehehe', '21321', 'in_review', '2025-06-22 20:17:01', '2025-06-22 20:41:20'),
(13, 24, 'hehehe', '21321', 'in_review', '2025-06-22 20:17:01', '2025-06-22 20:41:20'),
(15, 24, 'hehehe', '21321', 'in_review', '2025-06-22 20:17:01', '2025-06-22 20:41:20'),
(16, 24, 'hehehe', '21321', 'in_review', '2025-06-22 20:17:01', '2025-06-22 20:41:20');

-- --------------------------------------------------------

--
-- Table structure for table `custom_notifications`
--

CREATE TABLE `custom_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `custom_notifications`
--

INSERT INTO `custom_notifications` (`id`, `title`, `content`, `type`, `created_at`, `updated_at`) VALUES
(8, 'huhwh', 'aa', '2', '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(9, 'cọc', 'ưdw', '1', '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(10, 'hêhhe', '111', '1', '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(12, 'a', 'a', '1', '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(13, 'heheh', '22', '1', '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(14, 'heheh', '22', '1', '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(15, 'heheh', '22', '1', '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(16, 'heheh', '22', '1', '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(17, 'a', 'a', '1', '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(18, 'hehehehe', '213', '1', '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(19, 'hehehehe', '213', '1', '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(20, 'hehehehe', '213', '1', '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(21, 'hehehehe', '213', '1', '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(22, 'a', 'a', '1', '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(23, 'a', 'a', '1', '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(24, 'a', 'a', '1', '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(25, 'a', 'a', '1', '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(26, 'a', 'a', '1', '2025-06-22 19:29:12', '2025-06-22 19:29:12'),
(27, 'a', 'a', '1', '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(28, 'a', 'a', '1', '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(29, 'a', 'a21', '1', '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(30, 'a12', 'a2', '1', '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(31, '213', '213', '1', '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(32, '34214', '12214', '1', '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(33, 'a', 'a', '1', '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(35, 'a', 'a', '1', '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(36, 'wqewq', 'wqe', '1', '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(37, 'hiehe', '32', '1', '2025-06-22 19:40:17', '2025-06-22 19:40:17'),
(38, 'fd21', 'nhfg', '1', '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(39, 'tạo mới', 'tạo mới nội dung', '2', '2025-06-29 18:56:38', '2025-06-29 18:56:38'),
(40, 'TH1: Không có MST + Những đơn hàng có chọn ở danh sách mã số thuế chưa có thông tin Lấy tên KH ở Lazada + (Khách lẻ không lấy hóa đơn)', 'TH1: Không có MST + Những đơn TH1: Không có MST + Những đơn hàng có chọn ở danh sách mã số thuế chưa có hàng có chọn ở danh sách mã số thuế chưa có thông tin\nLấy tên KH ở Lazada + (Khách lẻ không lấy hóa đơn)', '1', '2025-07-09 20:24:20', '2025-07-09 20:24:20'),
(41, 'Variable icon font', 'Add the variable font stylesheet request to your head tag and the current variable axes configuration to icons using CSS.', '1', '2025-07-09 21:29:39', '2025-07-09 21:29:39');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `history_export`
--

CREATE TABLE `history_export` (
  `history_id` int(11) NOT NULL,
  `history_user_id` int(11) NOT NULL,
  `order_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_total_amount` int(11) DEFAULT NULL,
  `order_vat_amount` int(11) DEFAULT NULL,
  `order_paid_amount` int(11) DEFAULT NULL,
  `order_export_receipt` enum('0','1','2','3') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `history_instance_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `history_export`
--

INSERT INTO `history_export` (`history_id`, `history_user_id`, `order_code`, `order_date`, `order_total_amount`, `order_vat_amount`, `order_paid_amount`, `order_export_receipt`, `history_instance_id`, `created_at`, `updated_at`) VALUES
(11, 1, 'WB00156770292PS', '16/06/2025 12:01:29', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:01', '2025-06-21 07:21:01'),
(12, 1, 'WB00156757857PS', '15/06/2025 11:40:27', 15278, 6667, 16500, '0', NULL, '2025-06-21 07:21:01', '2025-06-21 07:21:01'),
(13, 1, 'WB00156806970PS', '15/06/2025 10:40:41', 16667, 6667, 18000, '0', NULL, '2025-06-21 07:21:01', '2025-06-21 07:21:01'),
(14, 1, 'WB00156783276PS', '15/06/2025 12:41:14', 15278, 6667, 16500, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(15, 1, 'WB00156682085PS', '16/06/2025 11:19:33', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(16, 1, 'WB00156773501PS', '15/06/2025 08:59:55', 15278, 6667, 16500, '0', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(17, 1, 'WB00156692975PS', '15/06/2025 10:33:11', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(18, 1, 'WB00156692103PS', '16/06/2025 10:09:39', 15278, 6667, 16500, '0', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(19, 1, 'WB00156689434PS', '15/06/2025 09:44:15', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(20, 1, 'WB00156738123PS', '15/06/2025 10:31:06', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(21, 1, 'WB00156770292PS', '16/06/2025 12:01:29', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:01', '2025-06-21 07:21:01'),
(22, 1, 'WB00156757857PS', '15/06/2025 11:40:27', 15278, 6667, 16500, '0', NULL, '2025-06-21 07:21:01', '2025-06-21 07:21:01'),
(23, 1, 'WB00156806970PS', '15/06/2025 10:40:41', 16667, 6667, 18000, '0', NULL, '2025-06-21 07:21:01', '2025-06-21 07:21:01'),
(24, 1, 'WB00156783276PS', '15/06/2025 12:41:14', 15278, 6667, 16500, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(25, 1, 'WB00156682085PS', '16/06/2025 11:19:33', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(26, 1, 'WB00156773501PS', '15/06/2025 08:59:55', 15278, 6667, 16500, '0', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(27, 1, 'WB00156692975PS', '15/06/2025 10:33:11', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(28, 1, 'WB00156692103PS', '16/06/2025 10:09:39', 15278, 6667, 16500, '0', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(29, 1, 'WB00156689434PS', '15/06/2025 09:44:15', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52'),
(30, 1, 'WB00156738123PS', '15/06/2025 10:31:06', 16667, 6667, 18000, '1', NULL, '2025-06-21 07:21:52', '2025-06-21 07:21:52');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `queue`, `payload`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
(23, 'default', '{\"uuid\":\"c8841883-fb5d-4d81-b992-40ff25c25c79\",\"displayName\":\"App\\\\Events\\\\NotificationCreated\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Broadcasting\\\\BroadcastEvent\",\"command\":\"O:38:\\\"Illuminate\\\\Broadcasting\\\\BroadcastEvent\\\":13:{s:5:\\\"event\\\";O:30:\\\"App\\\\Events\\\\NotificationCreated\\\":1:{s:5:\\\"notif\\\";O:29:\\\"App\\\\Models\\\\CustomNotification\\\":30:{s:13:\\\"\\u0000*\\u0000connection\\\";s:5:\\\"mysql\\\";s:8:\\\"\\u0000*\\u0000table\\\";s:20:\\\"custom_notifications\\\";s:13:\\\"\\u0000*\\u0000primaryKey\\\";s:2:\\\"id\\\";s:10:\\\"\\u0000*\\u0000keyType\\\";s:3:\\\"int\\\";s:12:\\\"incrementing\\\";b:1;s:7:\\\"\\u0000*\\u0000with\\\";a:0:{}s:12:\\\"\\u0000*\\u0000withCount\\\";a:0:{}s:19:\\\"preventsLazyLoading\\\";b:0;s:10:\\\"\\u0000*\\u0000perPage\\\";i:15;s:6:\\\"exists\\\";b:1;s:18:\\\"wasRecentlyCreated\\\";b:1;s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;s:13:\\\"\\u0000*\\u0000attributes\\\";a:7:{s:5:\\\"title\\\";s:11:\\\"tạo mới\\\";s:7:\\\"content\\\";s:22:\\\"tạo mới nội dung\\\";s:4:\\\"type\\\";s:1:\\\"2\\\";s:10:\\\"updated_at\\\";s:19:\\\"2025-06-30 01:56:38\\\";s:10:\\\"created_at\\\";s:19:\\\"2025-06-30 01:56:38\\\";s:2:\\\"id\\\";i:39;s:12:\\\"unread_count\\\";i:17;}s:11:\\\"\\u0000*\\u0000original\\\";a:7:{s:5:\\\"title\\\";s:11:\\\"tạo mới\\\";s:7:\\\"content\\\";s:22:\\\"tạo mới nội dung\\\";s:4:\\\"type\\\";s:1:\\\"2\\\";s:10:\\\"updated_at\\\";s:19:\\\"2025-06-30 01:56:38\\\";s:10:\\\"created_at\\\";s:19:\\\"2025-06-30 01:56:38\\\";s:2:\\\"id\\\";i:39;s:12:\\\"unread_count\\\";i:17;}s:10:\\\"\\u0000*\\u0000changes\\\";a:0:{}s:8:\\\"\\u0000*\\u0000casts\\\";a:1:{s:2:\\\"id\\\";s:3:\\\"int\\\";}s:17:\\\"\\u0000*\\u0000classCastCache\\\";a:0:{}s:21:\\\"\\u0000*\\u0000attributeCastCache\\\";a:0:{}s:8:\\\"\\u0000*\\u0000dates\\\";a:0:{}s:13:\\\"\\u0000*\\u0000dateFormat\\\";N;s:10:\\\"\\u0000*\\u0000appends\\\";a:0:{}s:19:\\\"\\u0000*\\u0000dispatchesEvents\\\";a:0:{}s:14:\\\"\\u0000*\\u0000observables\\\";a:0:{}s:12:\\\"\\u0000*\\u0000relations\\\";a:0:{}s:10:\\\"\\u0000*\\u0000touches\\\";a:0:{}s:10:\\\"timestamps\\\";b:1;s:9:\\\"\\u0000*\\u0000hidden\\\";a:0:{}s:10:\\\"\\u0000*\\u0000visible\\\";a:0:{}s:11:\\\"\\u0000*\\u0000fillable\\\";a:3:{i:0;s:5:\\\"title\\\";i:1;s:7:\\\"content\\\";i:2;s:4:\\\"type\\\";}s:10:\\\"\\u0000*\\u0000guarded\\\";a:1:{i:0;s:1:\\\"*\\\";}}}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1751248599, 1751248599),
(24, 'default', '{\"uuid\":\"78f81152-63b5-4bd6-a263-5e0e064984d4\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:13:\\\"abc@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(25, 'default', '{\"uuid\":\"c473f2ef-fe25-4256-a208-5fd31be4945c\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:15:\\\"admin@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(26, 'default', '{\"uuid\":\"1844ace7-744e-4e9f-9ce2-95b092891ad2\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:16:\\\"ahh1h2@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(27, 'default', '{\"uuid\":\"b55ed7ce-66e8-4a54-8aad-352a29e1d56a\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:12:\\\"gh@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(28, 'default', '{\"uuid\":\"f4c8bc70-f1f1-4d0e-af21-c1420196c258\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:14:\\\"he22@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(29, 'default', '{\"uuid\":\"34e6c968-5425-4e5d-b57e-71d22e882a8e\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:15:\\\"hehee@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(30, 'default', '{\"uuid\":\"721a2c5a-6491-41a6-aab3-3b155d8ffbc8\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:26:\\\"hoanghaidang.dev@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(31, 'default', '{\"uuid\":\"cf005d42-7a21-4a2b-89f4-ca40ba8fbc8c\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:17:\\\"ngaymoi@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(32, 'default', '{\"uuid\":\"83e85ffd-3a8e-41f8-8c11-d156fce364f5\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:26:\\\"nguyenthily.weup@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(33, 'default', '{\"uuid\":\"5d087f1f-82d4-4434-ac00-68fa65863bfb\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:24:\\\"nhatmai.ketoan@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(34, 'default', '{\"uuid\":\"084f49c3-e6ef-4d56-ae7e-fc00ccfb0ee6\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:19:\\\"truo213ng@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(35, 'default', '{\"uuid\":\"54c7ca14-7b81-431e-8298-7d9423121bef\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:16:\\\"truong@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(36, 'default', '{\"uuid\":\"af795d4a-37b1-4d4c-aa20-5a03dffd9865\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:17:\\\"truong1@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(37, 'default', '{\"uuid\":\"e3b5c927-e3f8-4a7b-9e07-9dbdff10a7ed\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:21:\\\"truong11322@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(38, 'default', '{\"uuid\":\"77c83aac-b069-44f9-a65b-2758cf491f01\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:18:\\\"truong12@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(39, 'default', '{\"uuid\":\"e888edf9-cf6d-4c8b-a0d4-03e37857c0db\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:19:\\\"truong123@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(40, 'default', '{\"uuid\":\"1a31664d-3483-455e-8aea-2f3a070aa905\",\"displayName\":\"App\\\\Mail\\\\CustomNotificationMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:31:\\\"App\\\\Mail\\\\CustomNotificationMail\\\":3:{s:12:\\\"notification\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:29:\\\"App\\\\Models\\\\CustomNotification\\\";s:2:\\\"id\\\";i:39;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:23:\\\"truongbackend@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:3:\\\"job\\\";N;}\"}}', 0, NULL, 1751248599, 1751248599),
(41, 'default', '{\"uuid\":\"ae72109b-6102-4a51-b4bb-92790769d16f\",\"displayName\":\"App\\\\Events\\\\NotificationCreated\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Broadcasting\\\\BroadcastEvent\",\"command\":\"O:38:\\\"Illuminate\\\\Broadcasting\\\\BroadcastEvent\\\":13:{s:5:\\\"event\\\";O:30:\\\"App\\\\Events\\\\NotificationCreated\\\":1:{s:5:\\\"notif\\\";O:29:\\\"App\\\\Models\\\\CustomNotification\\\":30:{s:13:\\\"\\u0000*\\u0000connection\\\";s:5:\\\"mysql\\\";s:8:\\\"\\u0000*\\u0000table\\\";s:20:\\\"custom_notifications\\\";s:13:\\\"\\u0000*\\u0000primaryKey\\\";s:2:\\\"id\\\";s:10:\\\"\\u0000*\\u0000keyType\\\";s:3:\\\"int\\\";s:12:\\\"incrementing\\\";b:1;s:7:\\\"\\u0000*\\u0000with\\\";a:0:{}s:12:\\\"\\u0000*\\u0000withCount\\\";a:0:{}s:19:\\\"preventsLazyLoading\\\";b:0;s:10:\\\"\\u0000*\\u0000perPage\\\";i:15;s:6:\\\"exists\\\";b:1;s:18:\\\"wasRecentlyCreated\\\";b:0;s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;s:13:\\\"\\u0000*\\u0000attributes\\\";a:7:{s:2:\\\"id\\\";i:39;s:5:\\\"title\\\";s:11:\\\"tạo mới\\\";s:7:\\\"content\\\";s:22:\\\"tạo mới nội dung\\\";s:4:\\\"type\\\";s:1:\\\"2\\\";s:10:\\\"created_at\\\";s:19:\\\"2025-06-30 01:56:38\\\";s:10:\\\"updated_at\\\";s:19:\\\"2025-06-30 01:56:38\\\";s:12:\\\"unread_count\\\";i:17;}s:11:\\\"\\u0000*\\u0000original\\\";a:7:{s:2:\\\"id\\\";i:39;s:5:\\\"title\\\";s:11:\\\"tạo mới\\\";s:7:\\\"content\\\";s:22:\\\"tạo mới nội dung\\\";s:4:\\\"type\\\";s:1:\\\"2\\\";s:10:\\\"created_at\\\";s:19:\\\"2025-06-30 01:56:38\\\";s:10:\\\"updated_at\\\";s:19:\\\"2025-06-30 01:56:38\\\";s:12:\\\"unread_count\\\";i:17;}s:10:\\\"\\u0000*\\u0000changes\\\";a:0:{}s:8:\\\"\\u0000*\\u0000casts\\\";a:1:{s:2:\\\"id\\\";s:3:\\\"int\\\";}s:17:\\\"\\u0000*\\u0000classCastCache\\\";a:0:{}s:21:\\\"\\u0000*\\u0000attributeCastCache\\\";a:0:{}s:8:\\\"\\u0000*\\u0000dates\\\";a:0:{}s:13:\\\"\\u0000*\\u0000dateFormat\\\";N;s:10:\\\"\\u0000*\\u0000appends\\\";a:0:{}s:19:\\\"\\u0000*\\u0000dispatchesEvents\\\";a:0:{}s:14:\\\"\\u0000*\\u0000observables\\\";a:0:{}s:12:\\\"\\u0000*\\u0000relations\\\";a:0:{}s:10:\\\"\\u0000*\\u0000touches\\\";a:0:{}s:10:\\\"timestamps\\\";b:1;s:9:\\\"\\u0000*\\u0000hidden\\\";a:0:{}s:10:\\\"\\u0000*\\u0000visible\\\";a:0:{}s:11:\\\"\\u0000*\\u0000fillable\\\";a:3:{i:0;s:5:\\\"title\\\";i:1;s:7:\\\"content\\\";i:2;s:4:\\\"type\\\";}s:10:\\\"\\u0000*\\u0000guarded\\\";a:1:{i:0;s:1:\\\"*\\\";}}}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1751248599, 1751248599),
(42, 'default', '{\"uuid\":\"9b963fd5-98af-4bd1-8b32-17dd30455c34\",\"displayName\":\"App\\\\Events\\\\NotificationCreated\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Broadcasting\\\\BroadcastEvent\",\"command\":\"O:38:\\\"Illuminate\\\\Broadcasting\\\\BroadcastEvent\\\":13:{s:5:\\\"event\\\";O:30:\\\"App\\\\Events\\\\NotificationCreated\\\":1:{s:5:\\\"notif\\\";O:29:\\\"App\\\\Models\\\\CustomNotification\\\":30:{s:13:\\\"\\u0000*\\u0000connection\\\";s:5:\\\"mysql\\\";s:8:\\\"\\u0000*\\u0000table\\\";s:20:\\\"custom_notifications\\\";s:13:\\\"\\u0000*\\u0000primaryKey\\\";s:2:\\\"id\\\";s:10:\\\"\\u0000*\\u0000keyType\\\";s:3:\\\"int\\\";s:12:\\\"incrementing\\\";b:1;s:7:\\\"\\u0000*\\u0000with\\\";a:0:{}s:12:\\\"\\u0000*\\u0000withCount\\\";a:0:{}s:19:\\\"preventsLazyLoading\\\";b:0;s:10:\\\"\\u0000*\\u0000perPage\\\";i:15;s:6:\\\"exists\\\";b:1;s:18:\\\"wasRecentlyCreated\\\";b:0;s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;s:13:\\\"\\u0000*\\u0000attributes\\\";a:7:{s:2:\\\"id\\\";i:40;s:5:\\\"title\\\";s:169:\\\"TH1: Không có MST + Những đơn hàng có chọn ở danh sách mã số thuế chưa có thông tin Lấy tên KH ở Lazada + (Khách lẻ không lấy hóa đơn)\\\";s:7:\\\"content\\\";s:169:\\\"TH1: Không có MST + Những đơn hàng có chọn ở danh sách mã số thuế chưa có thông tin\\nLấy tên KH ở Lazada + (Khách lẻ không lấy hóa đơn)\\\";s:4:\\\"type\\\";s:1:\\\"1\\\";s:10:\\\"created_at\\\";s:19:\\\"2025-07-10 03:24:20\\\";s:10:\\\"updated_at\\\";s:19:\\\"2025-07-10 03:24:20\\\";s:12:\\\"unread_count\\\";i:17;}s:11:\\\"\\u0000*\\u0000original\\\";a:7:{s:2:\\\"id\\\";i:40;s:5:\\\"title\\\";s:169:\\\"TH1: Không có MST + Những đơn hàng có chọn ở danh sách mã số thuế chưa có thông tin Lấy tên KH ở Lazada + (Khách lẻ không lấy hóa đơn)\\\";s:7:\\\"content\\\";s:169:\\\"TH1: Không có MST + Những đơn hàng có chọn ở danh sách mã số thuế chưa có thông tin\\nLấy tên KH ở Lazada + (Khách lẻ không lấy hóa đơn)\\\";s:4:\\\"type\\\";s:1:\\\"1\\\";s:10:\\\"created_at\\\";s:19:\\\"2025-07-10 03:24:20\\\";s:10:\\\"updated_at\\\";s:19:\\\"2025-07-10 03:24:20\\\";s:12:\\\"unread_count\\\";i:17;}s:10:\\\"\\u0000*\\u0000changes\\\";a:0:{}s:8:\\\"\\u0000*\\u0000casts\\\";a:1:{s:2:\\\"id\\\";s:3:\\\"int\\\";}s:17:\\\"\\u0000*\\u0000classCastCache\\\";a:0:{}s:21:\\\"\\u0000*\\u0000attributeCastCache\\\";a:0:{}s:8:\\\"\\u0000*\\u0000dates\\\";a:0:{}s:13:\\\"\\u0000*\\u0000dateFormat\\\";N;s:10:\\\"\\u0000*\\u0000appends\\\";a:0:{}s:19:\\\"\\u0000*\\u0000dispatchesEvents\\\";a:0:{}s:14:\\\"\\u0000*\\u0000observables\\\";a:0:{}s:12:\\\"\\u0000*\\u0000relations\\\";a:0:{}s:10:\\\"\\u0000*\\u0000touches\\\";a:0:{}s:10:\\\"timestamps\\\";b:1;s:9:\\\"\\u0000*\\u0000hidden\\\";a:0:{}s:10:\\\"\\u0000*\\u0000visible\\\";a:0:{}s:11:\\\"\\u0000*\\u0000fillable\\\";a:3:{i:0;s:5:\\\"title\\\";i:1;s:7:\\\"content\\\";i:2;s:4:\\\"type\\\";}s:10:\\\"\\u0000*\\u0000guarded\\\";a:1:{i:0;s:1:\\\"*\\\";}}}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1752117863, 1752117863),
(43, 'default', '{\"uuid\":\"0d964347-e701-44c0-be51-257f1300aca0\",\"displayName\":\"App\\\\Events\\\\NotificationCreated\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Broadcasting\\\\BroadcastEvent\",\"command\":\"O:38:\\\"Illuminate\\\\Broadcasting\\\\BroadcastEvent\\\":13:{s:5:\\\"event\\\";O:30:\\\"App\\\\Events\\\\NotificationCreated\\\":1:{s:5:\\\"notif\\\";O:29:\\\"App\\\\Models\\\\CustomNotification\\\":30:{s:13:\\\"\\u0000*\\u0000connection\\\";s:5:\\\"mysql\\\";s:8:\\\"\\u0000*\\u0000table\\\";s:20:\\\"custom_notifications\\\";s:13:\\\"\\u0000*\\u0000primaryKey\\\";s:2:\\\"id\\\";s:10:\\\"\\u0000*\\u0000keyType\\\";s:3:\\\"int\\\";s:12:\\\"incrementing\\\";b:1;s:7:\\\"\\u0000*\\u0000with\\\";a:0:{}s:12:\\\"\\u0000*\\u0000withCount\\\";a:0:{}s:19:\\\"preventsLazyLoading\\\";b:0;s:10:\\\"\\u0000*\\u0000perPage\\\";i:15;s:6:\\\"exists\\\";b:1;s:18:\\\"wasRecentlyCreated\\\";b:0;s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;s:13:\\\"\\u0000*\\u0000attributes\\\";a:7:{s:2:\\\"id\\\";i:41;s:5:\\\"title\\\";s:18:\\\"Variable icon font\\\";s:7:\\\"content\\\";s:121:\\\"Add the variable font stylesheet request to your head tag and the current variable axes configuration to icons using CSS.\\\";s:4:\\\"type\\\";s:1:\\\"1\\\";s:10:\\\"created_at\\\";s:19:\\\"2025-07-10 04:29:39\\\";s:10:\\\"updated_at\\\";s:19:\\\"2025-07-10 04:29:39\\\";s:12:\\\"unread_count\\\";i:17;}s:11:\\\"\\u0000*\\u0000original\\\";a:7:{s:2:\\\"id\\\";i:41;s:5:\\\"title\\\";s:18:\\\"Variable icon font\\\";s:7:\\\"content\\\";s:121:\\\"Add the variable font stylesheet request to your head tag and the current variable axes configuration to icons using CSS.\\\";s:4:\\\"type\\\";s:1:\\\"1\\\";s:10:\\\"created_at\\\";s:19:\\\"2025-07-10 04:29:39\\\";s:10:\\\"updated_at\\\";s:19:\\\"2025-07-10 04:29:39\\\";s:12:\\\"unread_count\\\";i:17;}s:10:\\\"\\u0000*\\u0000changes\\\";a:0:{}s:8:\\\"\\u0000*\\u0000casts\\\";a:1:{s:2:\\\"id\\\";s:3:\\\"int\\\";}s:17:\\\"\\u0000*\\u0000classCastCache\\\";a:0:{}s:21:\\\"\\u0000*\\u0000attributeCastCache\\\";a:0:{}s:8:\\\"\\u0000*\\u0000dates\\\";a:0:{}s:13:\\\"\\u0000*\\u0000dateFormat\\\";N;s:10:\\\"\\u0000*\\u0000appends\\\";a:0:{}s:19:\\\"\\u0000*\\u0000dispatchesEvents\\\";a:0:{}s:14:\\\"\\u0000*\\u0000observables\\\";a:0:{}s:12:\\\"\\u0000*\\u0000relations\\\";a:0:{}s:10:\\\"\\u0000*\\u0000touches\\\";a:0:{}s:10:\\\"timestamps\\\";b:1;s:9:\\\"\\u0000*\\u0000hidden\\\";a:0:{}s:10:\\\"\\u0000*\\u0000visible\\\";a:0:{}s:11:\\\"\\u0000*\\u0000fillable\\\";a:3:{i:0;s:5:\\\"title\\\";i:1;s:7:\\\"content\\\";i:2;s:4:\\\"type\\\";}s:10:\\\"\\u0000*\\u0000guarded\\\";a:1:{i:0;s:1:\\\"*\\\";}}}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 0, NULL, 1752121780, 1752121780);

-- --------------------------------------------------------

--
-- Table structure for table `lazada_shop_tokens`
--

CREATE TABLE `lazada_shop_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `auth_user_id` int(11) NOT NULL,
  `access_token` varchar(255) NOT NULL,
  `refresh_token` varchar(255) NOT NULL,
  `account_platform` varchar(255) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `seller_id` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `country` varchar(10) DEFAULT NULL,
  `short_code` varchar(255) DEFAULT NULL,
  `expires_in` int(11) DEFAULT NULL,
  `refresh_expires_in` int(11) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `request_id` varchar(255) DEFAULT NULL,
  `trace_id` varchar(255) DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lazada_shop_tokens`
--

INSERT INTO `lazada_shop_tokens` (`id`, `auth_user_id`, `access_token`, `refresh_token`, `account_platform`, `account`, `seller_id`, `user_id`, `country`, `short_code`, `expires_in`, `refresh_expires_in`, `code`, `request_id`, `trace_id`, `active`, `created_at`, `updated_at`) VALUES
(2, 1, '50000200d109TNswoxfb4K127477aduDosgzvFBGgT8quwgiHtL3hRS9CBloy7zs', '50001201410cKCkuepvcxT193a0fdcd7idwBrUYHlHOmyguvnCbGsPAJOASlwSb8', 'lazada', 'LzdOp_VN_test@163.com', NULL, NULL, 'vn', NULL, 604800, 1736200, '0_132625_ruTT1wF9D3ZODkCS3Y2V1CS8443', '2140fcb517538585640186619', '2140d18717538585640205760e760f', 'N', '2025-06-28 03:30:52', '2025-07-29 23:56:30'),
(4, 1, '50000200933s6rv7jHtysUa95i0koSEWuGbhds7nVTHnh1908573buGvD5V9mTos', '50001201033qh0uaa6lwiMqAyrjeiDUiqVyiigNjZDV0D1c4f7f72DW8O3DJySVp', 'lazada', 'LzdOp_VN_test@163.com', NULL, NULL, 'vn', NULL, 604800, 2206368, '0_132625_ruTT1wF9D3ZODkCS3Y2V1CS8443', '2141310917524639630463977', '2141031417524639630448167e0f66', 'N', '2025-06-28 03:30:52', '2025-07-13 20:51:39'),
(5, 1, '50000200933s6rv7jHtysUa95i0koSEWuGbhds7nVTHnh1908573buGvD5V9mTos', '50001201033qh0uaa6lwiMqAyrjeiDUiqVyiigNjZDV0D1c4f7f72DW8O3DJySVp', 'lazada', 'LzdOp_VN_test@163.com', NULL, NULL, 'vn', NULL, 604800, 2206368, '0_132625_ruTT1wF9D3ZODkCS3Y2V1CS8443', '2141310917524639630463977', '2141031417524639630448167e0f66', 'N', '2025-06-28 03:30:52', '2025-07-13 20:51:47'),
(6, 1, '50000200933s6rv7jHtysUa95i0koSEWuGbhds7nVTHnh1908573buGvD5V9mTos', '50001201033qh0uaa6lwiMqAyrjeiDUiqVyiigNjZDV0D1c4f7f72DW8O3DJySVp', 'lazada', 'LzdOp_VN_test@163.com', NULL, NULL, 'vn', NULL, 604800, 2206368, '0_132625_ruTT1wF9D3ZODkCS3Y2V1CS8443', '2141310917524639630463977', '2141031417524639630448167e0f66', 'N', '2025-06-28 03:30:52', '2025-07-13 20:51:59'),
(7, 1, '50000201139yY3eZ0nzfnUaSvfdjhSiPxXhlgMkyHQXHgXioOpw1432e1f1o5MRq', '50001201d39uaqbccx9nxYdGkMn3kTXoiaDurdNrZPQuzWeoBVD1be84575f3Fwy', 'lazada', 'LzdOp_VN_test@163.com', NULL, NULL, 'vn', NULL, 604800, 2205171, '0_132625_ruTT1wF9D3ZODkCS3Y2V1CS8443', '0babf46a17524651607393192', '210143f217524651607355711e2513', 'Y', '2025-06-28 03:30:52', '2025-07-13 20:52:59'),
(8, 1, '50000200933s6rv7jHtysUa95i0koSEWuGbhds7nVTHnh1908573buGvD5V9mTos', '50001201033qh0uaa6lwiMqAyrjeiDUiqVyiigNjZDV0D1c4f7f72DW8O3DJySVp', 'lazada', 'LzdOp_VN_test@163.com', NULL, NULL, 'vn', NULL, 604800, 2206368, '0_132625_ruTT1wF9D3ZODkCS3Y2V1CS8443', '2141310917524639630463977', '2141031417524639630448167e0f66', 'N', '2025-06-28 03:30:52', '2025-07-13 20:52:32'),
(9, 1, '50000200933s6rv7jHtysUa95i0koSEWuGbhds7nVTHnh1908573buGvD5V9mTos', '50001201033qh0uaa6lwiMqAyrjeiDUiqVyiigNjZDV0D1c4f7f72DW8O3DJySVp', 'lazada', 'LzdOp_VN_test@163.com', NULL, NULL, 'vn', NULL, 604800, 2206368, '0_132625_ruTT1wF9D3ZODkCS3Y2V1CS8443', '2141310917524639630463977', '2141031417524639630448167e0f66', 'N', '2025-06-28 03:30:52', '2025-07-13 20:52:55');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2025_06_08_040026_create_package_table', 1),
(6, '2025_06_09_030836_create_notification_table', 2),
(7, '2025_06_09_031400_create_notifications_table', 3),
(8, '2025_06_10_061839_create_permission_tables', 4),
(9, '2025_06_10_063247_add_note_and_status_to_roles_table', 5),
(10, '2025_06_13_090504_create_product_table', 6),
(11, '2025_06_15_165325_create_notifications_table', 7),
(12, '2025_06_18_090058_create_products_table', 8),
(13, '2025_06_21_142305_create_custom_notifications_table', 8),
(14, '2025_06_21_142404_create_notification_user_table', 8),
(15, '2025_06_22_160046_create_complaints_table', 9),
(16, '2025_06_23_045842_add_token_created_at_to_users_table', 10),
(17, '2025_06_24_090117_create_products_table', 11),
(18, '2025_06_24_090503_create_product_details_table', 11),
(19, '2025_07_14_014455_create_setting_ecommerce_table', 12),
(20, '2025_07_31_092307_add_shop_id_to_setting_account_ecommerce_table', 13);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(1, 'App\\Models\\User', 8),
(2, 'App\\Models\\User', 9),
(2, 'App\\Models\\User', 10),
(2, 'App\\Models\\User', 18),
(1, 'App\\Models\\User', 20),
(2, 'App\\Models\\User', 22),
(2, 'App\\Models\\User', 23),
(1, 'App\\Models\\User', 24);

-- --------------------------------------------------------

--
-- Table structure for table `notification_user`
--

CREATE TABLE `notification_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notification_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_user`
--

INSERT INTO `notification_user` (`id`, `notification_id`, `user_id`, `read_at`, `created_at`, `updated_at`) VALUES
(113, 8, 11, '2025-07-22 04:01:43', '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(114, 8, 6, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(115, 8, 19, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(116, 8, 7, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(117, 8, 12, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(118, 8, 10, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(119, 8, 23, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(120, 8, 13, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(121, 8, 22, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(122, 8, 20, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(123, 8, 8, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(124, 8, 18, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(125, 8, 17, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(126, 8, 14, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(127, 8, 9, NULL, '2025-06-22 03:36:22', '2025-06-22 03:36:22'),
(128, 8, 1, '2025-06-22 21:00:50', '2025-06-22 03:36:22', '2025-06-22 04:15:59'),
(129, 9, 11, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(130, 9, 6, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(131, 9, 19, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(132, 9, 7, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(133, 9, 12, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(134, 9, 10, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(135, 9, 23, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(136, 9, 13, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(137, 9, 22, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(138, 9, 20, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(139, 9, 8, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(140, 9, 18, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(141, 9, 17, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(142, 9, 14, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(143, 9, 9, NULL, '2025-06-22 03:40:08', '2025-06-22 03:40:08'),
(144, 9, 1, '2025-06-22 21:00:50', '2025-06-22 03:40:08', '2025-06-22 08:24:43'),
(145, 10, 11, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(146, 10, 6, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(147, 10, 19, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(148, 10, 7, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(149, 10, 12, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(150, 10, 10, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(151, 10, 23, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(152, 10, 13, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(153, 10, 22, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(154, 10, 20, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(155, 10, 8, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(156, 10, 18, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(157, 10, 17, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(158, 10, 14, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(159, 10, 9, NULL, '2025-06-22 07:59:32', '2025-06-22 07:59:32'),
(160, 10, 1, '2025-06-22 21:00:50', '2025-06-22 07:59:32', '2025-06-22 08:20:35'),
(177, 12, 11, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(178, 12, 6, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(179, 12, 19, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(180, 12, 7, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(181, 12, 12, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(182, 12, 10, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(183, 12, 23, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(184, 12, 13, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(185, 12, 22, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(186, 12, 20, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(187, 12, 8, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(188, 12, 18, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(189, 12, 17, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(190, 12, 14, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(191, 12, 9, NULL, '2025-06-22 08:21:36', '2025-06-22 08:21:36'),
(192, 12, 1, '2025-06-22 21:00:50', '2025-06-22 08:21:36', '2025-06-22 08:49:02'),
(193, 13, 11, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(194, 13, 6, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(195, 13, 19, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(196, 13, 7, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(197, 13, 12, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(198, 13, 10, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(199, 13, 23, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(200, 13, 13, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(201, 13, 22, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(202, 13, 20, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(203, 13, 8, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(204, 13, 18, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(205, 13, 17, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(206, 13, 14, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(207, 13, 9, NULL, '2025-06-22 08:26:39', '2025-06-22 08:26:39'),
(208, 13, 1, '2025-06-22 21:00:50', '2025-06-22 08:26:39', '2025-06-22 08:46:01'),
(209, 14, 11, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(210, 14, 6, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(211, 14, 19, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(212, 14, 7, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(213, 14, 12, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(214, 14, 10, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(215, 14, 23, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(216, 14, 13, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(217, 14, 22, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(218, 14, 20, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(219, 14, 8, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(220, 14, 18, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(221, 14, 17, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(222, 14, 14, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(223, 14, 9, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(224, 14, 1, '2025-06-22 21:00:50', '2025-06-22 08:26:40', '2025-06-22 08:51:08'),
(225, 15, 11, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(226, 15, 6, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(227, 15, 19, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(228, 15, 7, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(229, 15, 12, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(230, 15, 10, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(231, 15, 23, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(232, 15, 13, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(233, 15, 22, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(234, 15, 20, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(235, 15, 8, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(236, 15, 18, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(237, 15, 17, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(238, 15, 14, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(239, 15, 9, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(240, 15, 1, '2025-06-22 21:00:50', '2025-06-22 08:26:40', '2025-06-22 08:46:00'),
(241, 16, 11, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(242, 16, 6, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(243, 16, 19, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(244, 16, 7, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(245, 16, 12, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(246, 16, 10, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(247, 16, 23, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(248, 16, 13, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(249, 16, 22, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(250, 16, 20, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(251, 16, 8, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(252, 16, 18, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(253, 16, 17, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(254, 16, 14, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(255, 16, 9, NULL, '2025-06-22 08:26:40', '2025-06-22 08:26:40'),
(256, 16, 1, '2025-06-22 21:00:50', '2025-06-22 08:26:40', '2025-06-22 08:46:00'),
(257, 17, 11, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(258, 17, 6, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(259, 17, 19, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(260, 17, 7, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(261, 17, 12, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(262, 17, 10, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(263, 17, 23, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(264, 17, 13, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(265, 17, 22, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(266, 17, 20, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(267, 17, 8, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(268, 17, 18, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(269, 17, 17, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(270, 17, 14, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(271, 17, 9, NULL, '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(272, 17, 1, '2025-06-22 21:00:50', '2025-06-22 18:55:46', '2025-06-22 18:55:46'),
(273, 18, 11, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(274, 18, 6, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(275, 18, 19, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(276, 18, 7, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(277, 18, 12, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(278, 18, 10, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(279, 18, 23, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(280, 18, 13, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(281, 18, 22, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(282, 18, 20, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(283, 18, 8, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(284, 18, 18, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(285, 18, 17, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(286, 18, 14, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(287, 18, 9, NULL, '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(288, 18, 1, '2025-06-22 21:00:50', '2025-06-22 19:01:05', '2025-06-22 19:01:05'),
(289, 19, 11, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(290, 19, 6, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(291, 19, 19, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(292, 19, 7, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(293, 19, 12, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(294, 19, 10, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(295, 19, 23, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(296, 19, 13, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(297, 19, 22, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(298, 19, 20, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(299, 19, 8, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(300, 19, 18, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(301, 19, 17, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(302, 19, 14, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(303, 19, 9, NULL, '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(304, 19, 1, '2025-06-22 21:00:50', '2025-06-22 19:01:06', '2025-06-22 19:01:06'),
(305, 20, 11, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(306, 20, 6, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(307, 20, 19, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(308, 20, 7, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(309, 20, 12, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(310, 20, 10, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(311, 20, 23, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(312, 20, 13, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(313, 20, 22, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(314, 20, 20, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(315, 20, 8, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(316, 20, 18, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(317, 20, 17, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(318, 20, 14, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(319, 20, 9, NULL, '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(320, 20, 1, '2025-06-22 21:00:50', '2025-06-22 19:01:30', '2025-06-22 19:01:30'),
(321, 21, 11, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(322, 21, 6, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(323, 21, 19, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(324, 21, 7, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(325, 21, 12, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(326, 21, 10, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(327, 21, 23, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(328, 21, 13, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(329, 21, 22, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(330, 21, 20, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(331, 21, 8, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(332, 21, 18, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(333, 21, 17, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(334, 21, 14, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(335, 21, 9, NULL, '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(336, 21, 1, '2025-06-22 21:00:50', '2025-06-22 19:01:31', '2025-06-22 19:01:31'),
(337, 22, 11, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(338, 22, 6, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(339, 22, 19, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(340, 22, 7, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(341, 22, 12, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(342, 22, 10, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(343, 22, 23, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(344, 22, 13, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(345, 22, 22, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(346, 22, 20, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(347, 22, 8, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(348, 22, 18, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(349, 22, 17, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(350, 22, 14, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(351, 22, 9, NULL, '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(352, 22, 1, '2025-06-22 21:00:50', '2025-06-22 19:02:57', '2025-06-22 19:02:57'),
(353, 23, 11, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(354, 23, 6, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(355, 23, 19, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(356, 23, 7, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(357, 23, 12, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(358, 23, 10, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(359, 23, 23, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(360, 23, 13, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(361, 23, 22, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(362, 23, 20, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(363, 23, 8, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(364, 23, 18, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(365, 23, 17, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(366, 23, 14, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(367, 23, 9, NULL, '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(368, 23, 1, '2025-06-22 21:00:50', '2025-06-22 19:08:25', '2025-06-22 19:08:25'),
(369, 24, 11, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(370, 24, 6, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(371, 24, 19, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(372, 24, 7, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(373, 24, 12, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(374, 24, 10, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(375, 24, 23, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(376, 24, 13, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(377, 24, 22, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(378, 24, 20, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(379, 24, 8, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(380, 24, 18, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(381, 24, 17, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(382, 24, 14, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(383, 24, 9, NULL, '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(384, 24, 1, '2025-06-22 21:00:50', '2025-06-22 19:22:44', '2025-06-22 19:22:44'),
(385, 25, 11, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(386, 25, 6, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(387, 25, 19, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(388, 25, 7, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(389, 25, 12, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(390, 25, 10, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(391, 25, 23, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(392, 25, 13, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(393, 25, 22, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(394, 25, 20, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(395, 25, 8, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(396, 25, 18, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(397, 25, 17, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(398, 25, 14, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(399, 25, 9, NULL, '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(400, 25, 1, '2025-06-22 21:00:50', '2025-06-22 19:29:10', '2025-06-22 19:29:10'),
(401, 26, 11, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(402, 26, 6, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(403, 26, 19, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(404, 26, 7, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(405, 26, 12, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(406, 26, 10, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(407, 26, 23, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(408, 26, 13, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(409, 26, 22, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(410, 26, 20, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(411, 26, 8, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(412, 26, 18, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(413, 26, 17, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(414, 26, 14, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(415, 26, 9, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(416, 26, 1, '2025-06-22 21:00:50', '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(417, 27, 11, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(418, 27, 6, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(419, 27, 19, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(420, 27, 7, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(421, 27, 12, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(422, 27, 10, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(423, 27, 23, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(424, 27, 13, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(425, 27, 22, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(426, 27, 20, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(427, 27, 8, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(428, 27, 18, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(429, 27, 17, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(430, 27, 14, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(431, 27, 9, NULL, '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(432, 27, 1, '2025-06-22 21:00:50', '2025-06-22 19:29:13', '2025-06-22 19:29:13'),
(433, 28, 11, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(434, 28, 6, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(435, 28, 19, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(436, 28, 7, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(437, 28, 12, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(438, 28, 10, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(439, 28, 23, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(440, 28, 13, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(441, 28, 22, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(442, 28, 20, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(443, 28, 8, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(444, 28, 18, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(445, 28, 17, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(446, 28, 14, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(447, 28, 9, NULL, '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(448, 28, 1, '2025-06-22 21:00:50', '2025-06-22 19:31:38', '2025-06-22 19:31:38'),
(449, 29, 11, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(450, 29, 6, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(451, 29, 19, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(452, 29, 7, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(453, 29, 12, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(454, 29, 10, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(455, 29, 23, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(456, 29, 13, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(457, 29, 22, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(458, 29, 20, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(459, 29, 8, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(460, 29, 18, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(461, 29, 17, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(462, 29, 14, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(463, 29, 9, NULL, '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(464, 29, 1, '2025-06-22 21:00:50', '2025-06-22 19:32:51', '2025-06-22 19:32:51'),
(465, 30, 11, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(466, 30, 6, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(467, 30, 19, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(468, 30, 7, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(469, 30, 12, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(470, 30, 10, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(471, 30, 23, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(472, 30, 13, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(473, 30, 22, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(474, 30, 20, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(475, 30, 8, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(476, 30, 18, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(477, 30, 17, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(478, 30, 14, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(479, 30, 9, NULL, '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(480, 30, 1, '2025-06-22 21:00:50', '2025-06-22 19:33:08', '2025-06-22 19:33:08'),
(481, 31, 11, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(482, 31, 6, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(483, 31, 19, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(484, 31, 7, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(485, 31, 12, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(486, 31, 10, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(487, 31, 23, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(488, 31, 13, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(489, 31, 22, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(490, 31, 20, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(491, 31, 8, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(492, 31, 18, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(493, 31, 17, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(494, 31, 14, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(495, 31, 9, NULL, '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(496, 31, 1, '2025-06-22 21:00:50', '2025-06-22 19:33:37', '2025-06-22 19:33:37'),
(497, 32, 11, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(498, 32, 6, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(499, 32, 19, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(500, 32, 7, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(501, 32, 12, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(502, 32, 10, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(503, 32, 23, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(504, 32, 13, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(505, 32, 22, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(506, 32, 20, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(507, 32, 8, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(508, 32, 18, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(509, 32, 17, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(510, 32, 14, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(511, 32, 9, NULL, '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(512, 32, 1, '2025-06-22 21:00:50', '2025-06-22 19:34:14', '2025-06-22 19:34:14'),
(513, 33, 11, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(514, 33, 6, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(515, 33, 19, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(516, 33, 7, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(517, 33, 12, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(518, 33, 10, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(519, 33, 23, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(520, 33, 13, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(521, 33, 22, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(522, 33, 20, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(523, 33, 8, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(524, 33, 18, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(525, 33, 17, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(526, 33, 14, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(527, 33, 9, NULL, '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(528, 33, 1, '2025-06-22 21:00:50', '2025-06-22 19:35:54', '2025-06-22 19:35:54'),
(545, 35, 11, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(546, 35, 6, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(547, 35, 19, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(548, 35, 7, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(549, 35, 12, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(550, 35, 10, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(551, 35, 23, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(552, 35, 13, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(553, 35, 22, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(554, 35, 20, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(555, 35, 8, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(556, 35, 18, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(557, 35, 17, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(558, 35, 14, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(559, 35, 9, NULL, '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(560, 35, 1, '2025-06-22 21:00:50', '2025-06-22 19:39:16', '2025-06-22 19:39:16'),
(561, 36, 11, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(562, 36, 6, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(563, 36, 19, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(564, 36, 7, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(565, 36, 12, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(566, 36, 10, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(567, 36, 23, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(568, 36, 13, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(569, 36, 22, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(570, 36, 20, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(571, 36, 8, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(572, 36, 18, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(573, 36, 17, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(574, 36, 14, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(575, 36, 9, NULL, '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(576, 36, 1, '2025-06-22 21:00:50', '2025-06-22 19:40:07', '2025-06-22 19:40:07'),
(577, 37, 11, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(578, 37, 6, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(579, 37, 19, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(580, 37, 7, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(581, 37, 12, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(582, 37, 10, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(583, 37, 23, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(584, 37, 13, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(585, 37, 22, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(586, 37, 20, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(587, 37, 8, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(588, 37, 18, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(589, 37, 17, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(590, 37, 14, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(591, 37, 9, NULL, '2025-06-22 19:40:17', '2025-06-22 19:40:18'),
(592, 37, 1, '2025-06-22 21:00:50', '2025-06-22 19:40:17', '2025-06-22 19:40:27'),
(593, 38, 11, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(594, 38, 6, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(595, 38, 19, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(596, 38, 7, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(597, 38, 12, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(598, 38, 10, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(599, 38, 23, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(600, 38, 13, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(601, 38, 22, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(602, 38, 20, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(603, 38, 8, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(604, 38, 18, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(605, 38, 17, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(606, 38, 14, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(607, 38, 9, NULL, '2025-06-22 19:40:39', '2025-06-22 19:40:39'),
(608, 38, 1, '2025-06-26 19:47:21', '2025-06-22 19:40:39', '2025-06-26 19:47:21'),
(609, 39, 11, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(610, 39, 6, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(611, 39, 19, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(612, 39, 7, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(613, 39, 12, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(614, 39, 10, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(615, 39, 23, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(616, 39, 13, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(617, 39, 22, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(618, 39, 20, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(619, 39, 24, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(620, 39, 8, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:54'),
(621, 39, 18, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(622, 39, 17, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(623, 39, 14, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(624, 39, 9, NULL, '2025-06-29 18:56:38', '2025-06-29 18:56:39'),
(625, 39, 1, '2025-07-09 20:24:01', '2025-06-29 18:56:38', '2025-07-09 20:24:01'),
(626, 40, 11, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(627, 40, 6, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(628, 40, 19, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(629, 40, 7, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(630, 40, 12, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(631, 40, 10, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(632, 40, 23, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(633, 40, 13, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(634, 40, 22, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(635, 40, 20, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(636, 40, 24, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(637, 40, 8, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(638, 40, 18, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(639, 40, 17, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(640, 40, 14, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(641, 40, 9, NULL, '2025-07-09 20:24:20', '2025-07-09 20:24:23'),
(642, 40, 1, NULL, '2025-07-09 20:24:20', '2025-07-09 21:37:35'),
(643, 41, 11, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(644, 41, 6, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(645, 41, 19, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(646, 41, 7, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(647, 41, 12, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(648, 41, 10, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(649, 41, 23, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(650, 41, 13, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(651, 41, 22, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(652, 41, 20, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(653, 41, 24, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(654, 41, 8, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(655, 41, 18, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(656, 41, 17, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(657, 41, 14, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(658, 41, 9, NULL, '2025-07-09 21:29:39', '2025-07-09 21:29:40'),
(659, 41, 1, NULL, '2025-07-09 21:29:39', '2025-07-10 00:31:02');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_amount` int(11) NOT NULL,
  `package_id` bigint(20) UNSIGNED NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `companyTax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `companyName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_user_id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `email`, `phone`, `address`, `total_amount`, `package_id`, `note`, `companyTax`, `companyName`, `order_user_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'truong', 'truongbackend@gmail.com', '12214', '1232', 21, 4, NULL, 'hewhehwqh', NULL, 1, 2, '2025-05-29 03:09:53', '2025-06-29 03:09:58'),
(2, 'truong', 'truongbackend@gmail.com', 'aaa', 'aa', 12, 3, NULL, NULL, NULL, 1, 2, '2025-06-29 03:11:10', '2025-06-29 03:11:21'),
(3, 'truong', 'truongbackend@gmail.com', '012402954', '12412', 21, 4, NULL, NULL, NULL, 1, 1, '2025-06-29 03:36:52', '2025-06-29 03:36:52'),
(4, 'truong', 'hhh@gmail.com', 'hêhhe', 'ưqewq', 21, 4, NULL, NULL, NULL, 25, 2, '2025-06-29 03:51:02', '2025-06-29 03:51:39'),
(5, 'truong', 'truong@gmail.com', '213', '123', 21, 4, NULL, NULL, NULL, 8, 1, '2025-06-29 21:57:24', '2025-06-29 21:57:24'),
(6, 'truong', 'truong@gmail.com', 'hehehe', '123', 1131, 7, NULL, NULL, NULL, 8, 1, '2025-06-29 22:23:03', '2025-06-29 22:23:03'),
(7, 'truong', 'truong@gmail.com', 'sad', 'ád', 21, 4, 'sda', NULL, NULL, 8, 1, '2025-06-29 22:48:49', '2025-06-29 22:48:49'),
(8, 'truong', 'truong@gmail.com', '213', '123', 21, 4, '123', NULL, NULL, 8, 1, '2025-06-29 22:50:06', '2025-06-29 22:50:06'),
(9, 'truong', 'truong@gmail.com', '123', '2131', 21, 4, '321', NULL, NULL, 8, 1, '2025-06-29 22:50:32', '2025-06-29 22:50:32'),
(10, 'truong', 'truong@gmail.com', '123', '3', 21, 4, '123', NULL, NULL, 8, 1, '2025-06-29 22:52:31', '2025-06-29 22:52:31'),
(11, 'truong', 'truong@gmail.com', '213', '3', 21, 4, '123', NULL, NULL, 8, 1, '2025-06-29 22:56:01', '2025-06-29 22:56:01'),
(12, 'truong', 'truong@gmail.com', '123', '2131', 21, 4, '23', NULL, NULL, 8, 1, '2025-06-29 22:58:51', '2025-06-29 22:58:51'),
(13, 'truong', 'truong@gmail.com', '03581155', 'mới', 21, 4, NULL, NULL, NULL, 8, 1, '2025-06-30 19:39:52', '2025-06-30 19:39:52'),
(14, 'truong', 'truong@gmail.com', '2421321', '123', 21, 4, '123', NULL, NULL, 8, 1, '2025-06-30 19:40:36', '2025-06-30 19:40:36'),
(15, 'có công ty', 'truong@gmail.com', '123123', '12', 21, 4, '123', '123213', '123123', 8, 1, '2025-06-30 19:41:55', '2025-06-30 19:41:55'),
(16, 'truon5555g', 'truong213214214@gmail.com', '213', '123', 1131, 7, '123', '213', '213', 8, 1, '2025-06-30 19:46:08', '2025-06-30 19:46:08'),
(17, 'truong', 'truong@gmail.com', '51252122', '214', 21, 4, 'sấ', 'công ty bividsaaa', 'công ty bividsaaa', 8, 1, '2025-06-30 23:13:59', '2025-06-30 23:13:59'),
(18, 'truong', 'truong@gmail.com', '21321', '21312', 1131, 7, NULL, '213123', '3213', 8, 1, '2025-06-30 23:18:57', '2025-06-30 23:18:57'),
(19, 'truong', 'truong@gmail.com', '213123', '123', 21, 4, '123', '123', '213', 8, 1, '2025-06-30 23:20:20', '2025-06-30 23:20:20'),
(20, 'truong', 'truong@gmail.com', '3213', '12312', 1131, 7, '4123', '213421', '12321', 8, 1, '2025-06-30 23:22:24', '2025-06-30 23:22:24');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `price` int(11) NOT NULL,
  `discould` decimal(5,2) NOT NULL,
  `default_packages` tinyint(1) DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `expiration_time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `created_at`, `updated_at`, `name`, `note`, `price`, `discould`, `default_packages`, `status`, `expiration_time`) VALUES
(3, '2025-06-08 19:12:28', '2025-06-12 09:34:41', 'truong', '21', 12, '12.00', 1, 1, '10'),
(4, '2025-06-08 19:57:02', '2025-06-12 09:34:41', 'base', NULL, 21, '12.00', 0, 1, '12'),
(7, '2025-06-22 19:23:31', '2025-06-22 19:23:31', 'a', '213', 1131, '21.00', 0, 1, '12');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'user.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(2, 'user.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(3, 'user.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(4, 'user.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(7, 'package.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(8, 'package.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(9, 'package.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(10, 'package.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(11, 'role.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(12, 'role.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(13, 'role.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(14, 'role.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(15, 'report.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(16, 'report.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(17, 'report.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(18, 'report.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(19, 'notification.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(20, 'notification.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(21, 'notification.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(22, 'notification.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(23, 'complaints.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(24, 'complaints.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(25, 'complaints.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(26, 'complaints.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(27, 'product.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(28, 'product.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(29, 'product.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(30, 'product.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(35, 'orders.create', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(36, 'orders.edit', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(37, 'orders.delete', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26'),
(38, 'orders.list', 'api', '2024-07-20 01:59:26', '2024-07-25 01:59:26');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_user_id` int(11) NOT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accounting_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_user_id`, `sku`, `accounting_code`, `product_name`, `unit`, `tax_rate`, `created_at`, `updated_at`) VALUES
(1, 0, 'dsfdsfds123123', 'gđsf', 'sadas', '2', '21', '2025-06-22 20:17:01', '2025-06-25 23:29:21'),
(387, 1, '3148238417', 'gđsf', 'sadas', '2', '21', '2025-06-22 20:17:01', '2025-06-22 20:41:20'),
(390, 1, 'a', 'a', 'a', 'a2', '12', '2025-06-25 21:50:00', '2025-06-25 21:50:00'),
(391, 1, '12321', '3213', '213', '2312', '1', '2025-06-25 21:52:39', '2025-06-25 21:52:39'),
(393, 1, 'GTJH002GR00', 'GTJH002', 'Bàn ủi hơi nước đứng  bàn ủi hơi nước đứng bàn là hơi nước, công suất 1800W, sử dụng cho cả gia đình, dễ dàng ủi phẳng nếp nhăn quần áo', 'Cái', '10', '2025-06-26 02:15:11', '2025-06-26 02:15:11'),
(394, 1, 'YYST001GY00', 'YYST001', 'Simplus Găng tay bàn ủi quần áo, đệm ủi bàn là chịu nhiệt, chống bỏng, chống thấm nước tiện lợi', 'Cái', '8', '2025-06-26 02:15:11', '2025-06-26 02:15:11'),
(395, 1, 'FURN_1118', 'DZGH002', 'Nồi lẩu điện cầm tay đa năng Simplus kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:15:11', '2025-06-26 02:15:11'),
(396, 1, 'XCQH001WB01', 'XCQH001', 'Máy hút bụi cầm tay Simplus Vaccum Cleaner Máy hút bụi gia đìn lực hút mạnh 16000Pa', 'Cái', '10', '2025-06-26 02:15:11', '2025-06-26 02:15:11'),
(397, 1, 'B0005XCQI001WB01', 'XCQI001', 'Máy hút bụi máy hút bụi gia đình  đa năng có dây lực hút mạnh 16000Pa dễ dàng hút lông thú cưng, nhỏ gọn, tiện lợi, hạn chế tiếng ồn, đi kèm 11 loại đầu cọ, hút bụi sàn, hút bụi giường, hút bụi rèm', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(398, 1, 'XCLX001WH00', 'XCLX001WH00', 'Simplus Bộ phận lọc của máy hút bụi được điều chỉnh phù hợp với máy hút bụi 001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(399, 1, 'GTJH002WH00', 'GTJH002', 'Bàn ủi hơi nước đứng  bàn ủi hơi nước đứng bàn là hơi nước, công suất 1800W, sử dụng cho cả gia đình, dễ dàng ủi phẳng nếp nhăn quần áo', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(400, 1, 'DDYS002GR01', 'DDYS002', 'Bàn chải điện Simplus Bàn chải đánh răng rửa mặt 2 trong 1 có thể sạc lại tự', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(401, 1, 'GTJH010WH00', 'GTJH010', 'Bàn là hơi nước cầm tay Simplus Bể nước lớn 250mL GTJH010', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(402, 1, 'JSQH002WH00', 'JSQH002', 'Bộ lọc nước tại vòi Simplus JSQH002 công nghệ 5 màng lọc', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(403, 1, 'SMZJ004', 'SMZJ004', 'Simplus Máy làm bánh mì Sandwish máy ăn sáng Máy làm bánh mì nướng bánh quế gia đình hai khay', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(404, 1, 'DZGH006WH01FZ', 'DZGH006', 'Nồi lẩu điện cầm tay đa năng Simplus 2L/1.5L DZGH006/002 kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(405, 1, 'GUOC002WD00', 'GUOC002', 'Xẻng gỗ chống dính xào nấu tiện lợi Simplus', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(406, 1, 'XCQH001WG01', 'XCQH001', 'Simplus Máy hút bụi có dây nhỏ gọn lực hút mạnh 16000PA dễ dàng hút lông thú cưng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(407, 1, 'KQZG004BK00', 'KQZG004', 'Nồi chiên không dầu Simplus dung tích lớn 5L điều khiển cảm ứng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(408, 1, 'E-COM06', 'GTJH012', 'Simplus Bàn Ủi Đứng 2 Trong 1 Công suất 2000W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(409, 1, 'GTJH001GR00', 'GTJH001', 'Bàn Là Hơi Nước Cầm Tay Simplus tiện lợi Dung tích nước 130ml công suất lớn 800W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(410, 1, 'DSLU001WH00', 'DSLU001', 'Máy nướng bánh mì sandwich mini Inssa, đa năng, tiện lợi, tiết kiệm thời gian máy nướng bánh đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(411, 1, 'GTJH009WH00', 'GTJH009', 'Simplus Bàn Ủi Hơi Nước Đứng Cầm Tay Đa Năng Công Suất 1800W, Phù Hợp Mọi Loại Vải', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(412, 1, 'GTJH006BL01', 'GTJH006', 'Bàn là Simplus Bàn ủi điện hơi nước cầm tay khô hơi nước kết hợp 2 trong 1 ủi phẳng hiệu quả', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(413, 1, 'DZGH003WH01', 'DZGH003', 'Nồi hấp Simplus nấu lẩu thích hợp cho 2-3 người, đa chức năng, hai nấc nhiệt điều chỉnh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(414, 1, 'GTJH012FZ01', 'GTJH012', 'Simplus Bàn là hơi nước Công suất lớn 1800w', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(415, 1, 'CMYH002WH00', 'CMYH002', 'Máy hút bụi giường nệm diệt khuẩn Simplus dùng để hút bụi giường hộ gia đình để loại bỏ mùi hôi và sạc thông minh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(416, 1, 'DRSH002GY00', 'DRSH002', 'Ấm đun nước siêu tốc (1.8L), lớp cách nhiệt chống bỏng, tự ngắt khi sôi', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(417, 1, 'KQZG007CW01', 'KQZG007', 'Simplus Nồi chiên không dầu Dung Tích Lớn 4L Air Fryers chiên nướng đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(418, 1, 'DRSH002WH00', 'DRSH002', 'Ấm đun nước siêu tốc (1.8L), lớp cách nhiệt chống bỏng, tự ngắt khi sôi', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(419, 1, 'GTJH008WH00', 'GTJH008', 'Bàn ủi hơi nước cầm tay Simplus tiện lợi mang theo ủi treo là hẳng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(420, 1, 'XCLX008WH00', 'XCLX008', 'Simplus Bộ phận lọc của máy hút bụi được điều chỉnh phù hợp với máy hút bụi 001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(421, 1, 'GTJH011WH00', 'GTJH011', 'Bàn ủi hơi nước cầm tay Simplus Quần áo 170ml Công suất lớn, Công suất cao 1200W GTJH011', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(422, 1, 'LLJH004GY00', 'LLJH004', 'Máy Xay Sinh Tố Simplus Máy xay sinh tố đa năng LLJH004 Dung Tích 600ml', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(423, 1, 'DDYS002PK01', 'DDYS002', 'Bàn chải điện Simplus Bàn chải đánh răng rửa mặt 2 trong 1 có thể sạc lại tự', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(424, 1, 'YSST-DDYS002PK01', 'DDYS002', 'Bàn chải điện Simplus Bàn chải đánh răng rửa mặt 2 trong 1 có thể sạc lại tự (Simplus Đầu bàn chải đánh răng DuPont 3D Chống nước IPX7 accessories Brush)', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(425, 1, 'DZGH002WH01', 'DZGH002', 'Nồi lẩu điện cầm tay đa năng Simplus không kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(426, 1, 'DZGH008WH00FZ01', 'DZGH008', 'Nồi điện đa năng Simplus DZGH008 dung tích 3L điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(427, 1, 'XCQH008GY01FZ01', 'XCQH008', 'Simplus Máy hút bụi có dây nhỏ gọn lực hút mạnh 16000PA dễ dàng hút lông thú cưng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(428, 1, 'LFSH002WH00', 'LFSH002', 'Simplus Quạt điều hòa hơi nước Quạt siêu mát điều khiển từ xa dung tích lớn 10L LFSH', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(429, 1, 'GTJH011PK00', 'GTJH011', 'Bàn ủi hơi nước cầm tay Simplus Quần áo 170ml Công suất lớn, Công suất cao 1200W GTJH011', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(430, 1, 'SMZJ001PK00', 'SMZJ001', 'Máy kẹp sandwich Inssa máy nướng bánh mì sandwich nướng bánh mì đa năng tiện dụng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(431, 1, 'CFLL002GYTS', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon tay cầm gỗ sồi chịu nhiệt cao chuyên dụng Vá Đặc', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(432, 1, 'XCQH008WB01FZ01', 'XCQH008', 'Simplus Máy hút bụi có dây nhỏ gọn lực hút mạnh 16000PA dễ dàng hút lông thú cưng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(433, 1, 'CFJH001', 'CFJH001', 'Máy sấy tóc đa chức năng Simplus 3 tốc độ điều chỉnh gió nóng / lạnh dụng cụ tạo kiểu mang đi du lịch 220V', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(434, 1, 'DFSH002WH00', 'DFSH002', 'Quạt Cây Đứng Simplus 16 inch công suất gió lớn,tiêu thụ điện năng thấp và tiết kiệm năng lượng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(435, 1, 'DCLU001WH00', 'DCLU001', 'Bếp từ đơn Simplus 1800W gia dụng đa năng, tiết kiệm không gian  Hàng chính hãng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(436, 1, 'DDJR003CW00', 'DDJR003', 'Máy xay thịt Simplus 1.8L đa năng, cối thủy tinh, 420 lưỡi thép không gỉ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(437, 1, 'LVSH001WH00', 'LVSH001', 'Simplus  Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(438, 1, 'GYZH001YL00', 'GYZH001', 'Giấy lót nồi chiên không dầu', 'Bịch', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(439, 1, 'CMYH001WH00', 'CMYH001', 'Máy hút bụi giường nệm diệt khuẩn Simplus dùng để hút bụi giường hộ gia đình để loại bỏ mùi hôi và sạc thông minh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(440, 1, 'DZGH006WH01-ZH', 'DZGH006', 'Nồi lẩu điện cầm tay đa năng Simplus 2L/1.5L DZGH006/002 kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(441, 1, 'DZGH002WH02FZ', 'DZGH002', 'Nồi lẩu điện cầm tay đa năng Simplus kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(442, 1, 'XCQH009GY01', 'XCQH009', 'Máy Hút Bụi Cầm Tay Không Dây Simplus 12000PA, Tốc Độ Cao , Lực Hút Mạnh, Hút Bụi Không Dây', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(443, 1, 'XCQH008GY01', 'XCQH008', 'Máy Hút Bụi Simplus 15000PA cho Gia Đình Nhỏ Lực Hút Mạnh Mẽ Máy Hút Bụi Làm Sạch', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(444, 1, 'KFJH006', 'KFJH006', 'Simplus Máy Pha Cà Phê Mini Tự KFJH006 Động Kiểu Mỹ Pha Nhỏ Giọt Máy Pha Trà Bình Pha Cà Phê', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(445, 1, 'GJBG001BL00', 'GJBG001', 'Khay đá Simplus Ice Tray GJBG001BL00', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(446, 1, 'KQZG004CW01', 'KQZG004', 'Nồi chiên không dầu Simplus dung tích lớn 5L điều khiển cảm ứng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(447, 1, 'DZGH007', 'DZGH007', 'Nồi lẩu điện đa năng Simplus Electric Multifunction Cooker', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(448, 1, 'LLJH005WH01', 'LLJH005', 'Simplus Máy Xay Sinh Tố Đa Chức Năng 1.25L Công suất lớn 380W 3 cối đa dụng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(449, 1, 'ZFBA002WP01', 'ZFBA002', 'Máy Duỗi Tóc  Simplus Máy Uốn Duỗi Tóc ZFBA002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(450, 1, 'SMZJ001GR00', 'SMZJ001', 'Máy kẹp sandwich Inssa máy nướng bánh mì sandwich nướng bánh mì đa năng tiện dụng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(451, 1, 'CFLL002GYGC', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon tay cầm gỗ sồi chịu nhiệt cao chuyên dụng Xẻng đặc', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(452, 1, 'CFLL002GYLC', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon tay cầm gỗ sồi chịu nhiệt cao chuyên dụng Vá Lỗ', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(453, 1, 'KQZG007GR01', 'KQZG007', 'Simplus Nồi chiên không dầu Dung Tích Lớn 4L Air Fryers chiên nướng đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(454, 1, 'GTJH001WH00', 'GTJH001', 'Bàn Là Hơi Nước Cầm Tay Simplus tiện lợi Dung tích nước 130ml công suất lớn 800W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(455, 1, 'DRSH005WH00', 'DRSH005', 'Ấm điện Siêu Tốc Thông Minh Cảm Ứng Simplus Công Suất 1500W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(456, 1, 'DKZP001WH00', 'DKZP001', 'Nồi lẩu nướng điện 2 ngăn Simplus đa năng dùng trong gia đình ký túc xá', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(457, 1, 'DZGH003WH01-ZH', 'DZGH003', 'Dòng nồi điện Simplus nấu lẩu thích hợp cho 2-3 người, đa chức năng, hai nấc nhiệt điều chỉnh kèm xửng hấp', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(458, 1, 'GTJH011WH00-ZH', 'GTJH011', 'Bàn ủi hơi nước cầm tay Simplus 1200w công suất lớn, ngăn chứa nước dung tích lớn 250ml', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(459, 1, 'KQZG011CW01', 'KQZG011', 'Nồi chiên không dầu Simplus Dung tích 5L', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(460, 1, 'SPJA001GY00', 'SPJA001', 'Đồ dùng nhà bếp - Simplus Kẹp gắp thức ăn Silicone SPJA001GR00', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(461, 1, 'KFJH004BK00', 'KFJH004', 'Máy pha cà phê Simplus pha cà phê nhỏ giọt Dung tích 600ml KFJH004', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(462, 1, 'KQZG007BK01', 'KQZG007', 'Simplus Nồi chiên không dầu Dung Tích Lớn 4L Air Fryers chiên nướng đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(463, 1, 'JFBA004WP01', 'JFBA004', 'Máy uốn tóc xoăn Simplus Máy uốn duỗi thẳng uốn xoăn ion âm công dụng kép không làm tổn thương tóc', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(464, 1, 'LLJH003GR00', 'LLJH003', 'Máy xay tỏi ớt cầm tay Simplus đa năng dễ dàng tháo lắp tiện dụng LLJH003', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(465, 1, 'XCLX002WH00', 'XCLX002', 'Simplus Bộ Phận lọc của máy hút bụi được điều chỉnh phù hợp với XCQI002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(466, 1, 'CFLL002WHGC', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon CFLL002- Xẻng Đặc', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(467, 1, 'HMJH001GR01', 'HMJH001', 'Máy nhồi, trộn bột đa năng Simplus dung tích lớn, dùng trong gia đình tiện dụng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(468, 1, 'DZGH002WH01FZ', 'DZGH002', 'Nồi lẩu điện cầm tay đa năng Simplus không kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(469, 1, 'ZENP004BL00', 'ZENP004', 'Simplus Miếng trải bàn silicone gia dụng tấm lót cách nhiệt chống bỏng  miếng lót bát lót nồi bếp bát', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(470, 1, 'XCQH002WH00', 'XCQH002', 'Máy hút bụi Simplus cầm tay có dây 12000Pa XCQH002 công suất cao 300W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(471, 1, 'LFSH001WH00', 'LFSH001', 'Simplus Quạt điều hòa hơi nước Quạt siêu mát điều khiển từ xa dung tích lớn 10L LFSH', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(472, 1, 'ZFBA001PK01', 'ZFBA001', 'Máy uốn tóc Simplus Máy uốn và duỗi tóc xoăn 2in1 màn hình thời gian thực LCD tấm ZFBA', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(473, 1, 'YSST-DDYS002GR01', 'DDYS002', 'Bàn chải điện Simplus Bàn chải đánh răng rửa mặt 2 trong 1 có thể sạc lại tự (Simplus Đầu bàn chải đánh răng DuPont 3D Chống nước IPX7 accessories Brush)', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(474, 1, 'DFBA005WH01', 'DFBA005', 'Nồi cơm điện mini đa năng thích hợp cho 1-2 người. Chức năng hẹn 24 giờ Bảo vệ kép chống cháy khô và quá nhiệt', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(475, 1, 'GTJH008WH00-ZH', 'GTJH008', 'Bàn ủi hơi nước cầm tay Simplus 1200w công suất lớn, ngăn chứa nước dung tích lớn 250ml', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(476, 1, 'SMZJ003WH00', 'SMZJ003', 'Simplus Máy Nướng Bánh Mì Sandwich SMZJ003', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(477, 1, 'CFJH004BK00', 'CFJH004', 'Máy Sấy Tóc Ion Âm Simplus 1000W, Sấy Hai Chiều Nóng Lạnh Nhanh Khô Không Xơ Tóc, Nhỏ Gọn Tiện Lợi', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(478, 1, 'DSLU006WH00', 'DSLU006', 'Máy nướng bánh mì Simplus Công suất lớn 800W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(479, 1, 'GTJH005BL01', 'GTJH005', 'Simplus Bàn ủi khô bàn ủi điện cầm tay gia dụng Công Suất 1300W Dry Iron', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(480, 1, 'ZFBA002GY01', 'ZFBA002', 'Máy Duỗi Tóc  Simplus Máy Uốn Duỗi Tóc ZFBA002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(481, 1, 'DDYS001BL01', 'DDYS001', 'Bàn chải điện Simplus Sonic lông DuPont công nghệ sóng âm rung dành cho người lớn, chải sạch trắng răng, bảo vệ nướu', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(482, 1, 'GTJH011PK00-ZH', 'GTJH011', 'Bàn ủi hơi nước cầm tay Simplus 1200w công suất lớn, ngăn chứa nước dung tích lớn 250ml', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(483, 1, 'KQZG012CW01', 'KQZG012', 'Nồi chiên không dầu Simplus Dung tích lớn 5.5L  KQZG012', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(484, 1, 'HFBJ001WH00', 'HFBJ001', 'SMZJ005', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(485, 1, 'DDYS002WH01', 'DDYS002', 'Bàn chải điện Simplus Bàn chải đánh răng rửa mặt 2 trong 1 có thể sạc lại tự', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(486, 1, 'DFSH007WH00', 'DFSH007', 'Quạt cầm tay mini Simplus DFSH007 Dung lượng Pin 2000mah', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(487, 1, 'DZGH007WH01-ZH', 'DZGH007', 'Nồi lẩu điện đa năng Simplus Electric Multifunction Cooker kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(488, 1, 'ZFBA002WB01', 'ZFBA002', 'Máy Duỗi Tóc  Simplus Máy Uốn Duỗi Tóc ZFBA002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(489, 1, 'GUOJ010CR01', 'GUOJ010', 'Vanilla Series Nồi nấu đá Simplus bếp chống dính gia đình bếp gas phù hợp với chảo rán và rán đa năng 24cm', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(490, 1, 'GUOJ012CR01', 'GUOJ012', 'Nồi chống dính Simplus đá Maifan 4L size 24cm dòng nồi Vanilla Series dùng cho bếp từ và ga', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(491, 1, 'CFLL002WHTS', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon CFLL002- Vá Đặc', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(492, 1, 'XCQI003WB01', 'XCQI003', 'Máy hút bụi không dây Simplus nhỏ gọn với lực hút mạnh 9000PA dễ dàng hút lông thú cưng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(493, 1, 'SMZJ001WH00', 'SMZJ001', 'Máy kẹp sandwich Inssa máy nướng bánh mì sandwich nướng bánh mì đa năng tiện dụng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(494, 1, 'GTJH009FZ', 'GTJH009', 'Bàn ủi hơi nước đứng Simplus 1800w là phẳng tiện lợi', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(495, 1, 'SPJA001WH00', 'SPJA001', 'Đồ dùng nhà bếp - Simplus Kẹp gắp thức ăn Silicone SPJA001GR00', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(496, 1, 'XCQH008WB01', 'XCQH008', 'Máy Hút Bụi Simplus 15000PA cho Gia Đình Nhỏ Lực Hút Mạnh Mẽ Máy Hút Bụi Làm Sạch', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(497, 1, 'LLJH004-ZH', 'LLJH004', 'Máy xay sinh tố Simplus đa chức năng lợi xay nhanh các loại nước trái cây', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(498, 1, 'CFJH005WH00', 'CFJH005', 'Máy sấy tóc Simplus Công suất cao 1800W CFJH005 gió nóng và lạnh điều chỉnh 3 tốc độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(499, 1, 'JFBA005', 'JFBA005', 'Máy Uốn Tóc Xoăn Tự Động Simplus 32mm Xoay Một Nút Uốn Tự Động', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(500, 1, 'JFBA006', 'JFBA006', 'Máy uốn xoăn sóng 32MM Simplus JFBA006 không hại tóc', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(501, 1, 'GTJH005PP01', 'GTJH005', 'Simplus Bàn ủi khô bàn ủi điện cầm tay gia dụng Công Suất 1300W Dry Iron', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(502, 1, 'CFLL002WHYS', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon CFLL002- Chổi quét dầu', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(503, 1, 'GTJH012WH01FZ', 'GTJH012', 'Bàn ủi hơi nước đứng Simplus 1800w là phẳng tiện lợi', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(504, 1, 'SLFH001TR01', 'SLFH001', 'Bộ 3 Hộp thực phẩm chữ nhật Simplus (Bộ 500/800/1100ml) SLFH001', 'Bộ', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(505, 1, 'GUOJ013CR01', 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(506, 1, 'LLJH005-ZH', 'LLJH005', 'Máy xay sinh tố Simplus đa chức năng lợi xay nhanh các loại nước trái cây', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(507, 1, 'KQZG008BK01', 'KQZG008', 'Nồi chiên không dầu Simplus dung tích lớn 5L Nồi chiên không dầu tự động', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(508, 1, 'JFBA007WB01', 'JFBA007', 'Máy uốn tóc Simplus 32MM JFBA007', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(509, 1, 'DZGH002WH01-ZH', 'DZGH002', 'Nồi lẩu điện cầm tay đa năng Simplus không kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(510, 1, 'DZEG001CW01', 'DZEG001', 'Nồi hấp điện đa năng 6in1 Simplus Dung tích lớn 12L', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(511, 1, 'KFJH005BK00', 'KFJH005', 'Máy Pha Cà Phê Simplus 1.2L Máy Cà Phê Kiểu Mỹ Hoàn Toàn Tự Động', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(512, 1, 'MDJH001CW00', 'MDJH001', 'Máy xay hạt cà phê Simplus Máy xay điện gia dụng Máy xay cà phê tự động dạng nhỏ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(513, 1, 'GTJH010WH00-ZH', 'GTJH010', 'Bàn ủi hơi nước cầm tay Simplus 1200w công suất lớn, ngăn chứa nước dung tích lớn 250ml', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(514, 1, 'KQZG007GR00', 'KQZG007', 'Nồi chiên không dầu Simplus OilFree Air Fryers Dung Tích lớn 4L', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(515, 1, 'GUOJ024CW01', 'GUOJ024', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán(Nồi hầm)', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(516, 1, 'GUOJ022CW00', 'GUOJ022', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán(Chảo chiên 18cm)', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(517, 1, 'DFSH006WH00', 'DFSH006', 'Quạt cây Simplus 16 inch DFSH006 sức gió lớn, tiếng ồn thấp, tiết kiệm năng lượng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(518, 1, 'DZGH002WH02-ZH', 'DZGH002', 'Nồi lẩu điện cầm tay đa năng Simplus kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(519, 1, 'DZGH006', 'DZGH006', 'Nồi lẩu điện đa năng có xửng hấp Simplus Electric Multi-function Cooker', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(520, 1, 'JBBA002WH00', 'JBBA002', 'Máy nấu ăn cầm tay Simplus Máy đánh trứng làm bánh tại nhà JBBA002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(521, 1, 'CFLL002WHZH', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon CFLL002', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(522, 1, 'DZGH008WH00-ZH', 'DZGH008', 'Dòng nồi điện Simplus nấu lẩu thích hợp cho 2-3 người, đa chức năng, hai nấc nhiệt điều chỉnh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(523, 1, 'KQZG004WH01', 'KQZG004', 'Nồi chiên không dầu Simplus dung tích lớn 5L điều khiển cảm ứng  Hàng chính hãng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(524, 1, 'KFLZ001WD01', 'KFLZ001', 'Giấy lọc cà phê Simplus V40', 'Bịch', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(525, 1, 'LLJH003GR00FZ01', 'LLJH003', 'Máy nghiền tỏi Simplus LSQH001', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(526, 1, 'ZENP004GR00', 'ZENP004', 'Simplus Miếng trải bàn silicone gia dụng tấm lót cách nhiệt chống bỏng  miếng lót bát lót nồi bếp bát', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(527, 1, 'KQZG004CW01FZ02', 'KQZG004', 'Nồi chiên không dầu dùng cho gia đình đa chức năng Simplus. Nồi chiên điện thông minh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(528, 1, 'KQZG004BK01FZ01', 'KQZG004', 'Nồi chiên không dầu dùng cho gia đình đa chức năng Simplus', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(529, 1, 'CFLL002WHLC', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon CFLL002- Vá Lỗ', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(530, 1, 'KFJH004WH00', 'KFJH004', 'Máy pha cà phê Simplus pha cà phê nhỏ giọt Dung tích 600ml KFJH004', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(531, 1, 'ZZJH004WH00', 'ZZJH004', 'Simplus Máy Xay Sinh Tố Cầm Tay 300ML,Sạc Pin USB, Cối Xay Đa Chức Năng Công Suất 40W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(532, 1, 'TZCH001WH01', 'TZCH001', 'Simplus Cân Điện Tử TZCH001 Cân Sức Khỏe Sử Dụng Gia Đình Mặt Kính Sang Trọng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(533, 1, 'GUOJ010GY01', 'GUOJ010', 'Vanilla Series Nồi nấu đá Simplus bếp chống dính gia đình bếp gas phù hợp với chảo rán và rán đa năng 24cm', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(534, 1, 'GUOJ020FZ', 'GUOJ020', 'Nồi nhỏ đun sữa, nấu mì Dá Maifan chống dính Simplus 18CM', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(535, 1, 'CSQH001GY00', 'CSQH001', 'Simplus Khăn treo bóng lau tay Chenille giẻ thấm nước dày khô nhanh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(536, 1, 'GUOJ016GY01', 'GUOJ016', 'Chảo chống dính Simplus Đường kính 24cm GUOJ016', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(537, 1, 'DDJR003', 'DDJR003', 'Máy xay thịt Simplus 1.8L đa năng, cối Inox 304', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(538, 1, 'GUOJ025CW01', 'GUOJ025', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán(Chảo xào sâu lòng)', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(539, 1, 'GTJH014WB01', 'GTJH014', 'Bàn ủi hơi nước đứng Simplus GTJH014 Khay nước trong suốt 1.8L Là đứng là nằm 2 trong 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(540, 1, 'KQZG005BK01', 'KQZG005', 'Nồi chiên không dầu Simplus kiểu mới công suất lớn 5L, đa năng thông minh KQZG005', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(541, 1, 'BBJH001WH00', 'BBJH001', 'Máy bào đá mini bằng tay tiện lợi siêu nhanh, siêu mịn', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(542, 1, 'CFJH003WH00', 'CFJH003', 'Simplus Máy Sấy Tóc công xuất lớn 1800W CFJH003', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(543, 1, 'ZZJH006WH00', 'ZZJH006', 'Máy Xay Sinh Tố Cầm Tay Simplus Dung tích 400ml ZZJH006', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(544, 1, 'CFJH003PK00', 'CFJH003', 'Simplus Máy Sấy Tóc công xuất lớn 1800W CFJH003', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(545, 1, 'KQZG003BK00', 'KQZG003', 'Nồi chiên không dầu  cảm ứng thông minh, đa năng, dung tích 5.5 lít, menu cài sẵn, làm nóng nhanh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(546, 1, 'SPJAWH001', 'SPJAWH001', 'Đồ dùng nhà bếp - Kẹp gắp thức ăn bằng Silicon CFLL002 Bộ 4', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(547, 1, 'CFLL002GY00', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon tay cầm gỗ sồi chịu nhiệt cao chuyên dụng- Bộ 4 món Vá đặc, Vá lỗ, Xẻng đặc, Chổi quét dầu', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(548, 1, 'CFLL002GYYS', 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon tay cầm gỗ sồi chịu nhiệt cao chuyên dụng Chổi quét dầu', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(549, 1, 'ZZJH006', 'ZZJH006', 'Máy xay sinh tố cầm tay Simplus,ZZJH005/006 mini đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(550, 1, 'ZZJH004', 'ZZJH004', 'Máy xay sinh tố cầm tay Simplus,ZZJH005/006 mini đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(551, 1, 'LSQH001GR00', 'LSQH001', 'Máy trộn gia đình Simplus Máy nghiền tỏi LSQH001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(552, 1, 'DZGH007WH01FZ', 'DZGH007', 'Nồi lẩu điện đa năng Simplus Electric Multifunction Cooker kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(553, 1, 'KQZG009BK01', 'KQZG009', 'Simplus Nồi chiên không dầu KQZG009 Dung tích lớn 5L cảm ứng thông minh đa chức năngg', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(554, 1, 'CUSH004WH01', 'CUSH004', 'Máy Hút Ẩm Simplus Dung tích 1L Dehumidifiers CUSH004', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(555, 1, 'CYQH001WH00', 'CYQH001', 'Máy Tăm Nước Simplus Tiện Lợi,Máy vệ Sinh Răng Miệng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(556, 1, 'GTJH014FZ01', 'GTJH014', 'Simplus Bàn là hơi nước Công suất lớn 1800w  Hàng chính hãng GTJH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(557, 1, 'DDYS007WH00', 'DDYS007', 'Bàn Chải Điện Simplus DDYS007', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(558, 1, 'CFJH004WP00', 'CFJH004', 'Máy sấy tóc Simplus Chống Hư Tổn 1000W CFJH004 Sấy Nóng Nhanh Khô', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(559, 1, 'KQZG007BK01FZ02', 'KQZG007', 'Nồi chiên không dầu dùng cho gia đình đa chức năng Simplus. Nồi chiên điện thông minh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(560, 1, 'XCQH010', 'XCQH010', 'Máy hút bụi không dây Simplus màn hình điện tử lực hút 13000PA kim loại lọc hepa F9 lọc XCQH010', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(561, 1, 'CMYH003WH01', 'CMYH003', 'Máy Hút Bụi Giường Nệm Không Dây Simplus Công Suất 7000PA CMYH003', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(562, 1, 'ZZJH005CW00', 'ZZJH005', 'Máy vắt cam Simplus Dung tích lớn 750ml ZZJH005', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(563, 1, 'XCQH008GY02', 'XCQH008', 'Máy hút bụi Simplus XCQH001/008 có dây nhỏ gọn lực hút mạnh 16590PA', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(564, 1, 'XCQH008WB02', 'XCQH008', 'Máy hút bụi Simplus XCQH001/008 có dây nhỏ gọn lực hút mạnh 16590PA', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(565, 1, 'GUOJ020CW01', 'GUOJ020', 'Nồi tuyết Chống Dính Đáy Sâu Đa Dụng, Phù Hợp Nhiều Kiểu Bếp, Nồi Hâm Sữa, Nấu Đồ Ăn Dặm Nấu Mì', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(566, 1, 'DCLU002BK00', 'DCLU002', 'Bếp hồng ngoại cơ Simplus', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(567, 1, 'CMYH002WH00-ZH', 'CMYH002', 'Máy hút bụi giường nệm diệt khuẩn Simplus dùng để hút bụi giường hộ gia đình để loại bỏ mùi hôi và sạc thông minh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(568, 1, 'DKXH005CW01', 'DKXH005', 'Lò nướng Simplus  Dung tích lớn 12L  Lò nướng đa chức năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(569, 1, 'XCLX-CMYH001WH00', 'XCLX-CMYH001', 'Simplus Bộ phận lọc của máy hút bụi được điều chỉnh phù hợp với máy hút bụi 001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(570, 1, 'CFJH001GY00', 'CFJH001', 'Máy sấy tóc đa chức năng Simplus 3 tốc độ điều chỉnh gió nóng / lạnh dụng cụ tạo kiểu mang đi du lịch 220V', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(571, 1, 'JFBA007WP01', 'JFBA007', 'Máy uốn tóc Simplus 32MM JFBA007', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(572, 1, 'DFBA004WH01', 'DFBA004', 'Nồi áp suất điện Simplus 5L Áp suất cao 70 kpa DFBA005 Công suất 900W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(573, 1, 'XCQH004GY00', 'XCQH004', 'Máy hút bụi không dây cầm tay Simplus lực hút mạnh 12000PA công suất cao, lõi lọc HEPA XCQH004', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(574, 1, 'ZENP003MX00', 'ZENP003', 'Simlus Stickers quà tặng', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(575, 1, 'JSQH002', 'JSQH002', 'Bộ lọc nước tại vòi Simplus JSQH002 công nghệ 5 màng lọc', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(576, 1, 'KFJH010BK00', 'KFJH010', 'Máy pha cà phê Americano Simplus Nâng cấp Dung tích lớn 1.2L', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(577, 1, 'CMYH001WH00-ZH', 'CMYH001', 'Máy hút bụi giường nệm diệt khuẩn Simplus dùng để hút bụi giường hộ gia đình để loại bỏ mùi hôi và sạc thông minh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(578, 1, 'KQZG004BK00FZ02', 'KQZG004', 'Nồi chiên không dầu dùng cho gia đình đa chức năng Simplus', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(579, 1, 'KQJH004WH00', 'KQJH004', 'Máy lọc không khí Simplus KQJH004 Khử trùng gia đình, Loại bỏ bụi mịn', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(580, 1, 'KFJH007', 'KFJH007', 'Máy pha cà phê Simplus KFJH007 Đánh bọt sữa 20Bar Dung tích 1.4L', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(581, 1, 'KQZG005BK01FZ02', 'KQZG005', 'Nồi chiên không Simplus KQZGZH dầu dùng cho gia đình đa chức năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(582, 1, 'LVXI-LVSH001WH00', 'LVXI-LVSH001', 'Lõi lọc Bình lọc nước Simplus LVXI-LVSH001WH00', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(583, 1, 'ZHGUOJXC03B', 'ZHGUOJXC03B_', 'chảo chống dính Bộ nồi chảo đá chống dính màu Vani cao cấp INSSA chính hãng dùng cho bếp từ Chảo chống dính cao cấp', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(584, 1, 'DFSH004WH00', 'DFSH004', 'Quạt gấp gọn Simplus 8 inch, sạc usb không dây, điều chỉnh được độ cao, để bàn, xách tay', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(585, 1, 'KQZG010WH01', 'KQZG010', 'Simplus Nồi chiên không dầu KQZG010 Dung tích 4L', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(586, 1, 'KQKX001BK00', 'KQKX001', 'Lò Nướng Không Khí Simplus 12L, Lò Nướng kiêm Nồi Chiên Không Dầu Đa Chức Năng  AIR FRYER OVEN', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(587, 1, 'CFJH006WH01', 'CFJH006', 'Máy Sấy Tóc Simplus 200 triệu ion âm CFJH006', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(588, 1, 'KQZG004CW01FZ01', 'KQZG004', 'Nồi chiên không dầu Simplus kiểu mới công suất lớn 5L, đa năng thông minh KQZG005', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(589, 1, 'DKXH006CW01', 'DKXH006', 'Lò nướng điện  Simplus DKXH006 Dung tích lớn 30L', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(590, 1, 'CUSH002WH00', 'CUSH002', 'Máy Hút Ẩm Simplus Dung Tích lớn 2.5L màn hình LCD', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(591, 1, 'XXHE-CUSH002WH00', 'XXHE-CUSH002', 'Simplus Hộp hương liệu thích ứng với máy hút ẩm CUSH002WH00', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(592, 1, 'JSQH001WH01', 'JSQH001', 'Máy lọc nước siêu lọc Simplus Uống trực tiếp tại nhà máy', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(593, 1, 'CFJH006PK01', 'CFJH006', 'Máy Sấy Tóc Simplus 200 triệu ion âm CFJH006', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(594, 1, 'GUOJ029', 'GUOJ029', 'Bộ nồi chảo Suit Simplus Chảo sữa 18cm, Chảo rán 20cm, Chảo rán 26cm - GUOJ0029', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(595, 1, 'NFJH002RD00', 'NFJH002', 'Máy Sưởi Mini Simplus Bàn làm việc nhỏ máy sưởi gia đình 2000W NFJH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(596, 1, 'TZCH002WH00', 'TZCH002', 'Simplus Cân Điện Tử TZCH001 Cân Sức Khỏe Sử Dụng Gia Đình Mặt Kính Sang Trọng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(597, 1, 'ZZJH002-ZH', 'ZZJH002', 'Máy xay sinh tố Simplus ZZJH-ZH đa chức năng tiện lợi xay nhanh các loại nước trái cây', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(598, 1, 'KQZG016', 'KQZG016', 'Nồi chiên không dầu Simplus Dung Tích Lớn 6L KQZG016', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(599, 1, 'XCLX-CMYH002WH00', 'XCLX-CMYH002WH00', 'Simplus Bộ phận lọc của máy hút bụi được điều chỉnh phù hợp với máy hút bụi 001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(600, 1, 'ZFBA001GY01', 'ZFBA001', 'Máy sấy tóc đa chức năng Simplus 3 tốc độ điều chỉnh gió nóng / lạnh dụng cụ tạo kiểu mang đi du lịch 220V', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(601, 1, 'LVSH001+LVXI02', 'LVSH001', 'Simplus  Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(602, 1, 'KQZG016BK00', 'KQZG016', 'Nồi chiên không dầu Simplus Dung tích lớn 5.5L  KQZG012', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(603, 1, 'CFJH007WH00', 'CFJH007', 'Máy sấy tóc Simplus Công suất cao 1800W CFJH007/005', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(604, 1, 'LVXI-JSQH002WH00', 'LVXI-JSQH002', 'Lõi lọc Bình lọc nước Simplus LVXI-LVSH001WH00', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(605, 1, 'SMZJ004WH00', 'SMZJ004', 'Simplus Máy làm bánh mì Sandwish SMZJ004 Chảo thay thế', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(606, 1, 'ZENP017PK00', 'ZENP017', 'Simplus Túi đựng đồ du lịch ZENP017 di động Có thể tháo rời', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(607, 1, 'DDJR004WH00', 'DDJR004', 'Máy xay thịt Simplus (1.8L), cối thủy tinh, 420 lưỡi thép không gỉ DDJR003', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(608, 1, 'KQZG007GR00FZ02', 'KQZG007', 'Nồi chiên không dầu dùng cho gia đình đa chức năng Simplus. Nồi chiên điện thông minh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(609, 1, 'KQZG014WH01', 'KQZG014', 'Nồi chiên không dầu Simplus Dung tích lớn 5L KQZG015', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(610, 1, 'GTJH014WY01', 'GTJH014', 'Simplus Bàn là hơi nước Công suất lớn 1800w - Hàng chính hãng GTJH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(611, 1, 'CFJS001WH01', 'CFJS001', 'Simplus Đồng Hồ Bấm Giờ Điện Tử, Hẹn Giờ Nhà Bếp, Đồng Hồ Đếm Ngược Cho Học Sinh  CFJH001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(612, 1, 'CUSH001WH00', 'CUSH001', 'Máy Hút Ẩm Simplus CUSH001 Bình chứa nước 600ml', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(613, 1, 'DDJR001WH00', 'DDJR001', 'Máy xay thịt đa năng INSSA dung tích lớn 2L nâng cấp bốn lưỡi dao ?inox, tốc độ nhanh, tiết kiệm thời gian DDJR001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(614, 1, 'DDJR002SS00', 'DDJR002', 'Máy xay thịt đa năng Inssa, chất liệu inox và thủy tinh, dung tích lớn 2L, máy nghiền thịt, rau tốc độ cao', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(615, 1, 'DDJR003WH00', 'DDJR003', 'Máy xay thịt đa năng Simplus, chất liệu inox và thủy tinh, dung tích lớn 1.8L, máy nghiền thịt, rau tốc độ cao, âm thanh nhỏ, hoàn toàn tự động', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(616, 1, 'B0001DDYS002GR01', 'DDYS002', 'Bàn chải đánh răng điện Simplus rửa mặt và đánh răng 2 trong 1 có thể sạc lại không sợ bị thấm nước - DDYS002', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(617, 1, 'B0001DDYS002PK01', 'DDYS002', 'Bàn chải đánh răng điện Simplus rửa mặt và đánh răng 2 trong 1 có thể sạc lại không sợ bị thấm nước - DDYS002', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(618, 1, 'B0001DDYS002WH01', 'DDYS002', 'Bàn chải đánh răng điện Simplus rửa mặt và đánh răng 2 trong 1 có thể sạc lại không sợ bị thấm nước - DDYS002', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(619, 1, 'DDYS001PK01', 'DDYS001', 'Bàn chải điện Simplus Sonic lông DuPont công nghệ sóng âm rung dành cho người lớn, chải sạch trắng răng, bảo vệ nướu', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(620, 1, 'B0004DSLU002WH00', 'DSLU002', 'Máy nướng bánh mì 750W máy làm đồ ăn sáng mini, đa năng, tự động', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(621, 1, 'B0004DSLU002WH00FZ01', 'DSLU002', 'Máy nướng bánh mì sandwich mini Inssa, đa năng, tiện lợi, tiết kiệm thời gian máy nướng bánh đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(622, 1, 'DSLU003CR01', 'DSLU003', 'Máy nướng bánh mì sandwich Inssa đa năng, hai ngăn, kèm giá nướng, cho bữa sáng tiện lợi, tiết kiệm thời gian máy nướng bánh đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(623, 1, 'DSLU003CR01FZ02', 'DSLU003', 'Máy nướng bánh mì sandwich mini Inssa, đa năng, tiện lợi, tiết kiệm thời gian máy nướng bánh đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(624, 1, 'DZGH002', 'DZGH002', 'Simplus Nồi hấp điện ẩu điện đa năng Dung tích 1.5L', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(625, 1, 'DZGH006WH01', 'DZGH006', 'Nồi lẩu điện cầm tay đa năng Simplus 2L/1.5L không kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(626, 1, 'DZGH008WH00', 'DZGH008', 'Nồi Điện Đa Năng Chống Dính Simplus 3L, Hai Nấc Nhiệt Độ, Nồi Lẩu Mini Điện Đa Năng Xào Nấu', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(627, 1, 'DZGH003WH02', 'DZGH003', 'Simplus Nồi hấp điện ẩu điện đa năng Dung tích 1.5L DZGH003', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(628, 1, 'B0002GTJI001GR00', 'GTJI001', 'Bàn ủi hơi nước cầm tay  tiện lợi khi mang đi du lịch, công tác, dễ dàng ủi phẳng nếp nhắn quần áo, hệ thống bảo vệ chống cháy  Hàng chính hãng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(629, 1, 'GTJH012WH01', 'GTJH012', 'Bàn Ủi Hơi Nước Đứng INSSA Bàn Là Hơi Nước Đa Dụng 2 Trong 1 Là Đứng Là Nằm GTJH012WH01', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(630, 1, 'GTJI001GR00', 'GTJI001', 'Bàn ủi hơi nước cầm tay  tiện lợi khi mang đi du lịch, công tác, dễ dàng ủi phẳng nếp nhắn quần áo, hệ thống bảo vệ chống cháy  Hàng chính hãng bàn là hơi nước cầm tay', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(631, 1, 'GUOJ005PP01', 'GUOJ005', 'Chảo chống dính INNSA dùng cho bếp từ, ga', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(632, 1, 'GUOJ005PP01FZ01', 'GUOJ005', 'Bộ nồi chảo chống dính đỏ cherry INSSA bộ nồi dùng cho bếp từ, ga nồi ăn dặm, nồi hầm, chảo bếp t', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(633, 1, 'GUOJ007PP01', 'GUOJ007', 'Nồi hầm nấu canh chống dính INSSA, dung tích lớn 5L, dùng được cho các loại bếp ga, từ, dùng cho gia đình GUOJ007', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(634, 1, 'GUOJ008PP01', 'GUOJ008', 'Chảo sâu lòng chống dính đa năng INSSA dùng được cho bếp từ, gas cỡ lớn 28cm, xào nấu thoải mái, tiện dụng trong gia đìn', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(635, 1, 'GUOJ009PP01', 'GUOJ009', 'Nồi nấu thức ăn bổ sung cho bé INSSA sâu lòng chống dính tiện lợi nấu bột dùng được cho bếp từ, ga', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(636, 1, 'GUOJ010CW01FZ01', 'GUOJ010', 'Bộ nồi chảo đá chống dính màu Vani cao cấp INSSA chính hãng, dùng cho bếp từ, ga', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(637, 1, 'GUOJ010GY01FZ01', 'GUOJ010', 'Bộ nồi chảo đá chống dính màu Vani cao cấp INSSA chính hãng, dùng cho bếp từ, ga', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(638, 1, 'GUOJ011CR01', 'GUOJ011', 'Chảo đá Maifan chống dính Inssa, chiên xào 2 trong 1, dùng được cho bếp ga, bếp từ, màu trắng 28CM', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(639, 1, 'GUOJ011CR01FZ01', 'GUOJ011', 'Nồi chảo đá chống dính màu Vani cao cấp INSSA chính hãng, dùng cho bếp từ, ga(Chảo xào)', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(640, 1, 'GUOJ011CW01FZ01', 'GUOJ011', 'Nồi chảo đá chống dính màu Vani cao cấp INSSA chính hãng, dùng cho bếp từ, ga(Chảo xào)', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(641, 1, 'GUOJ012CR00', 'GUOJ012', 'Nồi đá Maifan hầm nấu chống dính INSSA dung tích lớn 4L, nắp kính trong suốt, dùng được cho bếp từ, ga', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(642, 1, 'GUOJ012CR00FZ01', 'GUOJ012', 'Nồi chảo đá chống dính màu Vani cao cấp INSSA chính hãng, dùng cho bếp từ, ga(Chảo hầm nấu)', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(643, 1, 'GUOJ012CW00', 'GUOJ012', 'Bộ nồi Nồi đá Maifan hầm nấu chống dính INSSA dung tích lớn 4L, nắp kính trong suốt, dùng được cho bếp từ, ga', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(644, 1, 'GUOJ013CR01FZ01', 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(645, 1, 'GUOJ013CW01', 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(646, 1, 'GUOJ016GY01FZ01', 'GUOJ016', 'Simplus Nồi chống dính, bếp từ, bếp gas, dụng cụ nấu ăn chống dính chuyên dụng, chảo đa năng  chảo chiên gia dụng bộ nồi chảo chống dính', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(647, 1, 'GUOJ017GY01', 'GUOJ017', '24CM Nồi nấu canh chống dính có nắp đậy Tay cầm chống trầy xước Dụng cụ nấu ăn tốt cho sức khỏe, bếp từ không chứa  PFOA', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(648, 1, 'GUOJ017GY01FZ01', 'GUOJ017', 'Inssa Bộ nồi Nồi chống dính, bếp từ, bếp gas, dụng cụ nấu ăn chống dính chuyên dụng, chảo đa năng  chảo chiên gia dụng bộ nồi chảo chống dính', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(649, 1, 'GUOJ018GY01', 'GUOJ018', 'Chảo chống dính  28CM Chảo sâu lòng chảo có nắp đậy Tay cầm chống ghỉ Dụng cụ nấu ăn lành mạnh không chứaPFOA', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(650, 1, 'GUOJ019GY01', 'GUOJ019', 'Nồi ủ sữa 18cm có nắp bếp từ bếp điện từ gốm sứ  nồi nhỏ sử dụng cho gia đình', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(651, 1, 'GUOJ019GY01FZ01', 'GUOJ019', 'Inssa Bộ nồi Nồi chống dính, bếp từ, bếp gas, dụng cụ nấu ăn chống dính chuyên dụng, chảo đa năng  chảo chiên gia dụng bộ nồi chảo chống dính', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(652, 1, 'GUOJ020CR01', 'GUOJ020', 'Nồi tuyết 18 / 20cm, nồi nấu Nhật, nồi sữa, nồi bổ sung thức ăn cho bé, dùng được cho 23 người, nồi chống dính tay cầm vân gỗ, nồi nấu có nắp đậy', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(653, 1, 'GUOJ021CW01', 'GUOJ021', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán (Nồi nấu bột)', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(654, 1, 'GUOJ009PP01A', 'GUOJ009', 'Nồi nấu cháo bột Simplus cho bé chống dính sâu lòng 18cm dùng được cho bếp từ và ga', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(655, 1, 'GYZH001YL01', 'GYZH001', 'Giấy lót nồi chiên không dầu', 'Bịch', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(656, 1, 'B0003KQZG001BK01', 'KQZG001', 'Nồi chiên không dầu Inssa kiểu mới 5.5L đa chức năng KQZG001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(657, 1, 'KQZG002BL01', 'KQZG002', 'Nồi chiên không dầu 5L INSSA nồi chiên đa năng, công suất lớn 1300W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(658, 1, 'KQZG004BBK01FZ01', 'KQZG004', 'Nồi Chiên Không Dầu Simplus 5L Bản Cơ Núm Vặn, Công Suất 1300W, Bếp Chiên Không Khí Dung Tích Lớn, Chiên Nướng Hâm Nóng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(659, 1, 'KQZG004BCW01FZ01', 'KQZG004', 'Nồi Chiên Không Dầu Simplus 5L Bản Cơ Núm Vặn, Công Suất 1300W, Bếp Chiên Không Khí Dung Tích Lớn, Chiên Nướng Hâm Nóng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(660, 1, 'KQZG004WH01FZ', 'KQZG004', 'Simplus Nồi chiên không dầu KQZG010 Dung tích 4L', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(661, 1, 'KQZG005BK00', 'KQZG005', 'Nồi chiên không dầu INSSA kiểu mới 5L màn hình cảm ứng đa năng thông minh  KQZG005', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(662, 1, 'KQZG007BK01FZ01', 'KQZG007', 'Nồi chiên không dầu Simplus 4L, Bếp chiên không khí dung tích công suất lớn chiên nướng đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(663, 1, 'KQZG007CW01FZ01', 'KQZG007', 'Nồi chiên không dầu Simplus 4L, Bếp chiên không khí dung tích công suất lớn chiên nướng đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(664, 1, 'KQZG007CW01FZ02', 'KQZG007', 'Nồi chiên không dầu dùng cho gia đình đa chức năng Simplus. Nồi chiên điện thông minh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(665, 1, 'KQZG007GR01FZ01', 'KQZG007', 'Nồi chiên không dầu Simplus 4L, Bếp chiên không khí dung tích công suất lớn chiên nướng đa năng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(666, 1, 'KQZG008BK00', 'KQZG008', 'INSSA Nồi chiên không dầu kiểu mới dung tích lớn 5.5L Vỉ nướng có thể tháo rời', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(667, 1, 'KQZG008BK00FZ01', 'KQZG008', 'Nồi chiên không dầu Inssa kiểu mới 5.5L đa chức năng KQZG001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(668, 1, 'KQZG009BK00', 'KQZG009', 'Dung tích lớn 5.5L, cả gia đình cùng nhau chia sẻ những món ngon Khí nóng tuần hoàn 360° tốc độ cao, nhiệt độ cao thay thế dầu mỡ giúp chiên thực phẩm nhanh chóng Không dầu, tốt cho sức khỏe, chiên/rán/nướng/quay, đa năng trong một nồi Trên mặt có menu 8', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(669, 1, 'KQZG015WH01', 'KQZG015', 'Nồi chiên không dầu Simplus Dung tích lớn 5L KQZG015', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(670, 1, 'KQZG013WH01', 'KQZG013', 'Nồi chiên không dầu Simplus Dung tích lớn 5L KQZG015', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(671, 1, 'NFJH003WH00', 'NFJH003', 'Máy sưởi Simplus máy sưởi nhỏ máy sưởi gia đình mini quạt bàn 500W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(672, 1, 'TTQP-SMZJ004', 'TTQP-SMZJ004', 'Simplus Máy làm bánh mì Sandwish SMZJ004 Chảo thay thế', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43');
INSERT INTO `products` (`id`, `product_user_id`, `sku`, `accounting_code`, `product_name`, `unit`, `tax_rate`, `created_at`, `updated_at`) VALUES
(673, 1, 'HFBP-SMZJ004', 'HFBP-SMZJ004', 'Simplus Máy làm bánh mì Sandwish SMZJ004 Chảo thay thế', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(674, 1, 'XCQI001WB01', 'XCQI001', 'Máy hút bụi không dây Simplus nhỏ gọn với lực hút mạnh 9000PA dễ dàng hút lông thú cưng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(675, 1, 'C0008XCQI002WH00', 'XCQI002', 'Máy hút bụi  Lực hút lớn Máy hút bụi gia đình thiết kế tối giản XCQI002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(676, 1, 'KFJH008WH00', 'KFJH008', 'Máy Pha Cà Phê Viên Nén Simplus Dung Tích lớn 900ml Áp suất 20Bar', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(677, 1, 'KFLZ002WD01', 'KFLZ002', 'Giấy lọc cà phê Simplus V40', 'Bịch', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(678, 1, 'RFSH001WB00', 'RFSH001', 'Lược chải điện Simplus RFSH001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(679, 1, 'CFJH004WB00', 'CFJH004', 'Máy sấy tóc Simplus Chống Hư Tổn 1000W CFJH004 Sấy Nóng Nhanh Khô', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(680, 1, 'XCLXCMYH002WH00', 'XCLX-CMYH002WH00', 'Simplus Bộ phận lọc của máy hút bụi được điều chỉnh phù hợp với máy hút bụi 001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(681, 1, 'ZZJH002WH00', 'ZZJH002', 'Máy xay sinh tố Simplus , máy xay hoa quả 800ml đa năng, cao ấp, tiện lợi, an toàn có thể nghiền đá ZZJH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(682, 1, 'GTJH014GY01', 'GTJH014', 'Bàn ủi hơi nước đứng Simplus GTJH014 Khay nước trong suốt 1.8L Là đứng là nằm 2 trong 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(683, 1, 'SMZJ004WH00FZ01', 'SMZJ004', 'Máy Kẹp Bánh Mì Sandwich Simplus, Máy Nướng Bánh Mì Rán Trứng Làm Đồ Ăn Sáng Nướng Thịt 2 Mặt Thiết Kế Chống Bỏng An Toàn - Bảo Hành 12 Tháng - SMZJ004', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(684, 1, 'GUOJ023CW00', 'GUOJ023', 'Chảo Chiên Simplus 18cm - Chất Liệu Chống Dính Phù Hợp Bếp Ga Bếp Từ Nồi Chiên Rán Phủ Men Gốm Đa Công Năng Tiện Lợi GUOJ022CW01', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(685, 1, 'JBBA002WH00FZ01', 'JBBA002', ' Máy đánh trứng cầm tay bằng thép không gỉ Simplus  Máy xay thịt đa chức năng  Máy trộn kem trứng tiện ích JBBA002WH00', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(686, 1, 'XCQH010WH01', 'XCQH010', 'Máy hút bụi không dây Simplus XCQH010 màn hình điện tử lực hút 13000PA - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(687, 1, 'DZGH002WH02FZ01', 'DZGH002', '[Kèm xửng hấp] Nồi điện đa năng chống dính có tay cầm dài  Simplus 1.5L  Có khay hấp Lòng nồi phủ gốm chống dính Bảo hành 1 năm 1 đổi 1 - DZGH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(688, 1, 'KQZG007-Black', 'KQZG007', 'Nồi chiên không dầu Simplus 4L, Nồi chiên không khí đa năng không dầu mỡ bếp chiên không dầu dung tích lớn, sang trọng - tiết kiệm thời gian, bảo hành một năm chỉ đổi không sửa KQZG007', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(689, 1, 'KFJH004WH01', 'KFJH004', 'Máy pha cà phê Simplus KFJH004  Máy pha cà phê nhỏ giọt của Mỹ 600ml Hoàn toàn tự động', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(690, 1, 'SMZJ004WH01', 'SMZJ004', 'Máy nướng  bánh mì  Simplus，Máy nướng bánh dành cho  gia đình với  hai khay ép lò nướng đa chức năng SMZJ004WH00', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(691, 1, 'CFJH006WH001', 'CFJH006', 'Máy Sấy Tóc Simplus 200 triệu ion âm CFJH006 -Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(692, 1, 'SMZJ003WH00FZ01', 'SMZJ003', '[New arrival]Máy làm bánh sandwich Simplus công suất cao 800W Máy nướng bánh đa chức năng SMZJ003WH00', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(693, 1, 'KFJH004BK01', 'KFJH004', 'Máy pha cà phê Simplus KFJH004  Máy pha cà phê nhỏ giọt của Mỹ 600ml Hoàn toàn tự động', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(694, 1, 'DSLU006WH00FZ01', 'DSLU006', 'Máy nướng bánh mì Simplus 800W, Máy làm bánh kẹp Sandwich đa năng phù hợp cho gia đình, Lò nướng bánh mì lát nóng giòn - Bảo Hành 1 Năm Chỉ Đổi Không Sửa - DSLU006', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(695, 1, 'DZGH002WH02FZ02', 'DZGH002', 'Nồi Điện Đa Năng Simplus DZGH002 Chống Dính 1.5L Thích Hợp Cho 2-3 Người Hai Mức Nhiệt Độ Nồi Lẩu Điện Nhỏ Nồi Tay Cầm Dài Chống bỏng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(696, 1, 'CUSH002WH01', 'CUSH002', 'Máy Hút Ẩm Simplus Dung Tích lớn 2.5L Màn hình điều kiển LDC - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(697, 1, 'KFJH006WH00', 'KFJH006', 'Máy Pha Cà Phê Mini Tự Động Kiểu Mỹ  Máy Pha Trà Pha Cà Phê KFJH006', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(698, 1, 'DZGH002WH01FZ02', 'DZGH002', 'Nồi Điện Đa Năng Simplus DZGH002 Chống Dính 1.5L Thích Hợp Cho 2-3 Người Hai Mức Nhiệt Độ Nồi Lẩu Điện Nhỏ Nồi Tay Cầm Dài Chống bỏng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(699, 1, 'DZGH007WH00', 'DZGH007', 'Nồi Điện Đa Năng Simplus DZGH007 Chống Dính 1.5L Thích Hợp Cho 2-3 Người Hai Mức Nhiệt Độ Nồi Lẩu Điện Nhỏ Nồi Tay Cầm Dài Chống bỏng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(700, 1, 'HFBJ001WH00FZ01', 'HFBJ001', 'Máy làm bánh Waffle Simplus, máy nướng bánh mì làm nóng đều hai mặt, nhanh chóng, tiện lợi, làm đồ ăn sáng, Bảo hành 1 Năm 1 Đổi 1 -  HFBJ001WH00', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(701, 1, 'GUOJ013CW01FZ01', 'GUOJ013', '[Nồi bếp từ]  Nồi đá Maifan chống dính Inssa X Simplus nồi bổ sung ăn dặm cho bé nồi nhỏ đun sữa nấu mì size 18cm GUOJ013CW01', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(702, 1, 'GUOJ027CW00', 'GUOJ027', '[Nồi bếp từ] Nồi tuyết 18 / 20cm, nồi nấu Nhật, nồi sữa, dùng được cho 2-3 người, nồi chống dính tay cầm vân gỗ, nồi nấu có nắp đậy GUOJ020', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(703, 1, 'GUOJ010CW01', 'GUOJ010', 'INSSA X Simplus Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng Inssa X Simplus dùng cho bếp từ ga bộ nồi chảo chống dính Nồi bếp từ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(704, 1, 'GUOJ011CW01', 'GUOJ011', 'INSSA X Simplus Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng Inssa X Simplus dùng cho bếp từ ga bộ nồi chảo chống dính Nồi bếp từ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(705, 1, 'CFJH004BK00FZ01', 'CFJH004', 'INSSA X Simplus Máy Sấy Tóc Ion Âm 1000W, Sấy Hai Chiều Nóng Lạnh Nhanh Khô Không Xơ Tóc, Nhỏ Gọn Tiện Lợi CFJH004', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(706, 1, 'KFJH005BK01', 'KFJH005', 'INSSA X Simplus Máy Pha Cà Phê 1.2L, Kiểu Mỹ Hoàn Toàn Tự Động, Bảo Hành 1 Năm 1 Đổi 1 KFJH005', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(707, 1, 'ZFBA003WP01', 'ZFBA003', 'Máy Kẹp Tóc Simplus Màn hình LCD ZFBA003 -Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(708, 1, 'JFBA008PK01', 'JFBA008', 'Máy uốn tóc Simplus  5 mức nhiệt  Đầu cuộn 22mm JFBA008 - Bảo Hành 1 Năm 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(709, 1, 'LLJH007SS00', 'LLJH007', 'Máy xay sinh tố Simplus Công suất cao 400W - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(710, 1, 'XCQH011GY02', 'XCQH011', 'Máy Hút Bụi Simplus 18000PA cho Gia Đình Nhỏ Lực Hút Mạnh Mẽ XCQH011 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(711, 1, 'GYZH001', 'GYZH001', 'Giấy lót nồi chiên không dầu', 'Bịch', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(712, 1, 'ZENP005BL00', 'ZENP005', 'Túi vải Simplus dễ dàng mang theo', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(713, 1, 'DFBA006WH01', 'DFBA006', 'Nồi cơm điện mini Simplus Dung tích 2L DFBA006 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(714, 1, 'DZGH009', 'DZGH009', 'Nồi lẩu điện cầm tay đa năng Simplus 2L/1.5L DZGH006/002 kèm xửng hấp, chống dính, điều chỉnh nhiệt độ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(715, 1, 'GTJH014WY01FZ01', 'GTJH014', 'Bàn ủi hơi nước đứng Simplus 2000w là phẳng tiện lợi GTJH -Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(716, 1, 'HMCH001WH01', 'HMCH001', 'Simplus Bột gỗ tự nhiên HMCH001 Bọt biển thần thánh', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(717, 1, 'DFBA007WH01', 'DFBA007', 'Nồi cơm điện Simplus Dung tích 3L DFBA007 Màn hình LCD - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(718, 1, 'DZGH010WH01', 'DZGH010', 'Nồi điện đa năng Simplus DZGH008 dung tích 3L điều chỉnh nhiệt độ - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(719, 1, 'GTJH014WB01FZ01', 'GTJH014', 'Bàn ủi hơi nước đứng Simplus 2000w là phẳng tiện lợi GTJH -Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(720, 1, 'LFSH001WH00FZ01', 'LFSH001', 'Quạt điều hòa hơi nước làm mát không khí Simplus Dung tích 10L, Quạt phun sương siêu mát lạnh, Bảo hành 1 năm chỉ đổi không sửa LFSH001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(721, 1, 'LFSH002WH00FZ01', 'LFSH002', 'Quạt điều hòa hơi nước làm mát không khí Simplus Dung tích 10L, Quạt phun sương siêu mát lạnh, Bảo hành 1 năm chỉ đổi không sửa LFSH001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(722, 1, 'ZFBA004PK00', 'ZFBA004', 'Máy duỗi tóc mini Simplus ZFBA004 Duỗi uốn linh hoạt Máy duỗi uốn 2 trong 1 tiện lợi', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(723, 1, 'KFJH007CW01', 'KFJH007', 'Máy pha cà phê Simplus KFJH007 Đánh bọt sữa   20Bar  Bán tự động   Đồ dùng gia đình', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(724, 1, 'TZCH001WH00', 'TZCH001', 'Cân Điện Tử - Cân Sức Khỏe Sử Dụng Gia Đình，Mặt Kính Sang Trọng，Độ Chuẩn Xác Cao，Bền Đẹp TZCH001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(725, 1, 'ZFBA004GR00', 'ZFBA004', 'Máy uốn duỗi tóc Mini Simplus ZFBA004', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(726, 1, 'HMCH001WH02', 'HMCH001', 'Simplus Bột gỗ tự nhiên HMCH001 Bọt biển thần thánh', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(727, 1, 'ZENP015WB00', 'ZENP015', 'Túi vải Simplus dễ dàng mang theo', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(728, 1, 'LVSH001+LVXI05', 'LVSH001', 'Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(729, 1, 'DFBA007WH02', 'DFBA007', 'Nồi cơm điện Simplus Dung tích 3L DFBA007 Màn hình LCD', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(730, 1, 'KQZG015WH01FZ', 'KQZG015', 'Nồi chiên không dầu Simplus Dung tích lớn 5L  KQZG015', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(731, 1, 'ZFBA004WH00', 'ZFBA004', 'Máy uốn duỗi tóc Mini Simplus ZFBA004 -', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(732, 1, 'DZEG002WH00', 'DZEG002', 'Nồi hấp điện Simplus Dung tích 12L  Màn hình điện tử', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(733, 1, 'GTJH012WH01FZ01', 'GTJH012', 'Bàn ủi hơi nước đứng Simplus - Bàn là cây hơi nước công suất 1800W - Bảo Hành 1 Năm 1 Đổi 1 - GTJH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(734, 1, 'JFBA006PK01', 'JFBA006', 'Máy uốn tóc hình móng vuốt mèo siêu yêu 32mm thanh nẹp gợn tóc sóng nước dập xù cực tự nhiên JFBA006', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(735, 1, 'JFBA005PP01', 'JFBA005', 'Máy Uốn Tóc Xoăn Tự Động Simplus 32mm JFBA005 Xoay Một Nút Uốn Tự Động - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(736, 1, 'CFJH006WH01FZ01', 'CFJH006', 'Máy Sấy Tóc Simplus 200 triệu ion âm CFJH006 -Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(737, 1, 'ZENP014MX00', 'ZENP014', 'Miếng dán hoạt hình đáng yêu tiện dụng trang trí', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(738, 1, 'GTJH014WY01FZ02', 'GTJH014', 'Bàn ủi hơi nước đứng Simplus - Bàn là cây hơi nước công suất 1800W - Bảo Hành 1 Năm 1 Đổi 1 - GTJH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(739, 1, 'DDJR005WH01', 'DDJR005', 'Máy xay thịt đa năng nhỏ Simplus   Máy bổ sung thức ăn cho trẻ em   Máy xay gia đình 8 lưỡi dao   Máy xay thịt, rau củ siêu nhuyễn DDJR005', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(740, 1, 'GTJH014WB01FZ02', 'GTJH014', 'Bàn ủi hơi nước đứng Simplus - Bàn là cây hơi nước công suất 1800W - Bảo Hành 1 Năm 1 Đổi 1 - GTJH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(741, 1, 'GTJH014WB01FZ03', 'GTJH014', 'Bàn ủi hơi nước đứng Simplus - Bàn là cây hơi nước công suất 1800W - Bảo Hành 1 Năm 1 Đổi 1 - GTJH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(742, 1, 'GUOJ013GY01', 'GUOJ013', 'Nồi Nấu Bột Chống Dính Simplus 18CM Nồi Đa Năng Phù Hợp Cả Bếp Từ Bếp Ga  GUOJ013', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(743, 1, 'HMCH001WH03', 'HMCH001', 'Simplus Bột gỗ tự nhiên HMCH001 Bọt biển thần thánh HMCH001', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(744, 1, 'GUOJ011CR01FZ02', 'GUOJ011', '[Nồi bếp từ]  Chảo chống dính vân đá Maifan chảo gia dụng chiên rán bếp từ đa năng bếp từ bếp ga đa năng chảo trắng 28CM GUOJ011CR01', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(745, 1, 'KFJH005BK01FZ01', 'KFJH005', 'Máy pha cà phê Simplus KFJH005   Máy pha cà phê nhỏ giọt của Mỹ 1200ML Hoàn toàn tự động', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(746, 1, 'GUOJ029CW01', 'GUOJ029', 'Tay cầm rời nồi gia đình bộ nồi chảo chống dính full set chảo rán nồi canh chảo lồng nồi cho bé GUOJ029', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(747, 1, 'YSHU001WH02', 'YSHU001', 'Simplus 1.5L Bộ ấm điện Gia dụng Đa chức năng Tự động ngắt điện Văn phòng nhỏ Ấm điện đun trà  Ấm đun nước', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(748, 1, 'XCQH008GY02FZ02', 'XCQH008', 'Máy hút bụi Simplus XCQH011 18000PA  Máy hút bụi có dây Lực hút mạnh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(749, 1, 'LFSH002', 'LFSH002', 'Simplus Quạt điều hòa hơi nước Quạt siêu mát điều khiển từ xa dung tích lớn 10L LFSH', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(750, 1, 'DFBA007WH00', 'DFBA007', 'Nồi cơm điện simplus gia dụng thông minh đa năng 3L nồi cơm điện nhỏ Hẹn giờ DFBA007', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(751, 1, 'CMYH004WH00', 'CMYH004', 'Simplus 12000pa Loại bỏ ve Loại bỏ rận Rung với tần số cao Máy hút bụi giường nệm Vệ sinh thảm Hút lông tóc mites vacuum cleaner', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(752, 1, 'ZENP016BK00', 'ZENP016', 'Tạp dề INSSA  Tạp dề chống thấm nước và chống dầu nhà bếp  Bảo vệ quần áo không bị dính bẩn cà phê thức ăn ZENP016', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(753, 1, 'ZBJH001WH00', 'ZBJH001', 'Simplus Máy Làm Đá Simplus 1.2L Gia Dụng Mini Tự Động Máy Làm Đá Công Suất Thấp ICE MAKER', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(754, 1, 'KQJH005WH01', 'KQJH005', 'Simplus Máy lọc không khí Simplus Gia dụng Diệt khuẩn Loại bỏ khí Formaldehit Loại bỏ khói mù Loại bỏ mùi hôi KQJH00', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(755, 1, 'BWBH001WH00', 'BWBH001', 'Simplus  Cốc giữ nhiệt hai lớp bằng thép không gỉ 316 cốc nước cầm tay cách nhiệt', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(756, 1, 'DFBA006WH00', 'DFBA006', 'Nồi cơm điện mini   Gia dụng thông minh   2L   Nồi cơm điện nhỏ mini    Nồi nấu 2-3 người DFBA006', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(757, 1, 'GTJH016GR00', 'GTJH016', 'Bàn ủi hơi nước cầm tay 170ML Simplus - Bàn là Mini du lịch tiện lợi - nhỏ gọn tiện lợi cho gia đình - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(758, 1, 'DFSH002WH00FZ01', 'DFSH002', 'Quạt sạc tích điện Simplus 8 inch Dung lượng 4800MAH, Quạt để bàn sạc USB gấp gọn không dây điều chỉnh được độ cao, Quạt mini sạc điện dùng lâu DFSH004', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(759, 1, 'LFSH002WH00FZ03', 'LFSH002', 'Quạt điều hòa hơi nước làm mát không khí Simplus Dung tích 10L, Quạt phun sương siêu mát lạnh, Bảo hành 1 năm chỉ đổi không sửa LFSH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(760, 1, 'DZGH009WH01', 'DZGH009', '[Kèm xửng hấp] Nồi lẩu điện đa năng Simplus 2L nồi kèm xửng hấp, chống dính, điều chỉnh nhiệt độ,lẩu điện nhỏ, tay cầm dài DZGH009', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(761, 1, 'GUOJ032SS00', 'GUOJ032', 'Simplus GUOJ034 Nối nấu canh 16cm/20cm/24cm INSSA bằng thép không gỉ 304', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(762, 1, 'GTJH016WH00', 'GTJH016', 'Bàn ủi hơi nước cầm tay 170ML Simplus - Bàn là Mini du lịch tiện lợi - nhỏ gọn tiện lợi cho gia đình - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(763, 1, 'MFSH001CW00', 'MFSH001', 'Lược chải tóc đệm hơi tay cầm dài Simplus, làm mượt tóc, massage tại nhà và tạo kiểu tóc', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(764, 1, 'YSHU001WH01', 'YSHU001', 'Simplus 1.5L Bộ ấm điện Gia dụng Đa chức năng Tự động ngắt điện Văn phòng nhỏ Ấm điện đun trà  Ấm đun nước', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(765, 1, 'MDJH002SS00', 'MDJH002', 'Máy xay hạt cà phê Simplus Cầm tay, Xay thủ công 20g Màu Inox', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(766, 1, 'XGBH001WH00', 'XGBH001', 'INSSA Ly hai lớp cách nhiệt  Ly nước dung tích lớn  Màu thuần sắc  Ly uống nước mùa hè', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(767, 1, 'KQZG015GY01', 'KQZG015', 'Simplus Gen-S N1 Pro Nồi chiên không dầu Có ô cửa sổ Dung tích lớn 5L Gia dụng  Màn hình cảm ứng  Nhiều chức năng Air Fryer', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(768, 1, 'DCJH001WH00', 'DCJH001', 'Simplus Máy trộn bột   Máy trộn thực phẩm đa chức năng blender', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(769, 1, 'KQZG017CW01', 'KQZG017', 'Nồi chiên không dầu Simplus  Mẫu mới  Gia dụng   Cửa sổ trong suốt toàn cảnh   Dung tích 4L   Bản cảm ứng   Đa chức năng   Nồi chiên bằng điện thông minh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(770, 1, 'DFSH012WH00', 'DFSH012', 'Simplus, Quạt mini thông minh, cầm tay, USB, quạt sạc pin, dạng cầm tay mini, có thể gấp gọn, 2 mức tốc độ gió', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(771, 1, 'DFSH006WH00FZ01', 'DFSH006', 'Quạt cây Simplus 16 inch, quạt 5 cánh sức gió lớn, tiếng ồn thấp, tiết kiệm năng lượng, quạt đứng quay nâng hạ phù hợp văn phòng, gia đình, Bảo hành 1 năm chỉ đổi không sửa DFSH006', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(772, 1, 'DRSH007WH00', 'DRSH007', '[Sản phẩm mới] Simplus Ấm đun nước Simplus 1,7L 1500W 2 lớp chống bỏng Lòng ấm bằng thép liền mạch Bảo vệ ngắt nguồn chống cháy electeic kettle', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(773, 1, 'KQZG018CW01', 'KQZG018', '[Sản phẩm mới] Nồi chiên không dầu Simplus, dung tích lớn 6.5L, 1500W, cửa sổ trực quan, 10 menu cài sẵn, đa chức năng, sử dụng cho gia đình', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(774, 1, 'DZEG001CW01FZ01', 'DZEG001', 'Nồi hấp điện   Nồi Lẩu Điện  2 Trong 1  Simplus   2 tầng Nồi hấp  12L  + 1 tầng Nồi hấp 3L  1200W   Làm nóng nhanh đa chức năng  Ba chế độ   Màn hình điện tử  LCD  Trong suốt   Hẹn giờ 24H DZEG001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(775, 1, 'ZFSH001PK00', 'ZFSH001', 'Ion âm  Lược điện duỗi tóc  Uốn xoăn  Hai chức năng  Khóa trong  Không tổn thương tóc   Lược điện ZFSH001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(776, 1, 'DZGH002WH01FZ01', 'DZGH002', '[Kèm xửng hấp] Nồi điện đa năng chống dính có tay cầm dài  Simplus 1.5L  Có khay hấp Lòng nồi phủ gốm chống dính Bảo hành 1 năm 1 đổi 1 DZGH002', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(777, 1, 'DFSH011WH00', 'DFSH011', 'Simplus Quạt mini thông minh, cầm tay, USB, quạt điện, dạng mang đi, có thể gấp gọn, 3 mức tốc độ gió', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(778, 1, 'CFLL004WD00', 'CFLL004', 'Bộ thìa gỗ gia dụng muỗng, muôi súp, thìa chéo, thìa cơm, chuyên dụng cho chảo chống dính, chịu nhiệt độ cao CFLL004', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(779, 1, 'XGBH001WH00FZ01', 'XGBH001', 'Ly hai lớp cách nhiệt  Ly nước dung tích lớn  Màu thuần sắc  Ly uống nước mùa hè', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(780, 1, 'GUOJ031SS00', 'GUOJ031', 'Simplus GUOJ034 Nối nấu canh 16cm/20cm/24cm INSSA bằng thép không gỉ 304', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(781, 1, 'GUOJ028CW00', 'GUOJ028', 'Chảo chiên rán Simplus 26CM chống dính chất lượng cao, chảo chiên trứng, xào nấu đa dụng GUOJ028', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(782, 1, 'GTJH015CW00', 'GTJH015', 'Bàn ủi cầm tay 2 công dụng ủi hơi nước và khô  Dạng nhỏ, gia dụng, 2 mức độ, có thể gấp gọn, mẫu mang theo du lịch, mặt bàn ủi phủ lớp chống dính', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(783, 1, 'DRSH007GY00', 'DRSH007', '[Sản phẩm mới] Simplus Ấm đun nước Simplus 1,7L 1500W 2 lớp chống bỏng Lòng ấm bằng thép liền mạch Bảo vệ ngắt nguồn chống cháy electeic kettle', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(784, 1, 'XCQH008GY04FZ01', 'XCQH008', '[New arrival Máy Hút Bụi  Nhỏ Lực Hút Mạnh Mẽ Simplus 16590PA Phù Hợp Cho  Gia Đình Máy Hút Bụi Làm Sạch XCQH008GY01', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(785, 1, 'KQZG014GY01', 'KQZG014', '[Sản phẩm mới] Simplus Gen-S N1 Pro Nồi chiên không dầu Có ô cửa sổ Dung tích lớn 5L Gia dụng  Màn hình cảm ứng  Nhiều chức năng Air Fryer', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(786, 1, 'DZGH010WH01FZ01', 'DZGH010', 'Nồi điện đa năng Simplus 1.5L/3L, Phù hợp sử dụng cho 2-3/4-6 người, lòng nồi chống dính tráng men cao cấp, công suất 600W hai mức điều chỉnh nhiệt độ linh hoạt DZGH003', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(787, 1, 'XCQH008GY03FZ01', 'XCQH008', '[New arrival Máy Hút Bụi  Nhỏ Lực Hút Mạnh Mẽ Simplus 16590PA Phù Hợp Cho  Gia Đình Máy Hút Bụi Làm Sạch XCQH008GY01', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(788, 1, 'DZGH009WH00FZ01', 'DZGH009', '[Kèm xửng hấp] Nồi lẩu điện đa năng Simplus 2L nồi kèm xửng hấp, chống dính, điều chỉnh nhiệt độ,lẩu điện nhỏ, tay cầm dài DZGH009', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(789, 1, 'JSQH003WH00', 'JSQH003', '[New Arrival]Máy lọc nước gia dụng Simplus, lọc vòi nước nhà bếp và nhà vệ sinh, lõi lọc phức hợp hiệu quả cao, 2 kiểu xả nước, nước đã lọc và chưa lọc', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(790, 1, 'XCQH009WY01', 'XCQH009', 'Máy Hút Bụi Cầm Tay Không Dây Simplus 12000PA, Tốc Độ Cao , Lực Hút Mạnh, Hút Bụi Không Dây, Dùng Trong Nhà, Hút Bụi Xe Ô Tô, Pin Sạc Bền Lâu XCQH009', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(791, 1, 'MDJH003WH01', 'MDJH003', 'Máy xay hạt đa năng bằng điện Simplus 150W, xay gia vị, các loại hạt, hạt cà phê', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(792, 1, 'ZFBA003PK01', 'ZFBA003', 'Máy Kẹp Tóc Simplus Màn hình LCD ZFBA003 -Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(793, 1, 'GUOJ012GY01', 'GUOJ01', 'Nồi Nấu Canh Chống Dính Maifan INSSA 24CM - Nồi Đá Maifan Có Nắp, Hai Quai Chống Bỏng, Thông Dụng Bếp Ga, Từ', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(794, 1, 'KFJH009BK00', 'KFJH009', 'Máy  pha cà phêAmericano Simplus kiểu dáng đồng hồ cát dung tích lớn 600ml đồ dùng văn phòng nhỏ một máy nhiều chức năng hoàn toàn tự động', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(795, 1, 'GTJH017WH00', 'GTJH017', '[New Arrival] Simplus Máy hấp quần áo cầm tay, công suất cao 1200w, bàn ủi hơi nước, máy hấp quần áo', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(796, 1, 'XCQH012WH00', 'XCQH012', '[New Arrival]Máy hút bụi không dây gia dụng 5500PA Simplus, 3 lớp lọc hiệu quả, sạc Type-C', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(797, 1, 'CMYH004WH00FZ01', 'CMYH004', 'Simplus Dụng cụ hút tần số cao loại bỏ mạt ve và lông dành cho gia đình - Bảo Hành 1 Năm 1 Đổi 1 - CMYH002WH00', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(798, 1, 'XCQH011GY03', 'XCQH011', 'Simplus Máy hút bụi 18000PA    Máy hút bụi có dây   Lực hút mạnh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(799, 1, 'BYJH001GY00', 'BYJH001', 'Simplus Máy giặt vải Simplus  Tích hợp phun xả nhiệt độ cao  Không cần tháo rời để vệ sinh BYJH001', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(800, 1, 'GTJH005BL00', 'GTJH005', 'Simplus Bàn ủi điện hơi nước cầm tay - Ủi khô ủi hơi nước kết hợp - Tiện lợi sử dụng gia đình', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(801, 1, 'LVXI-JSQH003WH00', 'LVXI-JSQH003', 'Simplus Lõi lọc phức hợp hiệu quả cao - máy siêu lọc vòi nước gia dụng', 'Cái', '8', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(802, 1, 'LVXI-JSQH001WH01', 'LVXI-JSQH001', 'Simplus Lõi lọc phức hợp siêu lọc SUF - máy siêu lọc nước', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(803, 1, 'KQZG013GY01', 'KQZG013', '[Sản phẩm mới] Simplus Gen-S N1 Pro Nồi chiên không dầu Có ô cửa sổ Dung tích lớn 5L Gia dụng  Màn hình cảm ứng  Nhiều chức năng Air Fryer', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(804, 1, 'LLJH010WH01', 'LLJH010', 'Simplus Máy xay đa năng 1.25L, máy xay sinh tố, 3 chế độ xay, 3 cối thay đổi, cối di động, cối thủy tinh Mason', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(805, 1, 'DZGH009WH00', 'DZGH009', 'Simplus Nồi cơm điện đa năng  2L  Chống dính    Thích hợp cho 2-4 người    Hai mức nhiệt tùy chỉnh    Nồi lẩu điện mini   Chảo chiên', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(806, 1, 'JSQH005WH00', 'JSQH005', '[New Arrival]Simplus Máy lọc nước tại vòi , 7 tầng lọc, lõi lọc gốm sứ dễ dàng vệ sinh, dùng cho nhà bếp và nhà vệ sinh', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(807, 1, 'DHGH002WH00', 'DHGH002', 'Simplus Nồi lẩu điện đa năng dạng tách rời 4.2L, nồi điện chống dính gia dụng 1400W, đun nấu, hầm canh, chiên xào, beefsteak', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(808, 1, 'DHGH001WH00', 'DHGH001', 'Simplus Nồi lẩu điện đa năng 3.2L, nồi điện chống dính gia dụng 1300W, đun nấu, hầm canh, chiên xào, beefsteak', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(809, 1, 'KQJH005WH00', 'KQJH005', 'Simplus Máy lọc không khí Simplus Gia dụng Diệt khuẩn Loại bỏ khí Formaldehit Loại bỏ khói mù Loại bỏ mùi hôi KQJH00', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(810, 1, 'KFJH011BK00', 'KFJH011', 'Simplus Máy pha cà phê Máy pha cà phê lọc gia đình  Dung tích lớn 750ml Pha trà pha cà phê tiện dụng', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(811, 1, 'KFJH011BK00FZ01', 'KFJH011', 'Simplus Máy pha cà phê Máy pha cà phê lọc gia đình  Dung tích lớn 750ml Pha trà pha cà phê tiện dụng KFJH011', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(812, 1, 'ZFBA004GR00-77', 'ZFBA004', 'Simplus Máy duỗi tóc mini ZFBA004 Duỗi uốn linh hoạt Máy duỗi uốn 2 trong 1 tiện lợi -- FG', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(813, 1, 'DRSH006CW00', 'DRSH006', 'Simplus Ấm đun nước cổ điển Châu Âu  Hai lớp chống bỏng  Ấm đun nước gia đình dung tích 1.7L Lòng ấm bằng thép không gỉ 304  Bảo vệ tắt nguồn chống cháy', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(814, 1, 'LLJH009WH00', 'LLJH009', '[New Arrival] Simplus Máy xay gia dụng dạng cầm tay, máy xay hoa quả mini, thiết kế cốc di động, công suất 150W', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(815, 1, 'DRSH009WH00', 'DRSH009', 'Simplus Ấm pha cà phê  Ấm đun siêu tốc thép không gỉ 304   0.8L Vòi nước dài  Ấm đun siêu tốc cổ ngỗng  Phù hợp dùng cho cà phê phin   Tự tay pha cà phê và trà  DRSH009', 'Cái', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(816, 1, 'ZHGTJH014WY01+YYST001', 'ZHGTJH014+YYST001', 'Simplus Bàn ủi hơi nước đứng - Bàn là cây hơi nước công suất 1800W - Bảo Hành 1 Năm 1 Đổi 1 - GTJH014', 'Bộ', '10', '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(817, 1, 'GTJH015CW00FZ01', 'GTJH015', '[New Arrival] Simplus Bàn ủi cầm tay 2 công dụng ủi hơi nước và khô  Dạng nhỏ, gia dụng, 2 mức độ, có thể gấp gọn, mẫu mang theo du lịch, mặt bàn ủi phủ lớp chống dính GTJH015', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(818, 1, 'GTJH011WH00FZ01', 'GTJH011', 'Simplus Bàn Ủi Hơi Nước Cầm Tay Simplus Bình Chứa Nước 170ml GTJH011 Bảo Hành 1 Năm Chỉ Đổi Không Sửa,Ủi Quần Áo Là Quần Áo Bàn Là Hơi', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(819, 1, 'LLJH009WH00FZ01', 'LLJH009', 'Simplus Bàn Ủi Hơi Nước Cầm Tay Simplus Bình Chứa Nước 170ml GTJH011 Bảo Hành 1 Năm Chỉ Đổi Không Sửa,Ủi Quần Áo Là Quần Áo Bàn Là Hơi', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(820, 1, 'JFBA009PG00', 'JFBA009', 'Simplus Bàn Ủi Hơi Nước Cầm Tay Simplus Bình Chứa Nước 170ml GTJH011 Bảo Hành 1 Năm Chỉ Đổi Không Sửa,Ủi Quần Áo Là Quần Áo Bàn Là Hơi', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(821, 1, 'GTJH019WH00', 'GTJH019', 'Simplus Bàn ủi hơi nước cầm tay công suất 1200W - Bàn là mini tiện lợi mang đi du lịch, công tác GTJH010WH00', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(822, 1, 'SMZJ004WH00-VIP', 'SMZJ004', 'Simplus Máy nướng  bánh mì ，Máy nướng bánh dành cho  gia đình với  hai khay ép lò nướng đa chức năng SMZJ004WH00', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(823, 1, 'DFBA008GY00', 'DFBA008', '[New Arrival] Simplus Nồi cơm điện cảm ứng 4L Hẹn giờ 24 giờ  6 chế độ nấu sẵn Không chứa PFOA và PFOS Lòng nồi chống dính', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(824, 1, 'JFBA011PK00', 'JFBA011', '[New Arrival]Simplus Máy uốn tóc 32MM, máy uốn gợn sóng, bản kẹp nếp sóng to, bảo bối uốn tóc', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(825, 1, 'CFJH006PK03', 'CFJH006', 'Simplus Máy Sấy Tóc  Ion Âm Nhanh Khô 1600W Di Động Chăm Sóc Tóc Du Lịch Tốc Độ Cao Nhỏ Gọn CFJH006', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(826, 1, 'GUOJ035BK00', 'GUOJ035', 'Simplus Chảo nướng 26cm, chảo rán, làm bánh ngàn lớp, vỏ bánh, chảo, bánh kếp, trứng tráng, chống dính', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(827, 1, 'GTJH020WH00', 'GTJH020', '[New Arrival] Simplus Bàn ủi hơi nước cầm tay  Công suất cao 1200W Bình chứa nước 180ml Gấp gọn tiện lợi Ủi đứng nằm hai kiểu', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(828, 1, 'PSQH001WY01', 'PSQH001', 'Simplus Máy cắt sợi  Máy thái lát rau củ đa năng 5 lưỡi dao Kèm hộp đựng PSQH001', 'Cái', '8', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(829, 1, 'ZFBA004PK00-77', 'ZFBA004', 'Simplus Máy duỗi tóc mini ZFBA004 Duỗi uốn linh hoạt Máy duỗi uốn 2 trong 1 tiện lợi -- FG', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(830, 1, 'KFJH013BK00', 'KFJH013', '[New Arrival]Simplus Máy pha cà phê Máy pha cà phê nhỏ giọt tại nhà Cốc đôi một nút bấm Thân máy nhỏ gọn Pha cà phê và pha trà KFJH013', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(831, 1, 'KFJH013BK00FZ02', 'KFJH013', 'Simplus Máy pha cà phê Máy pha cà phê lọc gia đình  Dung tích lớn 750ml Pha trà pha cà phê tiện dụng', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(832, 1, 'LVXI-JSQH004WH00', 'LVXI-JSQH004', 'Lõi lọc của đầu lọc nước tại vòi, tốc độ lọc nước 2L/phút, mới 100%', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(833, 1, 'SMZJ005CW00', 'SMZJ005', 'Máy làm bánh Donut Máy ăn sáng Làm nóng hai mặt 800W Thiết kế 8 lỗ  Mặt nướng chống dính SMZJ005', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(834, 1, 'MFGH001GY00', 'MFGH001', 'Hộp nhựa đựng thực phẩm, Chống ẩm tốt, Đựng cà phê trái cây sấy MFGH001', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(835, 1, 'XCQH016WH00', 'XCQH016', 'Máy hút bụi ô tô cầm tay, dùng pin, không dây, cốc chứa bụi 0.6L, điện áp 7.4V, công suất 45W, pin 1500mAh, nhãn hiệu SIMPLUS', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(836, 1, 'CFJH008PK00', 'CFJH008', 'Simplus Máy Sấy Tóc Có Thể Gấp Gọn Ion Âm Bảo Vệ Tóc 3 Mức Sấy Màu Macaron CFJH008- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(837, 1, 'ZHGTJH011WH+YYST001', 'ZHGTJH011+YYST001', 'Combo 01 Bàn ủi hơi nước cầm tay, Công suất 1200W, Dung tích bình chứa nước 170ML+ 01 Simplus Găng tay bàn ủi quần áo, đệm ủi bàn là chịu nhiệt, chống bỏng, chống thấm nước tiện lợi', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(838, 1, 'XDJH003WH00', 'XDJH003', 'Máy hút bụi và lau nhà không dây, điện áp 22.2V, công suất 150W, dùng pin sạc, nhãn hiệu SIMPLUS', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(839, 1, 'ZZJH007CW00', 'ZZJH007', 'Máy ép trái cây Simplus Dung tích lớn 1000ml', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(840, 1, 'DZGH011WH01', 'DZGH011', 'Nồi điện điện áp 220-240V, 50/60Hz, công suất 630W, dung tích 1.2L, nhãn hiệu SIMPLUS', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(841, 1, 'DZEG003WH01FZ01', 'DZEG003', 'Nồi hấp điện 6in1 Simplus Dung tích lớn 12L/14 DZEG001', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(842, 1, 'DZEG004CW00', 'DZEG004', 'Nồi điện, có xửng hấp điện áp 220-240V, 50/60Hz, công suất 1000W, dung tích 11L ( nấu:3l, hấp:8l), nhãn hiệu SIMPLUS', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(843, 1, 'GTJH018WH00', 'GTJH018', 'Bàn Ủi Hơi Nước Đứng Simplus 1580W Dung tích 1,5L', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(844, 1, 'SMZJ004WH00-VIPFZ01', 'SMZJ004', 'Simplus Máy làm bánh mì Sandwish máy ăn sáng Máy làm bánh mì nướng bánh quế gia đình hai khay', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(845, 1, 'DZEG005WH00', 'DZEG005', 'Nồi điện, có xửng hấp điện áp 220-240V, 50/60Hz, công suất 1300W, dung tích 21L, nhãn hiệu SIMPLUS', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(846, 1, 'ZFBA004WH00-77', 'ZFBA004', 'Máy duỗi tóc, điện áp 220-240V, công suất 17W, 50/60Hz, nhãn hiệu SIMPLUS', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(847, 1, 'DFSH010WH00', 'DFSH010', 'Quạt Cầm Tay Mini Simplus 3 Tốc Độ - Pin 4000 Sử Thời lượng kéo dài 20h', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(848, 1, 'RFSH002WP00', 'RFSH002', 'Lược điện  Duỗi uốn hai kiểu Tạo kiểu nhanh khô Bảo vệ tóc không hư tổn RFSH002', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(849, 1, 'KFJH015WH00', 'KFJH015', 'Simplus Ấm pha cà phê Moka Chiết xuất áp suất cao Dung tích 150ml Cà phê Espresso kiểu Ý KFJH015- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(850, 1, 'FLL003WD00', 'FLL003', 'Simplus Bộ thìa gỗ gia dụng muỗng, muôi súp, thìa chéo, thìa cơm, chuyên dụng cho chảo chống dính, chịu nhiệt độ cao CFLL003', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(851, 1, 'CFLL003WD00', 'CFLL003', 'Bộ thìa gỗ gia dụng muỗng Simplus muôi súp, thìa chéo, thìa cơm, chuyên dụng cho chảo chống dính, chịu nhiệt độ cao', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(852, 1, 'KQZG007GR01-VIP', 'KQZG007', 'Simplus Nồi chiên không dầu 4L, Nồi chiên không dầu đa năng không dầu mỡ bếp chiên không dầu dung tích lớn, sang trọng  tiết kiệm thời gian KQZG007- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(853, 1, 'XCQH008GY03FZ03', 'XCQH008', '[New arrival Simplus Máy Hút Bụi  Nhỏ Lực Hút Mạnh Mẽ 16590PA Phù Hợp Cho  Gia Đình Máy Hút Bụi Làm Sạch XCQH008 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(854, 1, 'KQZG007BK01-VIP', 'KQZG007', 'Simplus Nồi chiên không dầu 4L, Nồi chiên không dầu đa năng không dầu mỡ bếp chiên không dầu dung tích lớn, sang trọng  tiết kiệm thời gian KQZG007', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(855, 1, 'JMQH001WH01', 'JMQH001', 'Simplus Súng massage cầm tay, máy massage cơ đa chức năng, 4 đầu massage, xoa dịu phần cơ đang căng cứng JMQH001- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(856, 1, 'KQZG007CW01-VIP', 'KQZG007', 'Simplus Nồi chiên không dầu 4L, Nồi chiên không dầu đa năng không dầu mỡ bếp chiên không dầu dung tích lớn, sang trọng  tiết kiệm thời gian KQZG007- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(857, 1, 'KFJH012BK00', 'KFJH012', '[New Arrival]Simplus Máy pha cà phê  Dung tích lớn 1.25L 10 Ly Tự động nhỏ giọt Pha thủ công Pha trà KFJH012- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(858, 1, 'DZEG003WH01', 'DZEG003', 'Simplus Nồi hấp điện  3 Tầng kết hợp  Dung tích lớn 14L  Hấp trứng hấp cá hấp bánh- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(859, 1, 'DHGH002WH00FZ01', 'DHGH002', 'Simplus Nồi lẩu điện đa năng dạng tách rời 4.2L, nồi điện chống dính gia dụng 1400W, đun nấu, hầm canh, chiên xào, beefsteak- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(860, 1, 'JFBA010PK00', 'JFBA010', '[New Arrival] Simplus Máy uốn tóc tự động 32mm, uốn lọn to giữ được lâu, không làm hư tóc- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(861, 1, 'DHGH002CW00', 'DHGH002', 'Simplus Nồi lẩu điện đa năng dạng tách rời 4.2L, nồi điện chống dính gia dụng 1400W, đun nấu, hầm canh, chiên xào, beefsteak- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(862, 1, 'CUSH005WH00', 'CUSH005', 'Simplus Máy hút ẩm lọc không khí 2in1, gia dụng, bình chứa nước 1.5L- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(863, 1, 'JASH003WH00', 'JASH003', 'Simplus Máy tạo ẩm Tạo ẩm gia đình, bàn làm việc, ô tô Dung tích 300ml Cổng sạc Type-C JASH003- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(864, 1, 'CUSH004WH02', 'CUSH004', '[New Arrival] Simplus Máy Hút Ẩm Máy Hút Ẩm 1L Văn Phòng Nhỏ Hộ Gia Đình Hút Ẩm Khô Im Lặng Chống Ẩm Tiết Kiệm Điện CUSH004 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(865, 1, 'LVXI-JSQH005WH00', 'LVXI-JSQH005', 'Simplus Lõi 7 Lớp Lọc Chính Xác, Độ Lọc Chính Xác 0.1 Micron Bằng Lõi Gốm', 'Cái', '8', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(866, 1, 'XCQH013WH00', 'XCQH013', 'Simplus Máy hút bụi màn hình LED không dây, gia dụng 24000 Pa, 6 chế độ lực hút, công suất cao 250W XCQH013- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(867, 1, 'DFSH009WH00', 'DFSH009', 'Simplus Quạt Đứng Và Quạt Bàn Hai Chức Năng Cánh quạt hai lớp Tạo gió mềm mại tự nhiên Hoạt động yên tĩnh và tiết kiệm năng lượng Ba mức độ gió DFSH009 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(868, 1, 'DFSH014WH00', 'DFSH014', 'Simplus Quạt để bàn mini Thiết kế xách tay Điều chỉnh không cấp Sử dụng liên tục 16 tiếng Cổng sạc Type-C DFSH014- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(869, 1, 'GTJH005PP00', 'GTJH005', 'Simplus Bàn ủi điện hơi nước cầm tay - Ủi khô ủi hơi nước kết hợp - Tiện lợi sử dụng gia đình - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(870, 1, 'XCQH002WH00FZ01', 'XCQH002', 'Simplus Máy hút bụi 13000PA  Lực hút lớn，Máy hút bụi gia đình hút ô tô xe hơi thiết kế tối giản sang trọng, bảo hành 1 năm 1 đổi 1- XCQH002', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(871, 1, 'ZENP016KK00', 'ZENP016', 'Tạp dề Tạp dề chống thấm nước và chống dầu nhà bếp  Bảo vệ quần áo không bị dính bẩn cà phê thức ăn ZENP016', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(872, 1, 'CMYH005GY01', 'CMYH005', '[New Arrival] Simplus Máy hút bụi giường nệm 14000Pa, khử mạt bụi, rung đập với tần số cao, hút bụi trên giường, vệ sinh thảm, hút lông tóc CMYH005- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(873, 1, 'KFJH018WH00', 'KFJH018', 'Simplus Máy Pha Cà Phê Máy Pha Cà Phê Đa Năng Mỹ Có thể Dùng Để Pha Cà Phê Và Trà Thiết Kế Nhỏ Gọn Dung Tích Bình Chứa Nước 250ml KFJH018 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(874, 1, 'MDJH004WH00', 'MDJH004', 'Simplus Máy Xay Cà Phê Điện Máy Xay Bột Thông Minh Gia Đình 35 Mức Độ Xay Từ Thô Đến Mịn Có thể Tùy Chỉnh Lượng Xay MDJH004- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(875, 1, 'XCQH014BK00', 'XCQH014', 'Simplus Máy hút bụi  Máy hút bụi gia đình lực hút mạnh Đa chức năng 3 đầu hút thay thế Lực hút mạnh 18000pa XCQH014 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(876, 1, 'BWHU001WH01', 'BWHU001', 'Simplus Phích giữ nhiệt   Mặt trong bằng thép không gỉ Dung tích 2L Giữ ấm 48H  Ấn để mở nắp BWHU001 - Bảo hành 1 năm 1 đổi 1', 'Cái', '8', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(877, 1, 'RFSH001WP00', 'RFSH001', 'Lược chải điện Simplus  Tiện lợi  Đa chức năng  Tạo kiểu    Sấy khô  Trải nghiệm Salon chuyên nghiệp RFSH001', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(878, 1, 'JASH004WH00', 'JASH004', 'Simplus Máy tạo ẩm Máy tạo ẩm lổ phun kép để bàn Thiết kế đèn tạo không gian Dung tích 500ml Cổng sạc Type-C JASH004- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(879, 1, 'GTJH020PK00', 'GTJH020', '[New Arrival] Simplus Bàn ủi hơi nước cầm tay  Công suất cao 1200W Bình chứa nước 180ml Gấp gọn tiện lợi Ủi đứng nằm hai kiểu- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(880, 1, 'CFJH008WH00', 'CFJH008', '[New Arrival] Simplus Máy Sấy Tóc Có Thể Gấp Gọn Ion Âm Bảo Vệ Tóc 3 Mức Sấy Màu Macaron CFJH008- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(881, 1, 'LLJH010WH01FZ01', 'LLJH010', 'Simplus Máy Xay Sinh Tố Đa Chức Năng 1.25L Công suất lớn 380W 3 cối đa dụng - Bảo Hành 1 Năm 1 Đổi 1 LLJH005', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(882, 1, 'KFJH014WH00', 'KFJH014', '[New Arrival] Simplus Máy Pha Cà Phê Chiết xuất nhỏ Giọt Tự Động 15Bar Áp xuất sâu Bình nước 12L Đồng hồ đo nhiệt độ KFJH014 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(883, 1, 'DFSH013WH00', 'DFSH013', '[New Arrival] Simplus Quạt cầm tay Quạt cầm tay không khí nén lạnh 100 tốc độ gió Cổng sạc Type-C DFSH013', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(884, 1, 'ZZJH008WH01', 'ZZJH008', '[New Arrival] Simplus Máy Xay Trái Cây Cốc không dây dễ mang đi uống trực tiếp Dung tích 340ML 10 Lưỡi dao xay Máy xay trái cây đa năng Xay Hoa Quả Rau Củ ZZJH008 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(885, 1, 'BYJH002WH00', 'BYJH002', 'Simplus Máy giặt cầm tay vệ sinh sofa Simplus, lực hút lớn 16kpa, tách sạch bụi bẩn, trụ phun nước tặng áp, có tay cầm- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(886, 1, 'TTQP-SMZJ004FZ01', 'TTQP-SMZJ004', 'Simplus Máy nướng  bánh mì ，Máy nướng bánh dành cho  gia đình với  hai khay ép lò nướng đa chức năng SMZJ004- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(887, 1, 'DZGH011WH00', 'DZGH011', '[New Arrival] Simplus Nồi điện đa năng Nồi đa năng 1.7L  2 Mức điều chỉnh  Nấu lẩu hầm thịt nấu cháo DZGH011- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(888, 1, 'DDGU001WH01', 'DDGU001', '[New Arrival] Simplus Nồi hầm điện Nồi hầm 1L Hầm cách thủy Menu cài sẵn thông minh Nấu súp, nấu cháo, hấp trứng Thực phẩm ăn dặm cho bé  DDGU001', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(889, 1, 'DDJR006WH01', 'DDJR006', '[New Arrival] Simplus Máy xay thịt Máy xay điện gia dụng Máy xay nguyên liệu đa chức năng Máy cắt rau củ DDJR006- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(890, 1, 'ZZJH009CW01', 'ZZJH009', '[New Arrival] Simplus Máy ép trái cây Ép chậm Miệng rộng 103mm Tách bã trái cây ZZJH009', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(891, 1, 'DAOJ001WH00', 'DAOJ001', 'Simplus Bộ dao, bộ 5 dao, dao bằng thép không gỉ, kèm giá dao, dao thái thịt, dao cắt rau củ quả DAOJ001- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(892, 1, 'GTJH009WH01', 'GTJH009', 'Số đơn hàng: 494827008993130. [New Arrival] Simplus Bàn ủi hơi nước đứng 2 Thanh đứng Ủi đứng nằm 2 in 1 Bình nước 1.8L GTJH009- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(893, 1, 'KFJH016BK00', 'KFJH016', 'Số đơn hàng: 494794605739297. Simplus Bình Pha Cà Phê Moka Hai van tăng áp Chiết xuất dầu phong phú Cà phê Espresso kiểu Ý KFJH016 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(894, 1, 'CFJH010PK01', 'CFJH010', '[New Arrival] Simplus Máy sấy tóc Tốc độ cao Gia đình nhiệt độ ổn định 200 triệu ion âm chăm sóc tóc Hai màu tùy chọn hồng ngọc trai hoặc trắng CFJH010', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(895, 1, 'CMYH006GY00', 'CMYH006', '[New Arrival] Simplus Máy Hút Bụi Giường Nệm Thiết kế cốc đôi Tiệt trùng UV Đánh bụi 14000 vòng/phút Hút mạnh 16000pa Lọc HEPA F9 CMYH006 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(896, 1, 'RFSH003GY01', 'RFSH003', '[New Arrival] Simplus Lược Điện Máy tạo kiểu tóc đa chức năng 5 trong 1 Máy uốn duỗi sấy Sấy nhanh tốc độ cao Ion âm bảo vệ tóc RFSH003 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(897, 1, 'ZENP022RD00', 'ZENP022', 'Simplus Sticker Giáng Sinh ZENP022', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(898, 1, 'LFSH005WY01', 'LFSH005', '[New Arrival] Simplus Quạt làm mát Bình chứa nước 24L Hẹn giờ 12 tiếng 3 Tốc độ Điều khiển từ xa LFSH005', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(899, 1, 'ASBH001TR00', 'ASBH001', 'Simplus Cốc Đong 90mL Cốc Cà Phê Thủy Tinh Borosilicate Cao Cấp Tay Cầm Bằng Gỗ ASBH001', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(900, 1, 'JSQH003WH00FZ01', 'JSQH003', 'Simplus Máy lọc nước gia dụng, lọc vòi nước nhà bếp và nhà vệ sinh, lõi lọc phức hợp hiệu quả cao, 2 kiểu xả nước, nước đã lọc và chưa lọc JSQH003', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(901, 1, 'LLJH008WH01', 'LLJH008', '[New Arrival] Simplus Máy xay dạng núm vặn 1.5L Simplus, máy xay hoa quả, thực phẩm khô, đa năng 2in1, máy xay hoa quả, máy nghiền- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(902, 1, 'KFJH019WH00', 'KFJH019', '[New Arrival] Simplus Máy Pha Cà Phê Máy pha cà phê dạng viên nén Áp suất cao 20Bar Nhỏ gọn cho gia đình và văn phòng Tùy chọn cốc nhỏ cốc lớn KFJH019 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(903, 1, 'GUOJ038CW01', 'GUOJ038', 'Simplus Tay cầm rời nồi gia đình bộ nồi chảo chống dính full set chảo rán nồi canh chảo lồng nồi cho bé GUOJ029', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(904, 1, 'DFSH010BL00', 'DFSH010', 'Simplus Quạt gió, quạt pin mini cầm tay, di động, 3 mức gió- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(905, 1, 'DFSH010PP00', 'DFSH010', 'Simplus Quạt gió, quạt pin mini cầm tay, di động, 3 mức gió- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(906, 1, 'KQJH007WH00', 'KQJH007', 'Số đơn hàng: 500141124079965. [New Arrival] Simplus Máy lọc không khí gia đình Bộ lọc HEPA hiệu suất cao  Giá trị CADR lên tới 300m³/h  Siêu yên tĩnh 35dB   Chế độ tự động thông minh KQZJH007', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(907, 1, 'DZEG006WH01', 'DZEG006', '[New Arrival] Simplus Nồi Hấp Trứng Nồi Hấp Đa Năng 7 Chế Độ Hẹn Giờ 24 Tiếng Điều Khiển Cảm Ứng Hấp Trứng Làm Sữa Chua DZEG006', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(908, 1, 'CFJH010WH01', 'CFJH010', '[New Arrival] Simplus Máy sấy tóc Tốc độ cao Gia đình nhiệt độ ổn định 200 triệu ion âm chăm sóc tóc Hai màu tùy chọn hồng ngọc trai hoặc trắng CFJH010', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(909, 1, 'ZENP009BK00', 'ZENP009', 'Simplus Đầu cắm chuyển đổi bằng đồng nguyên chất', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(910, 1, 'ZFBA006WH00', 'ZFBA006', 'Simplus Máy Duỗi Tóc Không Dây Di Động Mặt Phẳng 3D Sạc Type-C Nhiệt Độ Mặc Định 180°C ZFBA006 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(911, 1, 'LLJH010WH02', 'LLJH010', 'Simplus Máy xay đa năng 1.25L, máy xay sinh tố, 3 chế độ xay, 3 cối thay đổi, cối di động, cối thủy tinh Mason- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(912, 1, 'KQZG021WH01-VIP', 'KQZG021', '[New Arrival]Simplus Nồi Chiên Không Dầu Dung Tích 2.5L Dễ Thương Mini Thiết Kế Gọn Gàng Tiết Kiệm Không Gian Phù Hợp Gia Đình Nhỏ Hoặc Ký Túc Xá Chiên Rán Đồ Ăn Vặt Đa Năng Ít Dầu Mỡ KQZG021', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44');
INSERT INTO `products` (`id`, `product_user_id`, `sku`, `accounting_code`, `product_name`, `unit`, `tax_rate`, `created_at`, `updated_at`) VALUES
(913, 1, 'ZENP018BL00', 'ZENP018', 'Simplus Giá Đỡ Điện Thoại ZENP018', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(914, 1, 'BLFH002TR01', 'BLFH002', 'Simplus Hộp đựng sữa bột, chống ánh sáng, màu trà, dạng một nhấn, hộp đựng thực phẩm đậy kín, không chứa BPA BLFH002', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(915, 1, 'ZHJSQH005WH00+LVXI*1', 'ZHJSQH005+ LVXI*1', 'Simplus Máy lọc nước tại vòi , 7 tầng lọc, lõi lọc gốm sứ dễ dàng vệ sinh, dùng cho nhà bếp và nhà vệ sinh JSQH005- Bảo hành 1 năm 1 đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(916, 1, 'CYQH002WH01', 'CYQH002', 'Simplus Máy Tăm Nước Sạc Không Dây Mang Đi Du Lịch 3 Chế Độ 4 Vòi Xịt Bình Nước Tháo Rời 200mL Tần Số Xung 1600 Lần/phút CYQH002', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(917, 1, 'ZHLLJH004 + GMBE-LLJH004', 'ZHLLJH004 +GMBE-LLJH004', 'Simplus Bàn Ủi Hơi Nước Cầm Tay Simplus Bình Chứa Nước 170ml GTJH011 Bảo Hành 1 Năm Chỉ Đổi Không Sửa,Ủi Quần Áo Là Quần Áo Bàn Là Hơi', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(918, 1, 'LLJH004GY01', 'LLJH004', 'SimplusVN Máy Xay Sinh Tố Simplus Dung Tích 600ml Đa Chức Năng LLJH004，Máy Xay Trái Cây Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(919, 1, 'XCQH008GY04', 'XCQH008', 'Máy Hút Bụi Simplus 16590 PA Máy Hút Bụi Có Dây Lực Hút Mạnh Mẽ XCQH008 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(920, 1, 'GTJH020PK00FZ04', 'GTJH020', 'SP01 Bàn ủi hơi nước cầm tay Simplus GTJH020, Công suất 1200W, Bình chứa nước 180ml, Gấp gọn tiện lợi Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(921, 1, 'GTJH020WH00FZ04', 'GTJH020', 'SP01 Bàn ủi hơi nước cầm tay Simplus GTJH020, Công suất 1200W, Bình chứa nước 180ml, Gấp gọn tiện lợi Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(922, 1, 'ZHCFJH001+JFBA009', 'ZHCFJH001+JFBA009', 'Combo 01 Máy Sấy Tóc 2 Chiều Nóng Lạnh & 01 Máy Duỗi Uốn Tóc 2 Trong 1 CFJH001 & JFBA009 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(923, 1, 'CFJH001GY02', 'CFJH001', 'SP01 Máy Sấy Tóc 2 Chiều Nóng Lạnh Simplus Công Suất 1250W Thiết Kế Tinh Tế CFJH001 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(924, 1, 'GTJH005BL01FZ01', 'GTJH005', 'Bàn Ủi Khô Simplus Bàn Ủi Cầm Tay Gia Dụng Công Suất 1300W GTJH005 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(925, 1, 'DZGH003WH01FZ01', 'DZGH003', 'Nồi Điện Đa Năng Simplus Dung Tích 1.5L Kèm Khay Hấp Inox DZGH003 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(926, 1, 'CUSH002WH01FZ01', 'CUSH002', 'Simplus Máy Hút Ẩm CUSH002 Công Suất 380ml/Ngày,  Dung Tích Bình Nước 2.5L, Màn hình LCD, Có Xông Tinh Dầu, Dùng Cho Phòng Nhỏ Căn Hộ Thời Tiết Ẩm Nồm, Tiết Kiệm Điện Năng, Độ Ồn Thấp Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(927, 1, 'ZZJH006WH00FZ01', 'ZZJH006', 'Simplus Máy Xay Trái Cây Mini Cầm Tay ZZJH006, Dung Tích Cốc 400ML Công Suất 80W Sạc Pin  Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(928, 1, 'GMBE-LLJH004', 'GMBE-LLJH004', 'Simplus Máy Xay Sinh Tố Simplus Dung Tích 600ml Đa Chức Năng LLJH004 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '8', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(929, 1, 'KQZG007GR01FZ02', 'KQZG007', 'SP01 Nồi Chiên Không Dầu Simplus Dung Tích 4L Tặng Giấy Nướng KQZG007 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(930, 1, 'XCQH015BG00', 'XCQH015', 'SimplusVN Máy Hút Bụi Làm Sạch Simplus XCQH015, 2 Đầu Hút Thay Đổi, Lực Hút Mạnh 22000 Pa, Cốc Chứa Bụi Lớn 1.2l, Có Bánh Xe Di Chuyển Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(931, 1, 'LVWA-LLJH005', 'LVWA-LLJH005', 'SimplusVN Lưới lọc Bã Trái Cây Bằng Thép Không Gỉ Phụ Kiện Máy Xay LLJH005, Lọc bã Trái Cây Tăng Độ Mịn Khi Xay Sinh Tố, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(932, 1, 'CFJH001GY00FZ01', 'CFJH001', 'Simplus Máy Sấy Tóc 2 Chiều Nóng Lạnh Simplus Công Suất 1250W CFJH001 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(933, 1, 'XCQH008GY03', 'XCQH008', 'Máy Hút Bụi Simplus 16590 PA Máy Hút Bụi Có Dây Lực Hút Mạnh Mẽ XCQH008 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(934, 1, 'SMZJ001PK00FZ01', 'SMZJ001', 'Simplus Máy Làm Bánh Mì Sandwich Simplus Công Suất 650W SMZJ001 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(935, 1, 'CUSH006WH00', 'CUSH006', 'SimplusVN Máy Hút Ẩm Công Suất Lớn 12l/Ngày CUSH006, 3 Chức Năng 2 Mức Tốc Độ Gió, Thao Tác Cảm Ứng, Bình Nước 2l, Chức Năng Bảo Vệ Kép An Toàn, Hen Giờ 24h, Đèn Cảm Ứng Độ Ẩm, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(936, 1, 'DZGH011WH02', 'DZGH011', 'Simplus Nồi Lẩu Điện đa năng 1.7L Lòng Nồi Chống Dính Ceramic DZGH011, Nắp kính cường lực, 2 Mức điều chỉnh nhiệt, Bảo vệ quá nhiệt, Nấu lẩu hầm thịt nấu cháo Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(937, 1, 'LFSH004WY00', 'LFSH004', 'SimplusVN Quạt Điều Hòa Làm Mát Cho Gia Đình LFSH004, Bình Nước 10l, Điều Khiển Từ Xa, Hẹn Giờ 7,5 Tiếng, Kèm Hộp Đá Khô, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(938, 1, 'JSQH003WH00+LVXI*2', 'ZHJSQH003+LVXI*2', 'Simplus Bộ Lọc Nước Tại Vòi 6 Tầng Lọc JSQH003 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(939, 1, 'CUSH002WH01+XXHE*2', 'ZHCUSH002+XXHE-CUSH002*2', 'Simplus Máy Hút Ẩm Dung Tích Lớn 2.5L Dành Cho Diện Tích 70㎡ CUSH002 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(940, 1, 'JSQH001WH01+LVXI*1', 'ZHJSQH001+LVXI*1', 'Simplus Máy Lọc Nước Siêu Lọc JSQH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(941, 1, 'ZH-JSQH005WH00+2LVXI', 'ZHJSQH005+ LVXI*2', 'Simplus Đầu Lọc Nước Tại Vòi 7 Tầng Lọc JSQH005 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(942, 1, 'KFJH014WH00+MDJH002SS00', 'ZHKFJH014+MDJH002', 'Simplus Máy Pha Cà Phê Bán Tự Động Kiểu Ý Áp Suất Sâu 15 Bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(943, 1, 'LLJH004GY01+GMBE', 'ZHLLJH004 +GMBE-LLJH004', 'Simplus Bàn Ủi Hơi Nước Cầm Tay Simplus Bình Chứa Nước 170ml GTJH011 Bảo Hành 1 Năm Chỉ Đổi Không Sửa,Ủi Quần Áo Là Quần Áo Bàn Là Hơi', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(944, 1, 'XCQH002WH00+XCLX002WH00', 'ZHXCQH002+XCLX002', 'Simplus Máy Hút Bụi Có Dây Công Suất 400W Lực Hút 13000Pa XCQH002 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(945, 1, 'LLJH005WH01+LVWA-LLJH005', 'ZHLLJH005+LVWA-LLJH005', 'Simplus Combo Máy Xay Sinh Tố Đa Chức Năng Dung tích 1.25Lít LLJH005- Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(946, 1, 'DFSH010GR00', 'DFSH010', 'Simplus Quạt gió, quạt pin mini cầm tay, di động, 3 mức gió- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(947, 1, 'LFSH004WY01', 'LFSH004', '[New Arrival] Simplus Quạt làm mát Quạt điều hòa cho gia đình Bình nước 10L Điều khiển từ xa Quạt điều hòa LFSH004', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(948, 1, 'JSQH004WH00', 'JSQH004', 'SimplusVN Máy lọc nước tại vòi Simplus JSQH004, 6 tầng lọc, thanh carbon có thể xé, 2 mức xả nước Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(949, 1, 'ZH-CFLL002WHGC+CFLL002WHTS', 'ZHCFLL002', 'INSSA đồ dùng nhà bếp bằng Silicon tay cầm gỗ sồi chịu nhiệt cao chuyên dụng Vá đặc, Vá lỗ, Xẻng đặc ZHCFLL002', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(950, 1, 'ZHGUOJYY04A', 'ZHGUOJYY04A', 'INSSA [Nồi bếp từ] Combo chảo có nắp đậy Tay cầm chống ghỉ Dụng cụ nấu ăn lành mạnh không chứa PFOA GUOJ016-19', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(951, 1, 'KFJH014WH00+MDJH004WH00', 'ZHKFJH014+MDJH004', 'Combo Máy Pha Cà Phê Bán Tự Động Kiểu Ý Simplus Áp suất sâu 15 bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(952, 1, 'ZHDZGH002+DDJR004', 'ZHDZGH002+DDJR004', 'Combo 01 Nồi Lẩu Điện Đa Năng Simplus Dung Tích 1,5L DZGH002 & 01 Máy Xay Thịt Simplus Dung Tích 2L 4 Lưỡi Dao DDJR004 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(953, 1, 'KQZG007CW00FZ01', 'KQZG007', 'Nồi Chiên Không Dầu Simplus Dung Tích 4L Chiên Nướng Đa Năng Không Dầu Mỡ KQZG007 Bảo Hành 1 Năm Chỉ Đổi Không Sửa SP02', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(954, 1, 'ZHGUOJFK02E', 'ZHGUOJFK02E', 'INSSA Combo [Nồi bếp từ] 18/24cm chảo chống dính chảo gia dụng bếp gas cảm ứng chảo rán chảo gốm chảo rán GUOJ022-23', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(955, 1, 'CFJH011GD01', 'CFJH011', 'Simplus Máy Sấy Tóc Hyper-SIM Aura 10 Chế Độ Sấy Tốc Độ Gió 70m/s Động Cơ Không Chổi Than Tốc Độ Cao 110.000RPM 200 Triệu Ion Âm Độ Ồn Thấp 59dB Trọng Lượng 295g Chế Độ Điều Khiển Nhiệt Độ NTC Chức Năng Tự Làm Sạch CFJH011', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(956, 1, 'ZHGUOJXC03A', 'ZHGUOJXC03A_', 'Bộ nồi chảo đá chống dính màu Vani cao cấp INSSA chính hãng, dùng cho bếp từ, ga', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(957, 1, 'GUOJ037CW00', 'GUOJ037', 'INSSA Chảo chiên INSSA hình chữ nhật GUOJ037 chống dính thích hợp cho nhiều loại bếp', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(958, 1, 'GUOJ026CW01', 'GUOJ026', 'InssaVN Quánh chống dính 20cm GUOJ026, nấu thức ăn dặm hâm sữa không kén loại bếp, dòng Caramel', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(959, 1, 'DFSH016WH00', 'DFSH016', 'SimplusVN Quạt Mini Để Bàn Màn Hình LED DFSH016, Chân Đế Xoay 180° , Sạc Type-C, Xông Tinh Dầu, 5 Chế Độ Gió, Dùng Liên Tục 7.6H,  Có Quai Treo Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(960, 1, 'KQZG014WH01FZ01', 'KQZG014', 'Simplus Nồi Chiên Không Dầu Cửa Kính Trong Suốt 5L KQZG014, 2 Núm Cơ Chỉnh Nhiệt Độ Và Thời Gian, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(961, 1, 'KQJH008WH00', 'KQJH008', 'SimplusVN Máy Lọc Không Khí Dùng Cho Bàn Làm Việc Phòng Ngủ Nhỏ KQJH008, Bộ Lọc HEPA H11, Loại Bỏ Chất Gây Dị Ứng, 3 Mức Độ Lọc, Hẹn Giờ 8 Tiếng, Có Thể Dùng Tinh Dầu, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(962, 1, 'ZHXCQH002+CMYH006', 'ZHXCQH002+CMYH006', 'Combo 01 Máy Hút Bụi Giường Nệm  CMYH006 & 01 Máy Hút Bụi Cầm Tay Có Dây Lực Hút 13000Pa XCQH002 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(963, 1, 'GUOJ030CW01', 'GUOJ030', 'INSSA [BH 1 Năm] Bộ 4 nồi chảo đá chống dính Maifan cao cấp Chảo rán, chảo xào, nồi canh, quánh chống dính GUOJ030', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(964, 1, 'GUOJ020CW02', 'GUOJ020', 'INSSA [BH 1 Năm] Nồi nấu 18/20cm Nồi tuyết Nhật Nồi sữa Nồi đựng thức ăn cho bé cao cấp GUOJ020', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(965, 1, 'ZHGUOJXC02C', 'ZHGUOJXC02C_', 'INSSA [BH 1 Năm] Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng, dùng cho bếp từ GUOJ10-13', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(966, 1, 'ZHGUOJXC02B', 'ZHGUOJXC02B_', 'INSSA [BH 1 Năm] Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng, dùng cho bếp từ GUOJ10-13', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(967, 1, 'ZHGUOJYY02B', 'ZHGUOJYY02B', 'INSSA Bộ nồi Chảo có nắp đậy Tay cầm chống ghỉ Dụng cụ nấu ăn lành mạnh không chứa PFOA GUOJ016-19', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(968, 1, 'DFSH015PK00', 'DFSH015', 'Simplus Pink Mini Quạt Cầm Tay Tiện Lợi Có Thể Gập Lại- Type-C Sử Dụng Liên Tục 6 Tiếng DFSH015 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(969, 1, 'DFSH015WH00', 'DFSH015', 'Simplus Pink Mini Quạt Cầm Tay Tiện Lợi Có Thể Gập Lại- Type-C Sử Dụng Liên Tục 6 Tiếng DFSH015 - Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(970, 1, 'XCQH014BK00FZ01', 'XCQH014', 'Simplus Máy hút bụi gia đình Simplus XCQH014, lực hút mạnh 18000pa, 3 đầu hút thay thế, dây dài 4.5M Làm Sạch Dễ Dàng Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(971, 1, 'ZZJH009CW01FZ01', 'ZZJH009', 'Simplus Máy Ép Chậm Trái Cây ZZJH009, Miệng Máy 10.3CM, Máy Ép Nước Hoa Quả Đảo Chiều Tránh Tắc Nghẽn, Tiện Dụng Cho Gia Đình , Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(972, 1, 'GUOJ034SS00', 'GUOJ034', 'INSSA Bộ nồi inox 304 cao cấp 3 lớp đáy liền Đáy từ dùng mọi loại bếp chắc và bền 16/20/24cm GUOJ034', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(973, 1, 'ZH-KFJH011BK00+MDJH002SS00', 'ZHKFJH011+MDJH002', 'INSSA Máy pha cà phê Dạng đồng hồ cát tự động Đa chức năng Dung tích lơn 600ml KFJH011FZ', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(974, 1, 'KQZG018CW01-VIP', 'KQZG018', 'Simplus Nồi Chiên Không Dầu Dung Tích Lớn 6.5L Công Suất Cao 1500W KQZG018 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(975, 1, 'GTJH005BL00-VIP', 'GTJH005', 'Simplus Bàn Ủi Khô Công Suất 1000W GTJH005 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(976, 1, 'KQZG015GY01-VIP', 'KQZG015', 'Simplus Nồi Chiên Không Dầu  Dung tích lớn 5L KQZG015/014 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(977, 1, 'KQZG017CW01-VIP', 'KQZG017', 'Simplus Nồi Chiên Không Dầu Dung Tích 3.5L Lòng Nồi Thủy Tinh KQZG017 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(978, 1, 'XCQH013GY00', 'XCQH013', '[Bản nâng cấp]Simplus Máy Hút Bụi Lực Hút 24000Pa XCQH013 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(979, 1, 'SMZJ001GR00-VIP', 'SMZJ001', 'Máy Kẹp Nướng Bánh Mì sandwich Simplus Máy làm bánh mì sandwich máy làm bánh thức ăn nhẹ đa chức năng nhanh gọn tiện lợi', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(980, 1, 'DDJR004', 'DDJR004', 'Simplus Máy Xay Thịt 2L Lưỡi Dao Thép Không Gỉ DDJR004 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(981, 1, 'BLFH001TR01', 'BLFH001', 'Simplus Hộp Đựng Thực Phẩm Thủy Tinh Chịu Nhiệt Tốt BLFH001', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(982, 1, 'KQZG014GY01-VIP', 'KQZG014', 'Simplus Nồi Chiên Không Dầu Dung Tích Lớn 5L KQZG015-013 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(983, 1, 'MDJH001', 'MDJH001', 'Simplus Máy Xay Hạt Cà Phê MDJH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(984, 1, 'SMZJ001PK00-VIP', 'SMZJ001', 'Simplus Máy Kẹp Bánh Mì Sandwich SMZJ001 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(985, 1, 'SMZJ001CW00-VIP', 'SMZJ001', 'Simplus Máy Kẹp Bánh Mì Sandwich SMZJ001 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(986, 1, 'JASH005WH00', 'JASH005', 'Simplus Máy Tạo Ẩm Dùng Trên Xe Hoặc Bàn Làm Việc Sạc Type-C Không Dây Dung Tích 250mL Dùng Liên Tục 14h JASH005', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(987, 1, 'KQZG017CW01+SPJA', 'ZHKQZG017+SPJA001', 'Simplus Nồi Chiên Không Dầu Dung Tích 3.5L Lòng Nồi Thủy Tinh KQZG017 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(988, 1, 'KFJH020TR01', 'KFJH020', 'InssaVN Bộ Bình Cà Phê Nhỏ Giọt KFJH020, Bình Thủy Tinh Borosilicate, Hoa Văn Xoắn Ốc Sang Trọng Độc Đáo, Tặng Kèm 20 Tấm Giấy Lọc Cà Phê', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(989, 1, 'GUOJ036YL00', 'GUOJ036', 'InssaVN Quánh chống dính màu pastel 16cm GUOJ036, nấu sữa nấu mì tiện lợi phù hợp nhiều loại bếp, dòng Maracon', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(990, 1, 'GTJH020PK00FZ05', 'GTJH020', 'SP04 Bàn ủi hơi nước cầm tay Simplus GTJH020, Công suất 1200W, Bình chứa nước 180ml, Gấp gọn tiện lợi Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(991, 1, 'GTJH020WH00FZ01', 'GTJH020', 'Simplus Bàn ủi hơi nước cầm tay Simplus GTJH020, Công suất 1200W, Bình chứa nước 180ml, Gấp gọn tiện lợi Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(992, 1, 'GTJH022CW00-VIP', 'GTJH022', 'Simplus Bàn Ủi Hơi Nước Cầm Tay 2 Trong 1 Ủi Ướt Và Ủi Khô GTJH022 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(993, 1, 'GTJH015CW00-VIP', 'GTJH015', 'Simplus Bàn Ủi Hơi Nước Cầm Tay 2 Trong 1 Ủi Ướt Và Ủi Khô GTJH015 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(994, 1, 'ZFBA006WH01', 'ZFBA006', 'Simplus Máy Duỗi Tóc Không Dây Di Động ZFBA006 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(995, 1, 'CFJH009GY00', 'CFJH009', '[Sản phẩm mới]Simplus Máy Sấy Tóc Tốc Độ Cao 400 Triệu Ion Âm Tốc độ gió cao 65m/s CFJH009 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(996, 1, 'CWHL001WY00', 'CWHL001', 'Simplus Máy Hút Bụi Chăm Sóc Thú Cưng Cắt Tỉa Chải Lông Sấy Độ Ồn Thấp 16000Pa  CWHL001 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(997, 1, 'GTJH014WY01+YYST', 'ZHGTJH014+YYST001', 'Simplus Bàn Ủi Hơi Nước Đứng Công Suất Lớn 2000W GTJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(998, 1, 'SMZJ005CW00-VIP', 'SMZJ005', 'Simplus Máy Làm Bánh Donut 800W Thiết kế 8 lỗ SMZJ005 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(999, 1, 'ZHJSQH001WH01+ LVXI*1', 'ZHJSQH001+LVXI*1', 'Simplus Máy lọc nước siêu lọc Gia dụng Máy siêu lọc nhà bếp Bộ vòi lọc Vòi lọc tổng hợp SUF siêu lọc JSQH001- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1000, 1, 'ZHGTJH011PK+YYST001', 'ZHGTJH011+YYST001', 'Simplus Bàn ủi hơi nước cầm tay, Công suất 1200W, Dung tích bình chứa nước 180ML, Bàn là hơi nước có thể gấp gọn tiện lợi mang theo du lịch, công tác GTJH011- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1001, 1, 'XCQH008GY04FZ02', 'XCQH008', 'Máy Hút Bụi Cầm Tay Simplus Có Dây Lực Hút 13000Pa XCQH002 Bảo Hành 1 Năm Chỉ Đổi Không Sửa Làm Sạch nhà cửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1002, 1, 'XCQH002WH00FZ02', 'XCQH002', 'Simplus Máy Hút Bụi Cầm Tay Có Dây Lực Hút 13000Pa XCQH002, Làm Sạch nhà cửa, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1003, 1, 'GTJH020PK00FZ03', 'GTJH020', 'SP03  Bàn Ủi Hơi Nước Cầm Tay Simplus Bình Chứa Nước 180ml GTJH020 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1004, 1, 'KQJH004', 'KQJH004', 'INSSA Máy lọc không khí Khử trùng gia đình, Loại bỏ bụi mịn, Loại bỏ khói mù, Loại bỏ mùi hôi KQJH004', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1005, 1, 'ZHCFJH001+MFSH001', 'ZHCFJH001+MFSH001', 'Simplus Máy Sấy Tóc Đa Năng 2 Kiểu Gió Nóng Lạnh, 3 Tốc Độ Gió, Nhỏ Gọn Tiện Lợi  220V Công Suất 1250W - CFJH001- Bảo hành 1 năm 1 đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1006, 1, 'KQZG007BK00FZ01', 'KQZG007', 'Nồi Chiên Không Dầu Simplus Dung Tích 4L Chiên Nướng Đa Năng Không Dầu Mỡ KQZG007 Bảo Hành 1 Năm Chỉ Đổi Không Sửa SP02', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1007, 1, 'LLJH010WH02FZ01', 'LLJH010', 'Simplus Máy Xay Sinh Tố Simplus 1,25L LLJH010, Máy Xay Trái Cây 2 Cối Tiện Lợi, Làm Cốc Di động, 3 chế độ xay, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1008, 1, 'GTJH013BK01', 'GTJH013', 'SimplusVN Bàn ủi hơi nước để bàn Simplus GTJH013, Bình nước 2L, Chức Năng Tự Làm Sạch, Bảng ủi Teflon 5 Chế Độ, Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1009, 1, 'GUOJ035CW00', 'GUOJ035', 'Simplus Chảo Nướng 26cm Chảo Rán Làm Bánh Ngàn Lớp GUOJ035 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1010, 1, 'CFJH009WH00', 'CFJH009', '[Sản phẩm mới]Simplus Máy Sấy Tóc Tốc Độ Cao 400 Triệu Ion Âm Tốc độ gió cao 65m/s CFJH009 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1011, 1, 'ZHKFJH014+MDJH002', 'ZHKFJH014+MDJH002', '[New Arrival] Simplus Máy Pha Cà Phê Chiết xuất nhỏ Giọt Tự Động 15Bar Áp xuất sâu Bình nước 12L Đồng hồ đo nhiệt độ KFJH014 - Bảo hành 1 năm 1 đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1012, 1, 'GTJH020PK00FZ01', 'GTJH020', 'Simplus Bàn ủi hơi nước cầm tay Simplus GTJH020, Công suất 1200W, Bình chứa nước 180ml, Gấp gọn tiện lợi Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1013, 1, 'ZHGTJH014WB01+YYST001', 'ZHGTJH014+YYST001', 'Simplus Bàn ủi hơi nước đứng - Bàn là cây hơi nước công suất 1800W - Bảo Hành 1 Năm 1 Đổi 1 - GTJH014', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1014, 1, 'ZHKFJH014+MDJH004', 'ZHKFJH014+MDJH004', '[New Arrival] Simplus Máy Pha Cà Phê Chiết xuất nhỏ Giọt Tự Động 15Bar Áp xuất sâu Bình nước 12L Đồng hồ đo nhiệt độ KFJH014 - Bảo hành 1 năm 1 đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1015, 1, 'ZFBA005PK00', 'ZFBA005', 'SimplusVN Máy Duỗi Tóc 5 Mức Nhiệt 35 Triệu Ion Âm Bảo Vệ Tóc ZFBA005, Thanh Duỗi Phủ Men Gốm Sứ, Bảng Điều Chỉnh 3D Linh Hoạt, Làm Nóng Nhanh 30s Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1016, 1, 'ZHGUOJXC02A', 'ZHGUOJXC02A_', 'INSSA [BH 1 Năm] Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng, dùng cho bếp từ GUOJ10-13', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1017, 1, 'ZHGUOJFK02F', 'ZHGUOJFK02F', 'INSSA Bộ nồi chảo chống dính sứ 18cm GUOJ021-22 - Bảo Hành 1 Năm', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1018, 1, 'XCLX-XCQH014BK00', 'XCLX-XCQH014', 'Simplus Pink tổng hợp Lõi lọc máy hút bụi - Các loại lõi lọc máy hút bụi XCLX', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1019, 1, 'XDJH004GY00', 'XDJH004', 'Simplus Máy Lau Sàn Hút Bụi Cầm Tay Không Dây Thông Minh XDJH004 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1020, 1, 'GTJH006BL00-VIP', 'GTJH006', 'Simplus Bàn Hơi Nước Cầm Tay GTJH006 Dung Tích 110mL - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1021, 1, 'MFGH003BN00', 'MFGH003', 'Simplus Hộp Đựng Sữa Bột Kín Hơi Màu Trà Chống Ánh Sáng MFGH003', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1022, 1, 'JSQH004WH00FZ01', 'JSQH004', 'Simplus Máy lọc nước tại vòi, 6 tầng lọc, thanh carbon có thể xé, 2 mức xả nước JSQH004', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1023, 1, 'GTJH021BW00', 'GTJH021', 'SimplusVN Bàn Ủi Hơi Nước Để Bàn GTJH021, Công Suất Lớn 2000w, Bình Nước 2l, Lực Phun Hơi Nước Mạnh 200g/Phút, Tự Động Làm Sạch, Nhiều Mức Nhiệt, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1024, 1, 'ZHGUOJXC03D', 'ZHGUOJXC03D_', 'INSSA [BH 1 Năm] Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng, dùng cho bếp từ GUOJ10-13', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1025, 1, 'GTJH016GR01', 'GTJH016', 'Simplus Bàn Ủi Hơi Nước Cầm Tay Dung Tích 170mL Có Thể Gấp Gọn GTJH016 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1026, 1, 'XSJH002CW00', 'XSJH002', 'Máy rửa tay Simplus Không tiếp xúc Dung tích 320ml XSJH002 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1027, 1, 'ZFBA004PK00FZ02', 'ZFBA004', 'Simplus Máy Duỗi Tóc Mini Nhỏ Gọn Tiện Lợi ZFBA004 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1028, 1, 'ZHGUOJXC02D', 'ZHGUOJXC02D', 'INSSA [BH 1 Năm] Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng, dùng cho bếp từ GUOJ10-13', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1029, 1, 'KFTZ001BK01', 'KFTZ001', 'Simplus Bộ Dụng Cụ Pha Cà Phê Espresso Tay Nén Bộ Rây Bột KFTZ001 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1030, 1, 'FKJH001WH01', 'FKJH001', 'Simplus Máy Hàn Miệng Túi Chân Không Thanh Hàn Dài 30cm FKJH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1031, 1, 'DRSH009WH00+MDJH002SS00+KFJH020TR01', 'ZHDRSH009+MDJH002+KFJH020', 'Simplus Bộ Cà Phê Bình Pha Cà Phê Thủy Tinh Ấm Nước Cổ Ngỗng Máy Xay Cà Phê Tay - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1032, 1, 'GTJH014WH01FZ02', 'GTJH014', 'SP01 Simplus Bàn Ủi Hơi Nước Đứng Simplus GTJH014 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1033, 1, 'ZFBA004PK00FZ01', 'ZFBA004', 'Simplus Máy Duỗi Tóc Mini Nhỏ Gọn Tiện Lợi ZFBA004 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1034, 1, 'ZFBA004GR00FZ01', 'ZFBA004', 'Simplus Máy Duỗi Tóc Mini Nhỏ Gọn Tiện Lợi ZFBA004 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1035, 1, 'SMZP-SMZJ004', 'SMZP-SMZJ004', 'Máy Làm Bánh Mì Sandwich Simplus SMZJ004, Làm Bánh Mì Nướng, Bánh Quế, Bánh Donut 2 Khay thay đổi Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1036, 1, 'GUOJ012CW01', 'GUOJ012', 'INSSA Nồi canh 24CM Nồi đá Maifan hầm nấu Chống dính dung tích lớn 4L GUOJ012 -BH 1 Năm', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1037, 1, 'XCQH008GY04+2LVXI', 'ZHXCQH008+XCLX008*2', 'Simplus Máy Hút Bụi Cầm Tay Lực Hút Mạnh 16000Pa XCQH008 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1038, 1, 'ZHGUOJYY03B', 'ZHGUOJYY03B', 'INSSA Bộ nồi Chảo có nắp đậy Tay cầm chống ghỉ Dụng cụ nấu ăn lành mạnh không chứa PFOA GUOJ016-19', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1039, 1, 'LLJH010WH03', 'LLJH010', 'Simplus Máy Xay Sinh Tố Đa Chức Năng Dung Tích 1.25L LLJH005 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1040, 1, 'ZFBA004WH00FZ03', 'ZFBA004', 'Simplus Máy Duỗi Tóc Mini Nhỏ Gọn Tiện Lợi ZFBA004 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1041, 1, 'ZFBA004WH00FZ01', 'ZFBA004', 'Simplus Máy Duỗi Tóc Mini Nhỏ Gọn Tiện Lợi ZFBA004 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1042, 1, 'GUOJ036CW00', 'GUOJ036', 'INSSA [BH 1 Năm] Nồi sữa 1.7L Dòng nồi Macaron Nồi đựng thức ăn cho bé cao cấp 16CM GUOJ036', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1043, 1, 'ZH-LVSH001WH00+5LVXI', 'ZHLVSH001*1+LVXI-LVSH001*5', 'INSSA Bình Lọc Nước Dung Tích Lớn 3.5L Hệ thống lọc tổng hợp 4 lớp LVSH001', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1044, 1, 'GUOJ040CW00', 'GUOJ040', 'Simplus Bộ Nồi Tay Cầm Tháo Rời Chảo Chiên 24cm Nồi Sữa 18cm Có Nắp Chống Dính Bộ 4 Món GUOJ040', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1045, 1, 'LVXI-KQJH008WH00', 'LVXI-KQJH008', 'Simplus Lõi Lọc Máy Lọc Không Khí  Dành Cho LVXI-KQJH', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1046, 1, 'ZHZZJH006+DFSH011', 'ZHZZJH006+DFSH011', 'Combo 01 Máy Xay Hoa Quả Cầm Tay Mini ZZJH006 & 01 Quạt Mini Thông Minh 3 Mức Gió, Pin 4800mah DFSH011 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1047, 1, 'GTJH020WH00FZ05', 'GTJH020', 'SP04 Bàn ủi hơi nước cầm tay Simplus GTJH020, Công suất 1200W, Bình chứa nước 180ml, Gấp gọn tiện lợi Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1048, 1, 'ZHGUOJFK05A', 'ZHGUOJFK05A_', 'INSSA [BH 1 Năm] Bộ nồi caramen pudding, nồi chống dính bằng gốm, nồi sữa, nồi súp, chảo rán, chảo chiên bộ 8 món ZHFK', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1049, 1, 'NPBH001WH00', 'NPBH001', '[Sản phẩm mới]Simplus Ca Đánh Sữa Dung Tích Lớn 600mL NPBH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1050, 1, 'FKJH001WH01+FKDA002TR01', 'ZHFKJH001+FKDA002', 'Simplus Máy Hàn Miệng Túi Chân Không Thanh Hàn Dài 30cm FKJH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1051, 1, 'ZHCUSH002WH01', 'ZHCUSH002+XXHE-CUSH002*2', 'Simplus Máy Hút Ẩm  Dung Tích lớn 2.5L màn hình LCD Tặng kèm 1 hộp thơm phòng CUSH002 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1052, 1, 'GUOJ030GY02', 'GUOJ030', 'InssaVN Bộ nồi chảo 4 món chống dính 18cm/24cm/24cm/28cm GUOJ030, chiên xào nấu tiện lợi phù hợp mọi loại bếp', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1053, 1, 'ZHGUOJXC03C', 'ZHGUOJXC03C_', 'INSSA [BH 1 Năm] Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng, dùng cho bếp từ GUOJ10-13', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1054, 1, 'CFJH011GY01', 'CFJH011', 'SimplusVN Máy Sấy Tóc Hyper-SIM Aura 10 Chế Độ Sấy 200 Triệu Ion Âm CFJH011, Độ Ồn Thấp 59dB, Chế Độ Điều Khiển Nhiệt Độ NTC, Chức Năng Tự Làm Sạch, Sấy Nhanh Trong 1 Phút Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1055, 1, 'ZH-LVSH001WH00+2LVXI', 'ZHLVSH001*1+LVXI-LVSH001*2', 'INSSA Bình Lọc Nước Dung Tích Lớn 3.5L Hệ thống lọc tổng hợp 4 lớp LVSH001', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1056, 1, 'MFGH002TR00', 'MFGH002', 'INSSA Bộ 3 hộp đựng thực phẩm đậy kín, dạng một nhấn, bảo quản lương thực, không chứa BPA, MFGH002', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1057, 1, 'KQJH009WH00', 'KQJH009', '[Sản phẩm mới] Simpus Máy Lọc Không Khí Hiệu Suất Cao Diện Tích Lọc Rộng 50-70㎡ KQJH009- Bảo Hành 2 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1058, 1, 'GUOJ039CW01', 'GUOJ039', 'InssaVN Bộ 4 Nồi Chảo Kèm 3 Nắp Và Xẻng Silicone GUOJ039, Lớp Phủ Men Gốm Chống Dính, Chiên Xào Nấu Ăn Tiện Lợi, Không Kén Bếp, Dòng Caramel', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1059, 1, 'DHGH001WH00FZ01', 'DHGH001', 'Simplus Nồi lẩu điện đa năng 3.2L Simplus DHGH001, nồi điện chống dính gia dụng 1300W, đun nấu, hầm canh, chiên xào, beefsteak Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1060, 1, 'FKDA002TR01', 'FKDA002', 'SimplusVN Túi Hút Chân Không Họa Tiết Lưới 50 Cái FKDA001 FKDA002, 2 Kích Thước 20*25cm Và 20*30cm, Bảo Quản Thực Phẩm, Phù Hợp Nhiều Loại Máy Hút Chân Không, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1061, 1, 'ZHGUOJXP3A', 'ZHGUOJXP3A', 'INSSA [BH 1 Năm] Chảo chiên rán 26CM chống dính chất lượng cao, chảo chiên trứng, xào nấu đa dụng GUOJ027', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1062, 1, 'CYQH003WH01', 'CYQH003', 'SimplusVN Máy Tăm Nước Không Dây  Bình Nước Lớn 300mL CYQH003, 4 Chế Độ 4 Vòi Xịt, Dùng Liên Tục Tới 5 Ngày, Sạc Type-C, Tiện Dụng Mang Theo, Chế Độ Nhắc Nhở Thông Minh Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1063, 1, 'KQJH006WH01', 'KQJH006', 'Simplus Máy Lọc Không Khí Điều Khiển Từ Xa Qua APP KQJH006 - Bảo Hành 2 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1064, 1, 'GUOJ040BK00', 'GUOJ040', 'Simplus Bộ Nồi Tay Cầm Tháo Rời Chảo Chiên 24cm Nồi Sữa 18cm Có Nắp Chống Dính Bộ 4 Món GUOJ040', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1065, 1, 'GUOJ039', 'GUOJ039', 'Inssa [BH 1 Năm] Bộ Nồi 8 Món Dòng Caramel Pudding Lớp Phủ Men Gốm Chống Dính Nồi GUOJ039', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1066, 1, 'CFJH001GY00 + ZFBA004WH00', 'ZHCFJH001+ZFBA004', 'Simplus Pink Máy Sấy Tóc Ion âm - 2 chiều nóng lạnh tạo kiểu bảo vệ tóc CFJH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1067, 1, 'GUOJ038CW01+ZENP016', 'ZHGUOJ038+ZENP016', 'INSSA [BH 1 Năm] Bộ nồi chảo, bộ 3 món, nồi chảo chống dính có tay cầm rời, quánh chống dính, nồi canh, chảo rán GUOJ038', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1068, 1, 'KFJH020TR01+MDJH002SS00', 'ZHKFJH020+MDJH002', 'Simplus Bộ Bình Cà Phê Nhỏ Giọt Bình Cà Phê Gợn Sóng 600mL KFJH020 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1069, 1, 'GTJH021BW00-VIP', 'GTJH021', 'Simplus Bàn Ủi Hơi Nước Gia Đình Dung Tích Lớn 2L GTJH021 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1070, 1, 'DFSH006WH00FZ04', 'DFSH006', 'Simplus Quạt cây 16 inch gió lớn độ ồn thấp tiết kiệm điện có thể xoay đầu điều chỉnh độ cao Thiết bị cần thiết cho gia đình và văn phòng DFSH002', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1071, 1, 'ZHLVSH001WH00*1+LVXI-LVSH001WH00*3', 'ZHLVSH001*1+LVXI-LVSH001*3', 'Simplus Bình Lọc Nước Dung Tích Lớn 3.5L Lọc sạch cặn bẩn và tạp chất, lõi lọc chất lượng- Bảo hành 1 năm 1 đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1072, 1, 'CFJH011WH01', 'CFJH011', 'Simplus Máy Sấy Tóc Hyper-SIM Aura 10 Chế Độ Sấy Tốc Độ Gió 70m/s  200 Triệu Ion Âm Độ Ồn Thấp 59dB CFJH011', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1073, 1, 'LLJH005WH01+ZENP016KK00', 'ZHLLJH005+ZENP016', 'Simplus Máy Xay Sinh Tố Đa Chức Năng Dung Tích 1.25L LLJH005 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1074, 1, 'ZBJH002WH00', 'ZBJH002', '[Sản phẩm mới] Máy làm đá Simplus Làm Đá Nhanh Chóng 10-15 Phút ZBJH002 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1075, 1, 'ZHFKJH001+FKDA002', 'ZHFKJH001+FKDA002', '[New Arrival] Simplus Máy hàn miệng túi chân không  Bảo quản thực phẩm Lưu trữ kín đa năng -60KPa  Áp lực chân không lớn  3 chế độ  Tặng kèm túi chân không FKJH001', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1076, 1, 'ZHGUOJXC04A', 'ZHGUOJXC04A_', 'INSSA [BH 1 Năm] Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng, dùng cho bếp từ GUOJ10-13', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1077, 1, 'ZHGUOJXP2B', 'ZHGUOJXP2B', 'Inssa Chảo Đáy Phẳng Kiểu Nhật 26cm Dòng Butter Cookies Chống Dính Kiểu Nhật Chiên Trứng Xào Rau GUOJ027 -Bảo Hành 1 Năm', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1078, 1, 'LVXI-KQJH004WH00', 'LVXI-KQJH004', 'Simplus Lõi Lọc Máy Lọc Không Khí  Dành Cho LVXI-KQJH', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1079, 1, 'ZHLVSH001WH00*1+LVXI-LVSH001WH00*5', 'ZHLVSH001*1+LVXI-LVSH001*5', 'Simplus Bình Lọc Nước Dung Tích Lớn 3.5L Lọc sạch cặn bẩn và tạp chất, lõi lọc chất lượng- Bảo hành 1 năm 1 đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1080, 1, 'FKDA001TR01', 'FKDA001', 'SimplusVN Túi Hút Chân Không Họa Tiết Lưới 50 Cái FKDA001 FKDA002, 2 Kích Thước 20*25cm Và 20*30cm, Bảo Quản Thực Phẩm, Phù Hợp Nhiều Loại Máy Hút Chân Không, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1081, 1, 'DFSH019GD00', 'DFSH019', 'SimplusVN Quạt Cầm Tay Tốc Độ Gió Mạnh 10m/s 100 Mức Điều Chỉnh Vô Cấp Thời Gian Sử Dụng 15H Động Cơ Không Chổi Than 3 Pha Sạc Type-C DFSH019  Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1082, 1, 'GUOJ033SS00', 'GUOJ033', 'Inssa Nồi Nấu Canh Bằng Thép Không Gỉ Đáy Nồi 3 Lớp Dày Dặn Kích Thước 16cm/20cm/24cm GUOJ034', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1083, 1, 'ZHGUOJXC04AFZ01', 'ZHGUOJXC04A_', '[New Arrival]INSSA Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng Inssa X Simplus dùng cho bếp từ ga bộ nồi chảo chống dính Nồi bếp từ', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1084, 1, 'LVSH001WH00+LVXI-LVSH001WH00*1', 'ZHLVSH001*1+LVXI-LVSH001*1', 'Simplus Pink Bình Lọc Nước - Cầm Tay Dung Tích Lớn 3.5L LVSH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1085, 1, 'ZH-JSQH004WH00+2LVXI', 'ZHJSQH004+ LVXI*2', 'INSSA Máy lọc nước tại vòi, 6 tầng lọc, thanh carbon có thể xé, 2 mức xả nước JSQH004', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1086, 1, 'LVSH001WH00+LVXI-LVSH001WH00*3', 'ZHLVSH001*1+LVXI-LVSH001*3', 'Simplus Pink Bình Lọc Nước - Cầm Tay Dung Tích Lớn 3.5L LVSH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1087, 1, 'GTJH020WH00FZ03', 'GTJH020', 'SP03  Bàn Ủi Hơi Nước Cầm Tay Simplus Bình Chứa Nước 180ml GTJH020 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1088, 1, 'YFCH001BK00', 'YFCH001', 'SimplusVN Cán Nén Bột Cà Phê 51mm YFCH001, Áp Lực Ổn Định Thiết Kế Ren Tay Cầm Bằng Nhôm Đế Thép Không Gỉ', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1089, 1, 'ZZJH010CW01', 'ZZJH010', 'SimplusVN Máy Ép Chậm Cổng Nạp Lớn 11,3cm ZZJH010, Dung Tích 1.2L, Ép Xoắn Ốc, Độ Tinh Khiết Tới 99.8%, Có Thể Tháo Rời Dễ Dàng Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1090, 1, 'DFSH009WH00+DFSH015PK00', 'ZHDFSH009+DFSH015', 'Simplus Quạt Đứng Và Để Bàn 2 Trong 1 DFSH009 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1091, 1, 'GUOJ012CW00FZ01', 'GUOJ012', '[New Arrival]INSSA Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng Inssa X Simplus dùng cho bếp từ ga bộ nồi chảo chống dính Nồi bếp từ', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1092, 1, 'JBBA003WH01', 'JBBA003', 'Simplus Máy Xay Cầm Tay Xay Thịt Đánh Trứng Xay Thực Phẩm Cho Bé Ép Trái Cây Làm Sốt Làm Bánh Xay Hạt JBBA003', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1093, 1, 'CUSH004WH02FZ02', 'CUSH004', 'SP01 Máy Hút Ẩm Công Suất 500ml/ngày Simplus CUSH004, Dung Tích Bình Chứa 1L, Hút Ẩm Thông Minh, Màn Hình Cảm Ứng, Tiết Kiệm Năng Lượng, Độ Ồn Thấp, Phù Hợp Cho Gia Đình Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1094, 1, 'ZH-FKJH001WH01+FKDA001TR01', 'ZHFKJH001+FKDA001', 'INSSA Máy hàn miệng túi chân không 60KPa  Áp lực chân không lớn Tặng kèm túi chân không FKJH001', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1095, 1, 'GUOJ028', 'GUOJ028', 'INSSA [BH 1 Năm] Chảo ăn sáng 3 trong 1 Chảo rán đa năng Chảo chống dính GUOJ028', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1096, 1, 'GUOJ043CW00', 'GUOJ043', '[Bản Nâng Cấp 2025] Inssa Chảo Chiên Đáy Phẳng Lòng Sâu 26cm Chống Dính Bền Bỉ Nhôm Đúc Chắc Chắn Không Độc Hại GUOJ043', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1097, 1, 'CFJH001GY00 + ZFBA004PK00', 'ZHCFJH001+ZFBA004', 'Simplus Pink Máy Sấy Tóc Ion âm - 2 chiều nóng lạnh tạo kiểu bảo vệ tóc CFJH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1098, 1, 'ZHJSQH004WH00 + LVXI *1', 'ZHJSQH004+ LVXI*1', 'Simplus Máy lọc nước tại vòi, 6 tầng lọc, thanh carbon có thể xé, 2 mức xả nước', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1099, 1, 'ZHXCQH002+GTJH020', 'ZHXCQH002+GTJH020', 'Combo 01 Máy Hút Bụi & 01 Bàn Ủi Hơi Nước Simplus XCQH002 & GTJH020 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1100, 1, 'LLJH005WH02', 'LLJH005', 'Simplus Máy Xay Đa Năng 5 Trong 1 Cối Xay Trái Cây 1.25L Cối Cắt Lát 1L Dùng Để Xay Sinh Tố Xay Thịt LLJH005WH02', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1101, 1, 'GTJH020PK00FZ02', 'GTJH020', 'SP02 Bàn ủi hơi nước cầm tay Simplus GTJH020, Công suất 1200W, Bình chứa nước 180ml, Gấp gọn tiện lợi Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1102, 1, 'ZHGUOJFK02B', 'ZHGUOJFK02B', 'INSSA [BH 1 Năm] Bộ Nồi 5 Món Dòng Caramel Pudding Lớp Phủ Men Gốm Chống Dính Nồi Sữa Chảo Xào Chảo Rán Nồi Canh GUOJFK', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1103, 1, 'ZHGUOJFK02C', 'ZHGUOJFK02C', 'INSSA [BH 1 Năm] Bộ Nồi 5 Món Dòng Caramel Pudding Lớp Phủ Men Gốm Chống Dính Nồi Sữa Chảo Xào Chảo Rán Nồi Canh GUOJFK', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1104, 1, 'ZHGUOJXP2A', 'ZHGUOJXP2A', 'Inssa Chảo Đáy Phẳng Kiểu Nhật 26cm Dòng Butter Cookies Chống Dính Kiểu Nhật Chiên Trứng Xào Rau GUOJ027', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1105, 1, 'GTJH016WH01', 'GTJH016', 'Simplus Bàn Ủi Cầm Tay Công Suất Dung Tích Hộc Nước 210mL Có Thể Gấp Gọn GTJH016 - BH 1 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1106, 1, 'CUSH002WH01+XXHE-CUSH002WH00*3', 'ZHCUSH002+XXHE-CUSH002*3', 'Simplus Pink Máy Hút Ẩm 2.5L - Dung Tích lớn, Tặng kèm 1 hộp thơm phòng CUSH002 - Bảo Hành 1 Năm 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1107, 1, 'YYST001', 'YYST001', 'Inssa Găng Tay Ủi Quần Áo Đệm Ủi Chịu Nhiệt Chống Thấm Nước Tiện Lợi YYST001', 'Cái', '8', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1108, 1, 'KFJH014WH00+MDJH003WH01', 'ZHKFJH014+MDJH003', 'Simplus Máy Pha Cà Phê Bán Tự Động Kiểu Ý Áp Suất Sâu 15 Bar KFJH014FZ - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1109, 1, 'ZHGUOJYY03A', 'ZHGUOJYY03A', 'Inssa Bộ Nồi Chảo Chống Dính 4 Món Chảo Rán Nồi Canh Chảo Xào Nồi Sữa GUOJ016-19 - Bảo Hành 1 Năm', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1110, 1, 'ZH-FKJH001WH01+FKDA002TR01', 'ZHFKJH001+FKDA002', 'INSSA Máy hàn miệng túi chân không 60KPa  Áp lực chân không lớn Tặng kèm túi chân không FKJH001', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1111, 1, 'GUOJ042CW00', 'GUOJ042', 'Inssa Bộ Nồi Chảo Chống Dính Gốm Sứ Chảo Chiên 16cm Nồi Sữa 16cm Nắp Kính Không PTFE GUOJ042', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1112, 1, 'KFJH014WH00+MDJH001CW00', 'ZHKFJH014+MDJH001', 'Simplus Máy Pha Cà Phê Bán Tự Động Kiểu Ý Áp Suất Sâu 15 Bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1113, 1, 'DDYS008WH01', 'DDYS008', 'Simplus Bàn Chải Điện Công Nghệ Rung 60° Tần Số Rung 66.000 Lần/phút 6 Chế Độ Làm Sạch 3 Đầu Bàn Chải Đa Năng DDYS008', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1114, 1, 'YTBA001GY01', 'YTBA001', 'Simplus Pink Bàn Là Gấp Gọn - Bàn ủi quần áo, giá đỡ Bàn là mini YTBA001', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1115, 1, 'ZHLVSH001WH00*1+LVXI-LVSH001WH00*1', 'ZHLVSH001*1+LVXI-LVSH001*1', 'Simplus Bình Lọc Nước Dung Tích Lớn 3.5L Lọc sạch cặn bẩn và tạp chất, lõi lọc chất lượng- Bảo hành 1 năm 1 đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1116, 1, 'ZHCFJH001+ZFBA003', 'ZHCFJH001+ZFBA003', 'Combo 01 Máy Sấy Tóc 2 Chiều Nóng Lạnh & 01 Máy Uốn Duỗi Tóc đa năng CFJH001 & ZFBA003 Bảo hành 1 năm chỉ đổi không sửa', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1117, 1, 'DSLU007BK01', 'DSLU007', 'Simplus Máy Nướng Bánh Mì 7 Mức Nhiệt 3 Chức Năng Rã Đông Công Suất 700W Khay Nướng Đa Năng Tự Động Bật Lên DSLU007', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1118, 1, 'ZHGUOJFK03A', 'ZHGUOJFK03A', 'INSSA [BH 1 Năm] Bộ Nồi 5 Món Dòng Caramel Pudding Lớp Phủ Men Gốm Chống Dính Nồi Sữa Chảo Xào Chảo Rán Nồi Canh GUOJFK', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1119, 1, 'DFSH018CW00', 'DFSH018', 'Simplus Quạt Cầm Tay Làm Mát Nhanh 5 Mức Gió Pin 11.5h Trọng Lượng Nhẹ 150g  DFSH018', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1120, 1, 'CFJH001GY00 + ZFBA004GR00', 'ZHCFJH001+ZFBA004', 'Simplus Pink Máy Sấy Tóc Ion âm - 2 chiều nóng lạnh tạo kiểu bảo vệ tóc CFJH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1121, 1, 'GUOJ044CW00', 'GUOJ044', 'Simplus Bộ Nồi Chảo 7 Món Nhôm Đúc Chống Dính Bền Bỉ Chảo Chiên 26cm Chảo Xào 30cm Nồi Canh 24cm Nồi Sữa 18cm GUOJ044', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1122, 1, 'GYPA-KQZG007', 'GYPA-KQZG007', 'SimplusVN Vỉ Chiên Chống Dính Rời cho Nồi Chiên Không Dầu GYPA-KQZG007', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1123, 1, 'XCZJ002WH00', 'XCZJ002', 'Simplus Giá Đỡ Máy Hút Bụi Dễ Lắp Ráp Không Khoan Lỗ Bền Bỉ Chống Trượt XCZJ002', 'Cái', '8', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1124, 1, 'ZHGUOJFK04A', 'ZHGUOJFK04A', 'INSSA [BH 1 Năm] Bộ Nồi 5 Món Dòng Caramel Pudding Lớp Phủ Men Gốm Chống Dính Nồi Sữa Chảo Xào Chảo Rán Nồi Canh GUOJFK', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1125, 1, 'ZHKFJH014+MDJH001', 'ZHKFJH014+MDJH001', '[New Arrival] Simplus Máy Pha Cà Phê Chiết xuất nhỏ Giọt Tự Động 15Bar Áp xuất sâu Bình nước 12L Đồng hồ đo nhiệt độ KFJH014 - Bảo hành 1 năm 1 đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1126, 1, 'PEIJIAN', 'PEIJIAN', 'SimplusVN phụ kiện sản phẩm', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1127, 1, 'GTJH020WH00FZ02', 'GTJH020', 'SP02 Bàn ủi hơi nước cầm tay Simplus GTJH020, Công suất 1200W, Bình chứa nước 180ml, Gấp gọn tiện lợi Bảo hành 1 năm chỉ đổi không sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1128, 1, 'ZHGUOJXP2C', 'ZHGUOJXP2C', 'Inssa Chảo Đáy Phẳng Kiểu Nhật 26cm Dòng Butter Cookies Chống Dính Kiểu Nhật Chiên Trứng Xào Rau GUOJ027', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1129, 1, 'KQZG020BK01-VIP', 'KQZG020', 'Simplus Nồi Chiên Không Dầu Hai Ngăn Dung Tích Lớn 10L Màn Hình LCD Menu 11 Món Cài Sẵn Cửa Sổ Trong Suốt KQZG020', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1130, 1, 'KQJH008WH01', 'KQJH008', 'Simplus Máy Lọc Không Khí Để Bàn OxyCare A5 Lite KQJH008 - Bảo Hành 2 Năm 1 Đổi 1', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1131, 1, 'GUOJ013-TI', 'GUOJ013', 'Inssa Bộ Nồi Chảo Chống Dính Gốm Sứ Chảo Chiên 16cm Nồi Sữa 16cm Nắp Kính Không PTFE GUOJ042', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1132, 1, 'FKJH001WH01+FKDA001TR01', 'ZHFKJH001+FKDA001', 'Simplus Máy Hàn Miệng Túi Chân Không Thanh Hàn Dài 30cm FKJH001 - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1133, 1, 'KFJH020TR01+DRSH009WH00', 'ZHKFJH020+DRSH009', 'Simplus Bộ Cà Phê Bình Pha Cà Phê Thủy Tinh Ấm Nước Cổ Ngỗng Máy Xay Cà Phê Tay - Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1134, 1, 'ZHGUOJYY02D', 'ZHGUOJYY02D', 'Inssa Bộ Nồi Chảo Chống Dính 4 Món Chảo Rán Nồi Canh Chảo Xào Nồi Sữa GUOJ016-19 - Bảo Hành 1 Năm', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1135, 1, 'ZHGUOJXC02E', 'ZHGUOJXC02E', 'INSSA [BH 1 Năm] Bộ nồi chảo đá chống dính màu cream cao cấp chính hãng, dùng cho bếp từ GUOJ10-13', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1136, 1, 'GUOJ020CW01+GUOJ026CW01', 'ZHGUOJ020+GUOJ026', 'Inssa Bộ Nồi Chảo Chống Dính Gốm Sứ Chảo Chiên 16cm Nồi Sữa 16cm Nắp Kính Không PTFE GUOJ042', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1137, 1, 'ZHGTJH014WY01+YYST001FZ01', 'ZHGTJH014+YYST001', 'Simplus Bàn ủi hơi nước đứng GTJH014 Khay nước trong suốt 1.8L Là đứng là nằm 2 trong 1- Bảo Hành 1 Năm 1 Đổi 1', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1138, 1, 'ZFBA007PK00', 'ZFBA007', 'SimplusVN Máy Duỗi Tóc Nhỏ Gọn Trọng Lượng Nhẹ Tấm Làm Nóng Bằng Gốm Làm Nóng Nhanh Uốn Duỗi 2in1 Tạo Kiểu Tóc Nam ZFBA007 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1139, 1, 'GUOJ020CW01+GUOJ027CW00', 'ZHGUOJ020+GUOJ027', 'Inssa Bộ Nồi Chảo Chống Dính Gốm Sứ Chảo Chiên 16cm Nồi Sữa 16cm Nắp Kính Không PTFE GUOJ042', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1140, 1, 'DFSH019WH00', 'DFSH019', 'Simplus Quạt Cầm Tay Tốc Độ Gió Mạnh 10m/s 100 Mức Điều Chỉnh Vô Cấp Thời Gian Sử Dụng 15H DFSH019', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1141, 1, 'ZH-KFJH014WH00+MDJH002SS00', 'ZHKFJH014+MDJH002', 'Inssa Máy Pha Cà Phê Bán Tự Động Kiểu Ý Áp Suất Sâu 15 Bar KFJH014 - Bảo Hành 1 Năm', 'Bộ', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(1142, 1, 'GUOJ027CW01', 'GUOJ027', '[Livestream] INSSA Nồi nấu 18/20cm Nồi tuyết Nhật Nồi sữa Nồi đựng thức ăn cho bé cao cấp GUOJ020/27', 'Cái', '10', '2025-06-26 02:24:44', '2025-06-26 02:24:44');

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `combo_detail_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`id`, `product_id`, `combo_detail_code`, `detail_name`, `unit`, `quantity`, `created_at`, `updated_at`) VALUES
(7, 390, '12', '12', '12', 12, '2025-06-25 21:50:00', '2025-06-25 21:50:00'),
(15, 1, 'ưqeq213', 'chi tiết', 'chi tiết', 2, '2025-06-25 23:43:10', '2025-06-25 23:43:10'),
(16, 1, 'ưqeq', 'chi tiết', 'chi tiết', 2, '2025-06-25 23:43:10', '2025-06-25 23:43:10'),
(17, 1, 'ưqeq', 'chi tiết', 'chi tiết', 2, '2025-06-25 23:43:10', '2025-06-25 23:43:10'),
(23, 391, '2321', '3213', '21321', 3, '2025-06-26 00:08:02', '2025-06-26 00:08:02'),
(24, 391, 'heheehhe', '123213', '213', 1, '2025-06-26 00:08:02', '2025-06-26 00:08:02'),
(25, 391, '213213', '12312', '312321', 1312, '2025-06-26 00:08:02', '2025-06-26 00:08:02'),
(26, 391, '123123', '2133', '123123', 112, '2025-06-26 00:08:02', '2025-06-26 00:08:02'),
(27, 583, 'GUOJ011', 'Chảo nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ011 (GUOJ011CW01) (GUOJ011CR01) (GUOJ011CR01FZ01), kt: 28*28*8.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(28, 583, 'GUOJ012', 'Nồi nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ012 (GUOJ012CW00) (GUOJ012CR01) (ZHGUOJXC02C) , kt: 24*24*11.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(29, 583, 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', 1, '2025-06-26 02:24:43', '2025-06-26 02:24:43'),
(30, 816, 'GTJH014', 'Bàn ủi hơi nước dạng đứngcông suất 2000W, điện áp 220-240V nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(31, 816, 'YYST001', 'Simplus Găng tay bàn ủi quần áo, đệm ủi bàn là chịu nhiệt, chống bỏng, chống thấm nước tiện lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(32, 837, 'GTJH011', 'Bàn ủi hơi nước cầm tay, mã GTJH011, công suất 1200W, điện áp 220-240V, dùng để ủi quần áo, nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(33, 837, 'YYST001', 'Simplus Găng tay bàn ủi quần áo, đệm ủi bàn là chịu nhiệt, chống bỏng, chống thấm nước tiện lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(34, 915, 'JSQH005', 'INSSA Máy lọc nước tại vòi, 7 tầng lọc, lõi lọc gốm sứ dễ dàng vệ sinh, dùng cho nhà bếp và nhà vệ sinh JSQH005', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(35, 915, 'LVXI-JSQH005', 'Lõi lọc của thiết bị lọc nước tại vòi (Đầu lọc nước tại vòi), mã LVXI-JSQH005WH00, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(36, 917, 'LLJH004', 'Máy Xay Sinh Tố Simplus Máy xay sinh tố đa năng LLJH004 Dung Tích 600ml', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(37, 917, 'GMBE-LLJH004', 'Cối xay lẻ- SimplusVN Máy Xay Sinh Tố Simplus Dung Tích 600ml Đa Chức Năng LLJH004 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(38, 922, 'CFJH001', 'Máy sấy tóc đa chức năng Simplus 3 tốc độ điều chỉnh gió nóng / lạnh dụng cụ tạo kiểu mang đi du lịch 220V', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(39, 922, 'JFBA009', 'Máy uốn tóc mini Simplus Uốn duỗi 2 in 1 Đường kính 28mm', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(40, 938, 'JSQH003', 'Máy lọc nước gia dụng Simplus, lọc vòi nước nhà bếp và nhà vệ sinh, lõi lọc phức hợp hiệu quả cao, 2 kiểu xả nước, nước đã lọc và chưa lọc', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(41, 938, 'LVXI-JSQH003', 'Lõi lọc phức hợp hiệu quả cao - máy siêu lọc vòi nước gia dụng', 'Cái', 2, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(42, 939, 'CUSH002', 'Máy Hút Ẩm Simplus Dung Tích lớn 2.5L màn hình LCD', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(43, 939, 'XXHE-CUSH002', 'Phụ kiện máy hút ẩm- hộp chứa tinh dầu, chất liệu nhựa, mã XXHE-CUSH002', 'Cái', 2, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(44, 940, 'JSQH001', 'Máy lọc nước siêu lọc Simplus Uống trực tiếp tại nhà máy JSQH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(45, 940, 'LVXI-JSQH001', 'Lõi lọc Bình lọc nước Simplus LVXI-JSQH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(46, 941, 'JSQH005', 'Thiết bị lọc nước tại vòi, 7 tầng lọc, lõi lọc gốm sứ dễ dàng vệ sinh, dùng cho nhà bếp và nhà vệ sinh JSQH005', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(47, 941, 'LVXI-JSQH005', 'Phụ kiện thiết bị lọc nước - Lõi lọc của thiết bị lọc nước tại vòi (Đầu lọc nước tại vòi), mã LVXI-JSQH005', 'Cái', 2, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(48, 942, 'KFJH014', 'Máy Pha Cà Phê Bán Tự Động Kiểu Ý Simplus Áp suất sâu 15 bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(49, 942, 'MDJH002', 'Máy xay hạt cà phê Simplus Cầm tay, Xay thủ công 20g Màu Inox', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(50, 943, 'LLJH004', 'Máy Xay Sinh Tố Simplus Máy xay sinh tố đa năng LLJH004 Dung Tích 600ml', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(51, 943, 'GMBE-LLJH004', 'Cối xay lẻ- SimplusVN Máy Xay Sinh Tố Simplus Dung Tích 600ml Đa Chức Năng LLJH004 Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(52, 944, 'XCQH002', 'Máy hút bụi Simplus cầm tay có dây 12000Pa XCQH002 công suất cao 300W', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(53, 944, 'XCLX002', 'Simplus Bộ Phận lọc của máy hút bụi được điều chỉnh phù hợp với XCQI002', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(54, 945, 'LLJH005', 'Simplus Máy Xay Sinh Tố Đa Chức Năng 1.25L Công suất lớn 380W 3 cối đa dụng', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(55, 945, 'LVWA-LLJH005', 'Lưới Lọc Máy Xay Sinh Tố Đa Chức Năng', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(56, 949, 'CFLL002', 'Đồ dùng nhà bếp bằng Silicon tay cầm gỗ sồi chịu nhiệt cao chuyên dụng làm quà tặng ngẫu nhiên ( thìa, chổi quét, vá, xẻng,..)', 'Bộ', 2, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(57, 950, 'GUOJ016', 'Chảo chống dính Simplus Đường kính 24cm GUOJ016', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(58, 950, 'GUOJ017', 'Nồi nấu canh chống dính có nắp đậy 24 cm. Tay cầm chống trầy xước Dụng cụ nấu ăn tốt cho sức khỏe, bếp từ không chứa  PFOA', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(59, 950, 'GUOJ018', 'Chảo chống dính  28CM Chảo sâu lòng chảo có nắp đậy Tay cầm chống ghỉ Dụng cụ nấu ăn lành mạnh không chứaPFOA', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(60, 950, 'GUOJ019', 'Nồi ủ sữa 18cm có nắp bếp từ bếp điện từ gốm sứ  nồi nhỏ sử dụng cho gia đình', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(61, 951, 'KFJH014', 'Máy Pha Cà Phê Bán Tự Động Kiểu Ý Simplus Áp suất sâu 15 bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(62, 951, 'MDJH004', 'Máy xay hạt cà phê, mã CG9702-GS2, điện áp: 220-240V, công suất: 200W, nhãn hiệu SIMPLUS, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(63, 952, 'DZGH002', 'Simplus Nồi hấp điện ẩu điện đa năng Dung tích 1.5L', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(64, 952, 'DDJR004', 'Máy xay thịt Simplus (1.8L), cối thủy tinh, 420 lưỡi thép không gỉ DDJR003', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(65, 954, 'GUOJ022', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(66, 954, 'GUOJ023', 'Chảo Chiên Simplus 18cm - Chất Liệu Chống Dính Phù Hợp Bếp Ga Bếp Từ Nồi Chiên Rán Phủ Men Gốm Đa Công Năng Tiện Lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(67, 956, 'GUOJ010', 'Chảo nhôm 18CM có nắp màu kem, mã GUOJ010, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(68, 956, 'GUOJ011', 'Chảo nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ011 (GUOJ011CW01) (GUOJ011CR01) (GUOJ011CR01FZ01), kt: 28*28*8.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(69, 956, 'GUOJ012', 'Nồi nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ012 (GUOJ012CW00) (GUOJ012CR01) (ZHGUOJXC02C) , kt: 24*24*11.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(70, 962, 'XCQH002', 'Máy hút bụi Simplus cầm tay có dây 12000Pa XCQH002 công suất cao 300W', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(71, 962, 'CMYH006', 'Máy Hút Bụi Giường Nệm, Thiết Kế Cốc Đôi, Tiệt Trùng UV, Đánh Bụi 14000 Vòng/Phút, Hút Mạnh 16000pa, Bộ Lọc HEPA F9', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(72, 965, 'GUOJ011', 'Chảo nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ011 (GUOJ011CW01) (GUOJ011CR01) (GUOJ011CR01FZ01), kt: 28*28*8.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(73, 965, 'GUOJ012', 'Nồi nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ012 (GUOJ012CW00) (GUOJ012CR01) (ZHGUOJXC02C) , kt: 24*24*11.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(74, 966, 'GUOJ010', 'Chảo nhôm 18CM có nắp màu kem, mã GUOJ010, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(75, 966, 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(76, 967, 'GUOJ016', 'Chảo chống dính Simplus Đường kính 24cm GUOJ016', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(77, 967, 'GUOJ019', 'Nồi ủ sữa 18cm có nắp bếp từ bếp điện từ gốm sứ  nồi nhỏ sử dụng cho gia đình', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(78, 973, 'KFJH011', 'Simplus Máy pha cà phê Máy pha cà phê lọc gia đình  Dung tích lớn 750ml Pha trà pha cà phê tiện dụng', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(79, 973, 'MDJH002', 'Máy xay hạt cà phê Simplus Cầm tay, Xay thủ công 20g Màu Inox', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(80, 987, 'KQZG017', 'Nồi chiên không dầu, mã KY-1021PV (CKZ-2329B), điện áp 220V-240V, công suất 1300W, dung tích 4L, có chức năng chiên, nướng... nhãn hiệu SIMPLUS, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(81, 987, 'SPJA001', 'Simplus Kẹp gắp thức ăn Silicone SPJA001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(82, 997, 'GTJH014', 'Bàn ủi hơi nước dạng đứngcông suất 2000W, điện áp 220-240V nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(83, 997, 'YYST001', 'Simplus Găng tay bàn ủi quần áo, đệm ủi bàn là chịu nhiệt, chống bỏng, chống thấm nước tiện lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(84, 999, 'JSQH001', 'Máy lọc nước siêu lọc Simplus Uống trực tiếp tại nhà máy JSQH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(85, 999, 'LVXI-JSQH001', 'Lõi lọc Bình lọc nước Simplus LVXI-JSQH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(86, 1000, 'GTJH011', 'Bàn ủi hơi nước cầm tay, mã GTJH011, công suất 1200W, điện áp 220-240V, dùng để ủi quần áo, nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(87, 1000, 'YYST001', 'Simplus Găng tay bàn ủi quần áo, đệm ủi bàn là chịu nhiệt, chống bỏng, chống thấm nước tiện lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(88, 1005, 'CFJH001', 'Máy sấy tóc đa chức năng Simplus 3 tốc độ điều chỉnh gió nóng / lạnh dụng cụ tạo kiểu mang đi du lịch 220V', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(89, 1005, 'MFSH001', 'Lược chải tóc đệm hơi tay cầm dài Simplus, làm mượt tóc, massage tại nhà và tạo kiểu tóc MFSH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(90, 1011, 'KFJH014', 'Máy Pha Cà Phê Bán Tự Động Kiểu Ý Simplus Áp suất sâu 15 bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(91, 1011, 'MDJH002', 'Máy xay hạt cà phê Simplus Cầm tay, Xay thủ công 20g Màu Inox', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(92, 1013, 'GTJH014', 'Bàn ủi hơi nước dạng đứngcông suất 2000W, điện áp 220-240V nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(93, 1013, 'YYST001', 'Simplus Găng tay bàn ủi quần áo, đệm ủi bàn là chịu nhiệt, chống bỏng, chống thấm nước tiện lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(94, 1014, 'KFJH014', 'Máy Pha Cà Phê Bán Tự Động Kiểu Ý Simplus Áp suất sâu 15 bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(95, 1014, 'MDJH004', 'Máy xay hạt cà phê, mã CG9702-GS2, điện áp: 220-240V, công suất: 200W, nhãn hiệu SIMPLUS, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(96, 1016, 'GUOJ011', 'Chảo nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ011 (GUOJ011CW01) (GUOJ011CR01) (GUOJ011CR01FZ01), kt: 28*28*8.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(97, 1016, 'GUOJ010', 'Chảo nhôm 18CM có nắp màu kem, mã GUOJ010, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(98, 1017, 'GUOJ021', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán (Nồi nấu bột)', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(99, 1017, 'GUOJ022', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(100, 1024, 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(101, 1024, 'GUOJ012', 'Nồi nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ012 (GUOJ012CW00) (GUOJ012CR01) (ZHGUOJXC02C) , kt: 24*24*11.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(102, 1024, 'GUOJ010', 'Chảo nhôm 18CM có nắp màu kem, mã GUOJ010, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(103, 1028, 'GUOJ010', 'Chảo nhôm 18CM có nắp màu kem, mã GUOJ010, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(104, 1028, 'GUOJ012', 'Nồi nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ012 (GUOJ012CW00) (GUOJ012CR01) (ZHGUOJXC02C) , kt: 24*24*11.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(105, 1031, 'DRSH009', 'Ấm pha cà phê Simplus hép không gỉ 304 Dung tích 0.8L DRSH009', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(106, 1031, 'MDJH002', 'Máy xay hạt cà phê Simplus Cầm tay, Xay thủ công 20g Màu Inox', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(107, 1031, 'KFJH020', 'Dụng cụ pha cà phê bằng thủy tinh. Kt: 13*11*19cm', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(108, 1037, 'XCQH008', 'Máy hút bụi Simplus có dây nhỏ gọn lực hút mạnh 16000PA', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(109, 1037, 'XCLX008', 'Simplus Bộ phận lọc của máy hút bụi được điều chỉnh phù hợp với máy hút bụi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(110, 1038, 'GUOJ017', 'Nồi nấu canh chống dính có nắp đậy 24 cm. Tay cầm chống trầy xước Dụng cụ nấu ăn tốt cho sức khỏe, bếp từ không chứa  PFOA', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(111, 1038, 'GUOJ018', 'Chảo chống dính  28CM Chảo sâu lòng chảo có nắp đậy Tay cầm chống ghỉ Dụng cụ nấu ăn lành mạnh không chứaPFOA', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(112, 1038, 'GUOJ019', 'Nồi ủ sữa 18cm có nắp bếp từ bếp điện từ gốm sứ  nồi nhỏ sử dụng cho gia đình', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(113, 1043, 'LVXI-LVSH001', 'Lõi lọc Bình lọc nước Simplus LVXILVSH001WH00', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(114, 1043, 'LVSH001', 'Simplus  Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(115, 1046, 'ZZJH006', 'Máy xay sinh tố cầm tay Simplus dung tích 400ml', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(116, 1046, 'DFSH011', 'Quạt mini cầm tay Simplus 4800mAh/2000mAh Chức năng có thể gập lại 3 trong 1', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(117, 1048, 'GUOJ021', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán (Nồi nấu bột)', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(118, 1048, 'GUOJ022', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(119, 1048, 'GUOJ023', 'Chảo Chiên Simplus 18cm - Chất Liệu Chống Dính Phù Hợp Bếp Ga Bếp Từ Nồi Chiên Rán Phủ Men Gốm Đa Công Năng Tiện Lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(120, 1048, 'GUOJ024', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(121, 1048, 'GUOJ025', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(122, 1050, 'FKJH001', 'Máy hàn miệng túi chân không 60KPa', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(123, 1050, 'FKDA002', 'Túi đựng thực phẩm, Kt: 20*30*1cm', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(124, 1051, 'CUSH002', 'Máy Hút Ẩm Simplus Dung Tích lớn 2.5L màn hình LCD', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(125, 1051, 'XXHE-CUSH002', 'Phụ kiện máy hút ẩm- hộp chứa tinh dầu, chất liệu nhựa, mã XXHE-CUSH002', 'Cái', 2, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(126, 1053, 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(127, 1053, 'GUOJ011', 'Chảo nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ011 (GUOJ011CW01) (GUOJ011CR01) (GUOJ011CR01FZ01), kt: 28*28*8.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(128, 1053, 'GUOJ010', 'Chảo nhôm 18CM có nắp màu kem, mã GUOJ010, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(129, 1055, 'LVSH001', 'Simplus  Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(130, 1055, 'LVXI-LVSH001', 'Phụ kiện bình lọc nước - Lõi lọc Bình lọc nước Simplus LVXI-LVSH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(131, 1061, 'GUOJ027', '[Nồi bếp từ] Nồi tuyết 18 / 20cm, nồi nấu Nhật, nồi sữa, dùng được cho 2-3 người, nồi chống dính tay cầm vân gỗ, nồi nấu có nắp đậy', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(132, 1061, 'GUOJ020', 'Chảo nhôm 18CM có nắp màu kem', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(133, 1061, 'GUOJ026', 'Nồi tuyết Simplus nồi nấu Nhật 18 / 20cm nồi sữa nồi bổ sung thức ăn cho bé dùng được cho 2-3 người', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(134, 1066, 'CFJH001', 'Máy sấy tóc đa chức năng Simplus 3 tốc độ điều chỉnh gió nóng / lạnh dụng cụ tạo kiểu mang đi du lịch 220V', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(135, 1066, 'ZFBA004', 'Máy duỗi tóc, điện áp 220-240V, công suất 17W, 50/60Hz, nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(136, 1067, 'GUOJ038', 'Bộ nấu ăn bằng nhôm gồm nồi và chảo, KT: 18*18*8cm, 20*20*5.5cm, 26*26*5cm nhãn hiệu INSSA', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(137, 1067, 'ZENP016', 'Tạp dề INSSA  Tạp dề chống thấm nước và chống dầu nhà bếp  Bảo vệ quần áo không bị dính bẩn cà phê thức ăn ZENP016', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(138, 1068, 'KFJH020', 'Dụng cụ pha cà phê bằng thủy tinh. Kt: 13*11*19cm', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(139, 1068, 'MDJH002', 'Máy xay hạt cà phê Simplus Cầm tay, Xay thủ công 20g Màu Inox', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(140, 1071, 'LVXI-LVSH001', 'Lõi lọc Bình lọc nước Simplus LVXILVSH001WH00', 'Cái', 3, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(141, 1071, 'LVSH001', 'Simplus  Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(142, 1073, 'LLJH005', 'Simplus Máy Xay Sinh Tố Đa Chức Năng 1.25L Công suất lớn 380W 3 cối đa dụng', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(143, 1073, 'ZENP016', 'Tạp dề INSSA  Tạp dề chống thấm nước và chống dầu nhà bếp  Bảo vệ quần áo không bị dính bẩn cà phê thức ăn ZENP016', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(144, 1075, 'FKJH001', 'Máy hàn miệng túi chân không 60KPa', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(145, 1075, 'FKDA002', 'Túi đựng thực phẩm, Kt: 20*30*1cm', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(146, 1076, 'GUOJ010', 'Chảo nhôm 18CM có nắp màu kem, mã GUOJ010, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(147, 1076, 'GUOJ011', 'Chảo nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ011 (GUOJ011CW01) (GUOJ011CR01) (GUOJ011CR01FZ01), kt: 28*28*8.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(148, 1076, 'GUOJ012', 'Nồi nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ012 (GUOJ012CW00) (GUOJ012CR01) (ZHGUOJXC02C) , kt: 24*24*11.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(149, 1076, 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(150, 1077, 'GUOJ027', 'Nồi tuyết 18 / 20cm, nồi nấu Nhật, nồi sữa, dùng được cho 2-3 người, nồi chống dính tay cầm vân gỗ, nồi nấu có nắp đậy', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(151, 1077, 'GUOJ026', 'Nồi tuyết Simplus nồi nấu Nhật 18 / 20cm nồi sữa nồi bổ sung thức ăn cho bé dùng được cho 2-3 người', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(152, 1079, 'LVXI-LVSH001', 'Lõi lọc Bình lọc nước Simplus LVXILVSH001WH00', 'Cái', 5, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(153, 1079, 'LVSH001', 'Simplus  Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(154, 1083, 'GUOJ010', 'Chảo nhôm 18CM có nắp màu kem, mã GUOJ010, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(155, 1083, 'GUOJ011', 'Chảo nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ011 (GUOJ011CW01) (GUOJ011CR01) (GUOJ011CR01FZ01), kt: 28*28*8.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(156, 1083, 'GUOJ012', 'Nồi nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ012 (GUOJ012CW00) (GUOJ012CR01) (ZHGUOJXC02C) , kt: 24*24*11.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(157, 1083, 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(158, 1084, 'LVXI-LVSH001', 'Lõi lọc Bình lọc nước Simplus LVXILVSH001WH00', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(159, 1084, 'LVSH001', 'Simplus  Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(160, 1085, 'JSQH004', 'Máy lọc nước tại vòi, 6 tầng lọc, thanh carbon có thể xé, 2 mức xả nước,nhãn hiệu Simplus', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(161, 1085, 'LVXI-JSQH004', 'Phụ kiện máy lọc nước - Lõi lọc của đầu lọc nước tại vòi, tốc độ lọc nước 2L/phút, mã:LVXI-JSQH004', 'Cái', 2, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(162, 1086, 'LVXI-LVSH001', 'Lõi lọc Bình lọc nước Simplus LVXILVSH001WH00', 'Cái', 3, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(163, 1086, 'LVSH001', 'Simplus  Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(164, 1090, 'DFSH009', 'SimplusVN Quạt Đứng Điều Chỉnh Độ Cao Simplus DFSH009, Ba Mức Độ Gió, Hoạt Động Yên Tĩnh Và Tiết Kiệm Năng Lượng, Có Thể Để Bàn, Bảo Hành 1 Năm Chỉ Đổi Không Sửa', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(165, 1090, 'DFSH015', 'Quạt cầm tay mini,  mã K4, công suất 2.22W, dòng điện DC 5V, dung lượng pin 600mah, nhãn hiệu SIMPLUS, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(166, 1094, 'FKJH001', 'Máy hàn miệng túi chân không 60KPa', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(167, 1094, 'FKDA001', 'Túi đựng thực phẩm, Kt: 20*25*1cm', 'Bộ', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(168, 1097, 'CFJH001', 'Máy sấy tóc đa chức năng Simplus 3 tốc độ điều chỉnh gió nóng / lạnh dụng cụ tạo kiểu mang đi du lịch 220V', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(169, 1097, 'ZFBA004', 'Máy duỗi tóc, điện áp 220-240V, công suất 17W, 50/60Hz, nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(170, 1098, 'JSQH004', 'Máy lọc nước tại vòi, 6 tầng lọc, thanh carbon có thể xé, 2 mức xả nước,nhãn hiệu Simplus', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(171, 1098, 'LVXI-JSQH004', 'Lõi lọc của đầu lọc nước tại vòi, mã:LVXI-JSQH004, tốc độ lọc nước 2L/phút', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(172, 1099, 'XCQH002', 'Máy hút bụi Simplus cầm tay có dây 12000Pa XCQH002 công suất cao 300W', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(173, 1099, 'GTJH020', 'Bàn ủi hơi nước cầm tay công suất 1200W, 50/60Hz, điện áp 220-240V ,nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(174, 1102, 'GUOJ021', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán (Nồi nấu bột)', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(175, 1102, 'GUOJ023', 'Chảo Chiên Simplus 18cm - Chất Liệu Chống Dính Phù Hợp Bếp Ga Bếp Từ Nồi Chiên Rán Phủ Men Gốm Đa Công Năng Tiện Lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(176, 1103, 'GUOJ013', 'Inssa Nồi nấu bột chống dính bằng đá Maifan cỡ 18cm , tiện lợi hâm sữa, nấu bữa dặm, thức ăn bổ sung cho bé', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(177, 1103, 'GUOJ011', 'Chảo nhôm có nắp thủy tinh, màu kem trắng, mã GUOJ011 (GUOJ011CW01) (GUOJ011CR01) (GUOJ011CR01FZ01), kt: 28*28*8.5cm, nhãn hiệu INSSA, mới 100%', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(178, 1104, 'GUOJ027', '[Nồi bếp từ] Nồi tuyết 18 / 20cm, nồi nấu Nhật, nồi sữa, dùng được cho 2-3 người, nồi chống dính tay cầm vân gỗ, nồi nấu có nắp đậy', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(179, 1104, 'GUOJ020', 'Chảo nhôm 18CM có nắp màu kem', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(180, 1106, 'CUSH002', 'Máy Hút Ẩm Simplus Dung Tích lớn 2.5L màn hình LCD', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(181, 1106, 'XXHE-CUSH002', 'Phụ kiện máy hút ẩm- hộp chứa tinh dầu, chất liệu nhựa, mã XXHE-CUSH002', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(182, 1108, 'KFJH014', 'Máy Pha Cà Phê Bán Tự Động Kiểu Ý Simplus Áp suất sâu 15 bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(183, 1108, 'MDJH003', 'Máy xay hạt cà phê Simplus MDJH003 Lưỡi dao bằng thép không gỉ 304', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(184, 1109, 'GUOJ016', 'Chảo chống dính Simplus Đường kính 24cm GUOJ016', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(185, 1109, 'GUOJ017', 'Nồi nấu canh chống dính có nắp đậy 24 cm. Tay cầm chống trầy xước Dụng cụ nấu ăn tốt cho sức khỏe, bếp từ không chứa  PFOA', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(186, 1109, 'GUOJ018', 'Chảo chống dính  28CM Chảo sâu lòng chảo có nắp đậy Tay cầm chống ghỉ Dụng cụ nấu ăn lành mạnh không chứaPFOA', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(187, 1110, 'FKJH001', 'Máy hàn miệng túi chân không 60KPa', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(188, 1110, 'FKDA002', 'Túi đựng thực phẩm, Kt: 20*30*1cm', 'Bộ', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(189, 1112, 'KFJH014', 'Máy Pha Cà Phê Bán Tự Động Kiểu Ý Simplus Áp suất sâu 15 bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(190, 1112, 'MDJH001', 'Máy xay hạt cà phê Simplus Máy xay điện gia dụng Máy xay cà phê tự động', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(191, 1115, 'LVXI-LVSH001', 'Lõi lọc Bình lọc nước Simplus LVXILVSH001WH00', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(192, 1115, 'LVSH001', 'Simplus  Bình Lọc Nước Cầm Tay Dung Tích Lớn  3.5L LVSH001', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(193, 1116, 'CFJH001', 'Máy sấy tóc đa chức năng Simplus 3 tốc độ điều chỉnh gió nóng / lạnh dụng cụ tạo kiểu mang đi du lịch 220V', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(194, 1116, 'ZFBA003', 'Máy duỗi tóc, điện áp 110-240V, công suất 45W, nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(195, 1118, 'GUOJ021', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán (Nồi nấu bột)', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(196, 1118, 'GUOJ024', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(197, 1118, 'GUOJ025', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(198, 1120, 'CFJH001', 'Máy sấy tóc đa chức năng Simplus 3 tốc độ điều chỉnh gió nóng / lạnh dụng cụ tạo kiểu mang đi du lịch 220V', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(199, 1120, 'ZFBA004', 'Máy duỗi tóc, điện áp 220-240V, công suất 17W, 50/60Hz, nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(200, 1124, 'GUOJ021', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán (Nồi nấu bột)', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(201, 1124, 'GUOJ024', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(202, 1124, 'GUOJ025', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(203, 1124, 'GUOJ023', 'Chảo Chiên Simplus 18cm - Chất Liệu Chống Dính Phù Hợp Bếp Ga Bếp Từ Nồi Chiên Rán Phủ Men Gốm Đa Công Năng Tiện Lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(204, 1125, 'KFJH014', 'Máy Pha Cà Phê Bán Tự Động Kiểu Ý Simplus Áp suất sâu 15 bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(205, 1125, 'MDJH001', 'Máy xay hạt cà phê Simplus Máy xay điện gia dụng Máy xay cà phê tự động', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(206, 1128, 'GUOJ020', 'Chảo nhôm 18CM có nắp màu kem', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(207, 1128, 'GUOJ026', 'Nồi tuyết Simplus nồi nấu Nhật 18 / 20cm nồi sữa nồi bổ sung thức ăn cho bé dùng được cho 2-3 người', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(208, 1132, 'FKJH001', 'Máy hàn miệng túi chân không 60KPa', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(209, 1132, 'FKDA001', 'Túi đựng thực phẩm, Kt: 20*25*1cm', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(210, 1133, 'KFJH020', 'Dụng cụ pha cà phê bằng thủy tinh. Kt: 13*11*19cm', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(211, 1133, 'DRSH009', 'Ấm pha cà phê Simplus hép không gỉ 304 Dung tích 0.8L DRSH009', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(212, 1134, 'GUOJ016', 'Chảo chống dính Simplus Đường kính 24cm GUOJ016', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(213, 1134, 'GUOJ017', 'Nồi nấu canh chống dính có nắp đậy 24 cm. Tay cầm chống trầy xước Dụng cụ nấu ăn tốt cho sức khỏe, bếp từ không chứa  PFOA', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(214, 1135, 'GUOJ023', 'Chảo Chiên Simplus 18cm - Chất Liệu Chống Dính Phù Hợp Bếp Ga Bếp Từ Nồi Chiên Rán Phủ Men Gốm Đa Công Năng Tiện Lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(215, 1135, 'GUOJ024', 'Simplus chảo chống dính Pudding Series chảo gia dụng bếp ga cảm ứng sữa nồi gốm chảo rán', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(216, 1136, 'GUOJ020', 'INSSA Nồi tuyết 18 / 20cm, nồi nấu Nhật, nồi sữa, nồi bổ sung thức ăn cho bé, dùng được cho 2-3 người (Size18cm)', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(217, 1136, 'GUOJ026', 'INSSA Nồi tuyết 18 / 20cm, nồi nấu Nhật, nồi sữa, nồi bổ sung thức ăn cho bé, dùng được cho 2-3 người (Size 20cm)', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(218, 1137, 'GTJH014', 'Bàn ủi hơi nước dạng đứngcông suất 2000W, điện áp 220-240V nhãn hiệu SIMPLUS', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(219, 1137, 'YYST001', 'Simplus Găng tay bàn ủi quần áo, đệm ủi bàn là chịu nhiệt, chống bỏng, chống thấm nước tiện lợi', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(220, 1139, 'GUOJ020', 'INSSA Nồi tuyết 18 / 20cm, nồi nấu Nhật, nồi sữa, nồi bổ sung thức ăn cho bé, dùng được cho 2-3 người (Size18cm)', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(221, 1139, 'GUOJ027', 'INSSA Chảo chiên rán 26CM chống dính chất lượng cao, chảo chiên trứng, xào nấu đa dụng', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(222, 1141, 'KFJH014', 'Máy Pha Cà Phê Bán Tự Động Kiểu Ý Simplus Áp suất sâu 15 bar KFJH014 - Bảo Hành 1 Năm 1 Đổi 1', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44'),
(223, 1141, 'MDJH002', 'Máy xay hạt cà phê Simplus Cầm tay, Xay thủ công 20g Màu Inox', 'Cái', 1, '2025-06-26 02:24:44', '2025-06-26 02:24:44');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `default_role` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `note`, `status`, `default_role`) VALUES
(1, 'administration', 'api', '2025-06-09 23:23:02', '2025-06-22 20:26:39', 'Quant trị viên', 1, 0),
(2, 'nhân viên content', 'api', '2025-06-09 23:46:09', '2025-06-29 18:55:03', NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1);

-- --------------------------------------------------------

--
-- Table structure for table `setting_account_ecommerce`
--

CREATE TABLE `setting_account_ecommerce` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interpretation` json DEFAULT NULL,
  `product_name_setting` json DEFAULT NULL,
  `added_tax_vat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warehouse` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_capital_price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_warehouse` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_number_prefix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tiền tố Số chứng từ ',
  `issue_voucher_prefix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tiền tố Số phiếu xuất ',
  `user_id` int(11) NOT NULL,
  `shop_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'lazada',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `account_cash_debt` int(13) DEFAULT NULL,
  `account_revenue` int(13) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `setting_account_ecommerce`
--

INSERT INTO `setting_account_ecommerce` (`id`, `customer_code`, `customer_name`, `interpretation`, `product_name_setting`, `added_tax_vat`, `warehouse`, `account_capital_price`, `account_warehouse`, `payment_method`, `document_number_prefix`, `issue_voucher_prefix`, `user_id`, `shop_id`, `type`, `created_at`, `updated_at`, `account_cash_debt`, `account_revenue`) VALUES
(1, 'heheheheheh', '1221', '[\"2\", \"1\", \"3\"]', '[\"2\"]', '33311', '324234', '632', '1561', '1', '13213213', '1132321321', 1, 7, 'lazada', '2025-07-13 21:32:51', '2025-07-30 20:05:47', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_package` date DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `expiration_package` date DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `packages_id` int(11) DEFAULT NULL,
  `api_token` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_created_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `phone`, `address`, `create_package`, `note`, `expiration_package`, `status`, `packages_id`, `api_token`, `token_created_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'truong', 'truongbackend@gmail.com', '2032-02-25 02:51:34', '$2a$12$NFemA43XtUrxRyeMbTcKA.PQXWX9DG9F7Yi/vsIu.Xb3TbTHbN1GC', '0521266565', '0521266565121', '2025-06-30', NULL, '2026-07-31', 1, 4, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYXBpL2xvZ2luIiwiaWF0IjoxNzUzOTgyMjE2LCJleHAiOjE3NTQ1ODcwMTYsIm5iZiI6MTc1Mzk4MjIxNiwianRpIjoiWUR3RTlQb0pNVHBBNjNPRiIsInN1YiI6IjEiLCJwcnYiOiIyM2JkNWM4OTQ5ZjYwMGFkYjM5ZTcwMWM0MDA4NzJkYjdhNTk3NmY3In0.76eQAhq19E0NB5IBSthNQ6CdnMwFc7PoLi4c8KsOvHU', '2025-06-22 23:06:32', NULL, '2024-07-20 01:59:26', '2025-07-31 10:16:56'),
(6, 'admin', 'admin@gmail.com', NULL, '$2y$10$p4cmVtGZAMVWOhflDtgbguJ9UI9vjMm.Daa4otYgE.0Dgq2j6QUUC', '0352848002', '412', '2025-06-09', NULL, '2025-06-12', 0, 4, '', NULL, NULL, '2025-06-09 01:06:54', '2025-06-09 19:55:06'),
(7, 'truong', 'gh@gmail.com', NULL, '$2y$10$NfHYNUt.p5eKgthmkVwlQ.4kcDgEINRv4gz9u2XeaH/uku22UdiVG', '352848002', '214', '2025-06-09', NULL, '2025-06-27', 1, 3, '', NULL, NULL, '2025-06-09 01:07:48', '2025-06-09 01:14:09'),
(8, 'truong', 'truong@gmail.com', NULL, '$2a$12$NFemA43XtUrxRyeMbTcKA.PQXWX9DG9F7Yi/vsIu.Xb3TbTHbN1GC', NULL, NULL, NULL, NULL, NULL, 1, 3, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYXBpL2xvZ2luIiwiaWF0IjoxNzUzOTI4NTgyLCJleHAiOjE3NTQ1MzMzODIsIm5iZiI6MTc1MzkyODU4MiwianRpIjoiUzRDbVJxOTZjZDh5c3B2VSIsInN1YiI6IjgiLCJwcnYiOiIyM2JkNWM4OTQ5ZjYwMGFkYjM5ZTcwMWM0MDA4NzJkYjdhNTk3NmY3In0.g5SVW8GtmP2j50zajHdflmGuzETtpTvAFgVSFhm5h18', NULL, NULL, '2025-06-09 03:00:02', '2025-07-30 19:23:02'),
(9, 'truong', 'truong123@gmail.com', NULL, '$2y$10$6lJNvdwSjAu08wUykhdwjuatIOMFAy.w7qkETamqA/N.KYQQ98ZQO', '0352848005', NULL, '2025-06-10', NULL, '2025-06-11', 1, NULL, 'EofAHhhFyHEOEnPxVFq79Hx6MDaBMGyhyjfkvcPEHGr9Woo6V4qHZvo1SBq5', NULL, NULL, '2025-06-10 03:01:17', '2025-06-10 03:04:10'),
(10, 'hehehe', 'hehee@gmail.com', NULL, '$2y$10$RFDyyCC1q9VFoEnBEhTP4.5usuK/.CvD7QF3SXAkk.uZTDrJf0Lp6', NULL, NULL, '2025-06-10', NULL, '2025-06-11', 1, NULL, NULL, NULL, NULL, '2025-06-10 03:02:53', '2025-06-10 03:02:53'),
(11, 'aa', 'abc@gmail.com', NULL, '$2y$10$iy8XIcOa33X85rJy2NXpJulMG9CqEGs20RzfRvE9P8SviMQWdZ/Ky', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, '2025-06-12 08:26:01', '2025-06-12 08:26:01'),
(12, 'hêh ngay 22', 'he22@gmail.com', NULL, '$2y$10$ceVwL7zfmBOZ18uHKgPBr.ROO5i20l.NU4JpELDlgzidUwM.lAR52', NULL, NULL, NULL, NULL, '2025-06-22', 1, 3, NULL, NULL, NULL, '2025-06-12 09:35:17', '2025-06-12 09:35:17'),
(13, 'ngay moii', 'ngaymoi@gmail.com', NULL, '$2y$10$zzpWMnrj25jjBMXajpn7DeKS36xQlY4LsKe.hCC1bPnS2ek3wZNrO', NULL, NULL, '2025-06-12', NULL, '2025-06-22', 1, 3, NULL, NULL, NULL, '2025-06-12 09:39:49', '2025-06-12 09:39:49'),
(14, 'truong12', 'truong12@gmail.com', NULL, '$2y$10$n2Ixc5A0LI2AwDIkqWmc1egD2CejmBGojZC.vz3maC36oan8Hmi2W', NULL, NULL, '2025-06-12', NULL, '2025-06-22', 1, 3, NULL, NULL, NULL, '2025-06-12 09:58:34', '2025-06-12 09:58:34'),
(17, 'truong123', 'truong11322@gmail.com', NULL, '$2y$10$n2Ixc5A0LI2AwDIkqWmc1egD2CejmBGojZC.vz3maC36oan8Hmi2W', NULL, NULL, '2025-06-12', NULL, '2025-06-22', 1, 3, NULL, NULL, NULL, '2025-06-12 09:58:34', '2025-06-12 09:58:34'),
(18, 'truong', 'truong1@gmail.com', NULL, '$2y$10$TVFRk3aGoQ3//jK3Zj34i.5ngzotHUdXanQZqwh2gqwdbJc63DSGW', NULL, NULL, '2025-06-15', NULL, '2025-06-25', 1, 3, NULL, NULL, NULL, '2025-06-15 08:34:07', '2025-06-15 08:34:07'),
(19, 'truong', 'ahh1h2@gmail.com', NULL, '$2y$10$52.ihW2Y9xSqqM7TAou5HOv5kIkwSOL667WAfVWB2jjyG8l/fAP8W', NULL, NULL, '2025-06-16', NULL, '2025-06-26', 1, 3, NULL, NULL, NULL, '2025-06-16 01:51:03', '2025-06-16 01:51:03'),
(20, 'Admin', 'nhatmai.ketoan@gmail.com', NULL, '$2y$10$xnb7XbiB63I/V6N6VKcqduAQrAvJIUONHtNrEVaLkhnut.GbCgKJG', NULL, NULL, '2025-06-16', NULL, '2025-06-26', 1, 3, NULL, NULL, NULL, '2025-06-16 04:41:33', '2025-06-16 04:41:33'),
(22, 'Lim', 'nguyenthily.weup@gmail.com', NULL, '$2y$10$qSOdrgkJsONwELAJG7PDfuamhV8NCXwvLD5mJZXU/3SlfvxuKgCSG', NULL, NULL, '2025-06-16', NULL, '2025-06-26', 1, 3, 'tBpTPG2RPNnhhj8WzRpX4Xf3bocDmOuFtRZFAaPaRlK8yS2fcFzIO6PISCBI', NULL, NULL, '2025-06-16 05:19:23', '2025-06-16 06:32:55'),
(23, 'hoàng hải đăng', 'hoanghaidang.dev@gmail.com', NULL, '$2y$10$Qvcxwi0TOvdAjbUFahoHlOhDYgT8QNMNKBYWCJuvFEJKktXSGoGDC', NULL, NULL, '2025-06-16', NULL, '2025-06-26', 1, 3, 'URD9HC82nYkGKLISkZ6o7FFEmBv6qL9kWedkliTZHGtncuRUpVskPifYVlbn', NULL, NULL, '2025-06-16 07:30:08', '2025-06-16 08:20:28'),
(24, 'nuni', 'truo213ng@gmail.com', NULL, '$2y$10$c.t3bdivOyKETZ4XCTpym.Hnu5mfkyUK1OrbYbIYaDpo5G0XhBaP6', NULL, NULL, '2025-06-23', NULL, '2025-07-03', 1, 3, NULL, NULL, NULL, '2025-06-22 20:16:54', '2025-06-22 20:16:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `complaints_user_id_foreign` (`user_id`);

--
-- Indexes for table `custom_notifications`
--
ALTER TABLE `custom_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `history_export`
--
ALTER TABLE `history_export`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `lazada_shop_tokens`
--
ALTER TABLE `lazada_shop_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `notification_user`
--
ALTER TABLE `notification_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `notification_user_notification_id_user_id_unique` (`notification_id`,`user_id`),
  ADD KEY `notification_user_user_id_foreign` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_package_id_foreign` (`package_id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_sku_unique` (`sku`);

--
-- Indexes for table `product_details`
--
ALTER TABLE `product_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_details_product_id_foreign` (`product_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `setting_account_ecommerce`
--
ALTER TABLE `setting_account_ecommerce`
  ADD PRIMARY KEY (`id`),
  ADD KEY `setting_account_ecommerce_shop_id_foreign` (`shop_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `custom_notifications`
--
ALTER TABLE `custom_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `history_export`
--
ALTER TABLE `history_export`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `lazada_shop_tokens`
--
ALTER TABLE `lazada_shop_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `notification_user`
--
ALTER TABLE `notification_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=660;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1143;

--
-- AUTO_INCREMENT for table `product_details`
--
ALTER TABLE `product_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `setting_account_ecommerce`
--
ALTER TABLE `setting_account_ecommerce`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notification_user`
--
ALTER TABLE `notification_user`
  ADD CONSTRAINT `notification_user_notification_id_foreign` FOREIGN KEY (`notification_id`) REFERENCES `custom_notifications` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notification_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_details`
--
ALTER TABLE `product_details`
  ADD CONSTRAINT `product_details_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `setting_account_ecommerce`
--
ALTER TABLE `setting_account_ecommerce`
  ADD CONSTRAINT `setting_account_ecommerce_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `lazada_shop_tokens` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
